/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.1-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: buku_tamu_ci4
-- ------------------------------------------------------
-- Server version	11.8.1-MariaDB-4deepin1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `keperluan`
--

DROP TABLE IF EXISTS `keperluan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `keperluan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `urutan` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keperluan`
--

LOCK TABLES `keperluan` WRITE;
/*!40000 ALTER TABLE `keperluan` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `keperluan` VALUES
(1,'Meeting/Rapat',1,1),
(2,'Interview',1,2),
(3,'Konsultasi',1,3),
(4,'Pengambilan Dokumen',1,4),
(5,'Lainnya',1,5);
/*!40000 ALTER TABLE `keperluan` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `penilaian_kategori`
--

DROP TABLE IF EXISTS `penilaian_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `penilaian_kategori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `urutan` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penilaian_kategori`
--

LOCK TABLES `penilaian_kategori` WRITE;
/*!40000 ALTER TABLE `penilaian_kategori` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `penilaian_kategori` VALUES
(1,'Pelayanan resepsionis',1,1),
(2,'Kecepatan pelayanan',2,1),
(3,'Keramahan petugas',3,1),
(4,'Kenyamanan fasilitas',4,1),
(5,'Kesediaan membantu',5,1);
/*!40000 ALTER TABLE `penilaian_kategori` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `profil_instansi`
--

DROP TABLE IF EXISTS `profil_instansi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `profil_instansi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_instansi` varchar(100) NOT NULL DEFAULT 'Instansi Anda',
  `telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profil_instansi`
--

LOCK TABLES `profil_instansi` WRITE;
/*!40000 ALTER TABLE `profil_instansi` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `profil_instansi` VALUES
(1,'Instansi Pemerintah','-','info@instansi.go.id','https://www.instansi.go.id','Jl. Contoh No. 123, Kota Contoh',NULL,NULL);
/*!40000 ALTER TABLE `profil_instansi` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survei_kepuasan`
--

DROP TABLE IF EXISTS `survei_kepuasan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survei_kepuasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tamu_id` int(11) NOT NULL,
  `saran` text DEFAULT NULL,
  `kritik` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `tamu_id` (`tamu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survei_kepuasan`
--

LOCK TABLES `survei_kepuasan` WRITE;
/*!40000 ALTER TABLE `survei_kepuasan` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survei_kepuasan` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survei_penilaian`
--

DROP TABLE IF EXISTS `survei_penilaian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survei_penilaian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survei_id` int(11) NOT NULL,
  `penilaian_kategori_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survei_id` (`survei_id`),
  KEY `penilaian_kategori_id` (`penilaian_kategori_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survei_penilaian`
--

LOCK TABLES `survei_penilaian` WRITE;
/*!40000 ALTER TABLE `survei_penilaian` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survei_penilaian` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tamu`
--

DROP TABLE IF EXISTS `tamu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tamu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) NOT NULL,
  `asal_instansi` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `keperluan_id` int(11) DEFAULT NULL,
  `bertemu_dengan` varchar(100) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `tanda_tangan` text DEFAULT NULL,
  `waktu_masuk` datetime DEFAULT NULL,
  `waktu_keluar` datetime DEFAULT NULL,
  `status` enum('masuk','keluar') DEFAULT 'masuk',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `keperluan_id` (`keperluan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tamu`
--

LOCK TABLES `tamu` WRITE;
/*!40000 ALTER TABLE `tamu` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tamu` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'admin','admin@bukutamu.com','$2y$12$0feDjGMXxhhK5IFFhGiEi.YVVpMF7jaskkd/Y19ug00jojrrdTlWe','Administrator',NULL,'2026-01-20 18:18:46','2026-01-20 18:18:46');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-06 18:52:56
