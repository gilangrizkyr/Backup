/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.1-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: buku_tamu
-- ------------------------------------------------------
-- Server version	11.8.1-MariaDB-4deepin1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `keperluan`
--

DROP TABLE IF EXISTS `keperluan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `keperluan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `urutan` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keperluan`
--

LOCK TABLES `keperluan` WRITE;
/*!40000 ALTER TABLE `keperluan` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `keperluan` VALUES
(1,'Meeting/Rapat',1,1),
(2,'Interview',1,2),
(3,'Konsultasi',1,3),
(4,'Pengambilan Dokumen',1,4),
(5,'Lainnya',1,5);
/*!40000 ALTER TABLE `keperluan` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `profil_instansi`
--

DROP TABLE IF EXISTS `profil_instansi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `profil_instansi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_instansi` varchar(100) NOT NULL DEFAULT 'Instansi Anda',
  `telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profil_instansi`
--

LOCK TABLES `profil_instansi` WRITE;
/*!40000 ALTER TABLE `profil_instansi` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `profil_instansi` VALUES
(1,'Instansi Pemerintah','-','info@instansi.go.id','https://www.instansi.go.id','Jl. Contoh No. 123, Kota Contoh',NULL,NULL);
/*!40000 ALTER TABLE `profil_instansi` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survei_pertanyaans`
--

DROP TABLE IF EXISTS `survei_pertanyaans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survei_pertanyaans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survei_id` int(11) NOT NULL,
  `pertanyaan` text NOT NULL,
  `tipe_input` enum('rating','text','textarea') DEFAULT 'rating',
  `is_required` tinyint(1) DEFAULT 1,
  `urutan` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `survei_id` (`survei_id`),
  CONSTRAINT `survei_pertanyaans_ibfk_1` FOREIGN KEY (`survei_id`) REFERENCES `survei_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survei_pertanyaans`
--

LOCK TABLES `survei_pertanyaans` WRITE;
/*!40000 ALTER TABLE `survei_pertanyaans` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survei_pertanyaans` VALUES
(1,1,'Bagaimana penilaian Anda terhadap pelayanan kami?','rating',1,1,'2026-01-20 10:33:50'),
(2,1,'Apakah Anda puas dengan kecepatan pelayanan?','rating',1,2,'2026-01-20 10:33:50'),
(3,1,'Bagaimana keramahan petugas?','rating',1,3,'2026-01-20 10:33:50'),
(4,1,'Apakah fasilitas memadai?','rating',1,4,'2026-01-20 10:33:50'),
(5,1,'Kesediaan membantu','rating',1,5,'2026-01-20 10:33:50'),
(6,3,'Apa?','rating',1,1,'2026-01-20 18:44:39'),
(7,3,'Ada apa','rating',1,2,'2026-01-20 18:44:39');
/*!40000 ALTER TABLE `survei_pertanyaans` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survei_response_details`
--

DROP TABLE IF EXISTS `survei_response_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survei_response_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `response_id` int(11) NOT NULL,
  `pertanyaan_id` int(11) NOT NULL,
  `jawaban` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `response_id` (`response_id`),
  KEY `pertanyaan_id` (`pertanyaan_id`),
  CONSTRAINT `survei_response_details_ibfk_1` FOREIGN KEY (`response_id`) REFERENCES `survei_responses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `survei_response_details_ibfk_2` FOREIGN KEY (`pertanyaan_id`) REFERENCES `survei_pertanyaans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survei_response_details`
--

LOCK TABLES `survei_response_details` WRITE;
/*!40000 ALTER TABLE `survei_response_details` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survei_response_details` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survei_responses`
--

DROP TABLE IF EXISTS `survei_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survei_responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survei_id` int(11) NOT NULL,
  `tamu_id` int(11) NOT NULL,
  `kritik` text DEFAULT NULL,
  `saran` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `survei_id` (`survei_id`),
  KEY `tamu_id` (`tamu_id`),
  CONSTRAINT `survei_responses_ibfk_1` FOREIGN KEY (`survei_id`) REFERENCES `survei_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `survei_responses_ibfk_2` FOREIGN KEY (`tamu_id`) REFERENCES `tamu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survei_responses`
--

LOCK TABLES `survei_responses` WRITE;
/*!40000 ALTER TABLE `survei_responses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survei_responses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survei_templates`
--

DROP TABLE IF EXISTS `survei_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survei_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(200) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `rating_min` int(11) DEFAULT 1,
  `rating_max` int(11) DEFAULT 5,
  `show_kritik` tinyint(1) DEFAULT 1,
  `show_saran` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survei_templates`
--

LOCK TABLES `survei_templates` WRITE;
/*!40000 ALTER TABLE `survei_templates` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survei_templates` VALUES
(1,'Survei Kepuasan Tamu','Bantu kami meningkatkan kualitas pelayanan dengan mengisi survei ini',1,5,1,1,0,'2026-01-20 10:33:50','2026-01-20 10:45:06'),
(3,'Survei Persepsi Korupsi','',1,6,1,1,1,'2026-01-20 10:44:39','2026-01-20 10:44:45');
/*!40000 ALTER TABLE `survei_templates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tamu`
--

DROP TABLE IF EXISTS `tamu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tamu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) NOT NULL,
  `asal_instansi` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `keperluan_id` int(11) DEFAULT NULL,
  `bertemu_dengan` varchar(100) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `tanda_tangan` text DEFAULT NULL,
  `waktu_masuk` datetime DEFAULT NULL,
  `waktu_keluar` datetime DEFAULT NULL,
  `status` enum('masuk','keluar') DEFAULT 'masuk',
  PRIMARY KEY (`id`),
  KEY `keperluan_id` (`keperluan_id`),
  CONSTRAINT `tamu_ibfk_1` FOREIGN KEY (`keperluan_id`) REFERENCES `keperluan` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tamu`
--

LOCK TABLES `tamu` WRITE;
/*!40000 ALTER TABLE `tamu` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tamu` VALUES
(1,'Gilang',NULL,'12121232',NULL,NULL,1,NULL,NULL,'1',NULL,NULL,'masuk');
/*!40000 ALTER TABLE `tamu` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'admin','admin@bukutamu.com','$2y$12$0feDjGMXxhhK5IFFhGiEi.YVVpMF7jaskkd/Y19ug00jojrrdTlWe','Administrator',NULL,'2025-12-04 13:40:37','2026-01-20 09:20:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-06 18:52:55
