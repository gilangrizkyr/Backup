/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.1-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: kinerja2
-- ------------------------------------------------------
-- Server version	11.8.1-MariaDB-4deepin1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `bidang`
--

DROP TABLE IF EXISTS `bidang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bidang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bidang` varchar(255) NOT NULL,
  `kode_bidang` varchar(50) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode_bidang` (`kode_bidang`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bidang`
--

LOCK TABLES `bidang` WRITE;
/*!40000 ALTER TABLE `bidang` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bidang` VALUES
(1,'Pengendalian','123','','2025-11-20 08:18:53','2025-11-20 08:18:53'),
(2,'Penanaman Modal','456','','2025-11-20 08:19:04','2025-11-20 08:19:04');
/*!40000 ALTER TABLE `bidang` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` text DEFAULT NULL,
  `blocked_until` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `blocked_ips` VALUES
(1,'::1','Too many failed login attempts','2026-02-13 05:39:39','2026-02-13 13:09:39');
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `laporan_kinerja`
--

DROP TABLE IF EXISTS `laporan_kinerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `laporan_kinerja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bidang_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `judul_kegiatan` varchar(255) NOT NULL,
  `uraian_kegiatan` text NOT NULL,
  `dokumentasi` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected','edited') DEFAULT 'pending',
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `catatan_verifikasi` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `bidang_id` (`bidang_id`),
  KEY `verified_by` (`verified_by`),
  CONSTRAINT `laporan_kinerja_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `laporan_kinerja_ibfk_2` FOREIGN KEY (`bidang_id`) REFERENCES `bidang` (`id`) ON DELETE CASCADE,
  CONSTRAINT `laporan_kinerja_ibfk_3` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laporan_kinerja`
--

LOCK TABLES `laporan_kinerja` WRITE;
/*!40000 ALTER TABLE `laporan_kinerja` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `laporan_kinerja` VALUES
(1,4,1,'2025-11-19','yuhu apakah yang kamu lakukan','asdasd asda sda sd asd asd as a sd','1763602875_125e495c7361273560f0.png','pending',NULL,'2025-11-20 00:40:06','','2025-11-20 08:37:46','2025-11-20 09:41:15'),
(2,4,1,'2025-11-20','asdlkjasdlkjas  ads asd asd asd asd ','asdhkjl askjdh askdjh qwieoypfasdfj asiodpf qwernk ','1763601350_6ff230d95232f69359f0.png','approved',NULL,'2025-11-20 02:23:03','','2025-11-20 09:15:50','2025-11-20 10:23:03'),
(3,4,1,'2025-11-04','asdlkjasdlkjas  ads ','asd asd asd awdasd aasf ','1763604254_de3636aa844be79b77c6.jpg','approved',NULL,'2025-11-20 02:32:27','','2025-11-20 10:04:14','2025-11-20 10:32:27'),
(4,4,1,'2026-02-13','Testtest','testtestasdadsadsadasdsadasdsadasdasdsa','1770959584_8bc94a43019b12d8d31a.png','approved',6,'2026-02-13 05:13:47','','2026-02-13 13:13:04','2026-02-13 13:13:47'),
(5,4,1,'2026-02-13','Testtest','safsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewfsafsafsafasssssssssssssssssssssssssssssssfdewf','1770960054_12d099e53b9c8851d012.png','approved',6,'2026-02-13 05:21:13','','2026-02-13 13:20:54','2026-02-13 13:22:48');
/*!40000 ALTER TABLE `laporan_kinerja` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `log_activity`
--

DROP TABLE IF EXISTS `log_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `activity_type` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `log_activity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=540 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_activity`
--

LOCK TABLES `log_activity` WRITE;
/*!40000 ALTER TABLE `log_activity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `log_activity` VALUES
(3,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:18:36'),
(4,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:18:36'),
(5,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/bidang','http://localhost:8080/index.php/superadmin/bidang','GET','2025-11-20 08:18:39'),
(6,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','superadmin/bidang/tambah','http://localhost:8080/index.php/superadmin/bidang/tambah','POST','2025-11-20 08:18:53'),
(7,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/bidang','http://localhost:8080/index.php/superadmin/bidang','GET','2025-11-20 08:18:53'),
(8,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','superadmin/bidang/tambah','http://localhost:8080/index.php/superadmin/bidang/tambah','POST','2025-11-20 08:19:04'),
(9,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/bidang','http://localhost:8080/index.php/superadmin/bidang','GET','2025-11-20 08:19:04'),
(10,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:19:06'),
(11,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:20:28'),
(12,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:23:48'),
(13,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','superadmin/users/tambah','http://localhost:8080/index.php/superadmin/users/tambah','POST','2025-11-20 08:24:02'),
(14,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:24:02'),
(15,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:25:08'),
(16,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','superadmin/users/tambah','http://localhost:8080/index.php/superadmin/users/tambah','POST','2025-11-20 08:25:18'),
(17,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:25:18'),
(18,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:26:14'),
(19,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 08:26:29'),
(20,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:26:29'),
(21,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:26:38'),
(22,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:26:38'),
(23,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:26:50'),
(24,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:28:14'),
(25,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:28:16'),
(26,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:30:28'),
(27,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 08:30:30'),
(28,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/riwayat-verifikasi','http://localhost:8080/index.php/sekretaris/riwayat-verifikasi','GET','2025-11-20 08:30:34'),
(29,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/riwayat-verifikasi','http://localhost:8080/index.php/sekretaris/riwayat-verifikasi','GET','2025-11-20 08:30:52'),
(30,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/riwayat-verifikasi','http://localhost:8080/index.php/sekretaris/riwayat-verifikasi','GET','2025-11-20 08:30:53'),
(31,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:30:54'),
(32,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:30:56'),
(33,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 08:31:07'),
(34,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:31:07'),
(35,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:31:14'),
(36,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:31:14'),
(37,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/bidang','http://localhost:8080/index.php/superadmin/bidang','GET','2025-11-20 08:31:16'),
(38,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:31:17'),
(39,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','superadmin/users/tambah','http://localhost:8080/index.php/superadmin/users/tambah','POST','2025-11-20 08:31:28'),
(40,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:31:28'),
(41,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','superadmin/users/tambah','http://localhost:8080/index.php/superadmin/users/tambah','POST','2025-11-20 08:31:43'),
(42,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/index.php/superadmin/users','GET','2025-11-20 08:31:43'),
(43,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 08:31:46'),
(44,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:31:46'),
(45,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:31:51'),
(46,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:31:52'),
(47,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:32:16'),
(48,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/laporan-semua','http://localhost:8080/index.php/kepaladinas/laporan-semua','GET','2025-11-20 08:32:30'),
(49,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:32:33'),
(50,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:35:13'),
(51,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 08:35:17'),
(52,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:35:17'),
(53,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:35:23'),
(54,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:35:23'),
(55,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:36:27'),
(56,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 08:36:38'),
(57,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 08:36:59'),
(58,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:36:59'),
(59,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:37:22'),
(60,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:37:23'),
(61,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:37:26'),
(62,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 08:37:27'),
(63,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/index.php/laporan/store','POST','2025-11-20 08:37:46'),
(64,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:37:47'),
(65,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:38:06'),
(66,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:38:22'),
(67,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:38:22'),
(68,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:38:48'),
(69,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 08:38:51'),
(70,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 08:39:33'),
(71,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/1','http://localhost:8080/index.php/sekretaris/verifikasi/detail/1','GET','2025-11-20 08:39:35'),
(72,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/1','http://localhost:8080/index.php/sekretaris/verifikasi/detail/1','GET','2025-11-20 08:40:02'),
(73,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','sekretaris/verifikasi/proses/1','http://localhost:8080/index.php/sekretaris/verifikasi/proses/1','POST','2025-11-20 08:40:06'),
(74,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 08:40:06'),
(75,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:40:10'),
(76,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 08:40:15'),
(77,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:40:15'),
(78,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/delete/1','http://localhost:8080/index.php/laporan/delete/1','GET','2025-11-20 08:40:26'),
(79,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:40:26'),
(80,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:40:30'),
(81,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:40:32'),
(82,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:42:26'),
(83,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:43:04'),
(84,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:43:43'),
(85,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:44:23'),
(86,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store-permintaan','http://localhost:8080/index.php/laporan/store-permintaan','POST','2025-11-20 08:44:37'),
(87,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:44:37'),
(88,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:45:43'),
(89,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store-permintaan','http://localhost:8080/index.php/laporan/store-permintaan','POST','2025-11-20 08:46:02'),
(90,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:46:03'),
(91,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store-permintaan','http://localhost:8080/index.php/laporan/store-permintaan','POST','2025-11-20 08:46:21'),
(92,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 08:46:21'),
(93,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store-permintaan','http://localhost:8080/index.php/laporan/store-permintaan','POST','2025-11-20 08:47:57'),
(94,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:47:58'),
(95,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 08:48:05'),
(96,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 08:48:05'),
(97,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 08:48:15'),
(98,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 08:48:16'),
(99,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 08:48:19'),
(100,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit/detail/1','http://localhost:8080/index.php/kepaladinas/permintaan-edit/detail/1','GET','2025-11-20 08:48:21'),
(101,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','kepaladinas/permintaan-edit/proses/1','http://localhost:8080/index.php/kepaladinas/permintaan-edit/proses/1','POST','2025-11-20 08:48:40'),
(102,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 08:48:40'),
(103,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:48:51'),
(104,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:48:58'),
(105,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:49:07'),
(106,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 08:49:13'),
(107,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:52:34'),
(108,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 08:54:50'),
(109,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:55:21'),
(110,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:55:57'),
(111,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:56:06'),
(112,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:56:39'),
(113,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:59:16'),
(114,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 08:59:42'),
(115,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:00:27'),
(116,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:00:58'),
(117,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:01:25'),
(118,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 09:01:37'),
(119,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:01:40'),
(120,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:01:42'),
(121,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 09:01:53'),
(122,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:05:16'),
(123,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:05:51'),
(124,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:06:04'),
(125,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:09:37'),
(126,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:10:46'),
(127,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:10:58'),
(128,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:11:30'),
(129,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:12:14'),
(130,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:12:40'),
(131,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:13:21'),
(132,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:13:50'),
(133,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:13:52'),
(134,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:13:52'),
(135,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:14:06'),
(136,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:14:06'),
(137,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 09:15:21'),
(138,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:15:23'),
(139,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 09:15:25'),
(140,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/index.php/laporan/store','POST','2025-11-20 09:15:50'),
(141,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:15:50'),
(142,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/2','http://localhost:8080/index.php/laporan/edit/2','GET','2025-11-20 09:15:58'),
(143,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:16:01'),
(144,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:16:25'),
(145,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 09:16:27'),
(146,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store-permintaan','http://localhost:8080/index.php/laporan/store-permintaan','POST','2025-11-20 09:22:52'),
(147,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:22:52'),
(148,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:23:10'),
(149,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit/detail/2','http://localhost:8080/index.php/kepaladinas/permintaan-edit/detail/2','GET','2025-11-20 09:23:13'),
(150,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:27:29'),
(151,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:27:31'),
(152,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit/detail/2','http://localhost:8080/index.php/kepaladinas/permintaan-edit/detail/2','GET','2025-11-20 09:27:38'),
(153,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit/detail/2','http://localhost:8080/index.php/kepaladinas/permintaan-edit/detail/2','GET','2025-11-20 09:34:18'),
(154,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','kepaladinas/permintaan-edit/proses/2','http://localhost:8080/index.php/kepaladinas/permintaan-edit/proses/2','POST','2025-11-20 09:34:24'),
(155,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:34:24'),
(156,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:34:34'),
(157,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:34:39'),
(158,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:35:46'),
(159,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:36:53'),
(160,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:36:55'),
(161,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:36:55'),
(162,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:37:03'),
(163,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:37:03'),
(164,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:38:26'),
(165,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:38:28'),
(166,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/update/1','http://localhost:8080/index.php/laporan/update/1','POST','2025-11-20 09:38:52'),
(167,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:38:52'),
(168,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:39:46'),
(169,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:39:48'),
(170,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/update/1','http://localhost:8080/index.php/laporan/update/1','POST','2025-11-20 09:40:02'),
(171,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:40:03'),
(172,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:41:08'),
(173,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/update/1','http://localhost:8080/index.php/laporan/update/1','POST','2025-11-20 09:41:15'),
(174,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:41:15'),
(175,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:42:48'),
(176,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/laporan-semua','http://localhost:8080/index.php/kepaladinas/laporan-semua','GET','2025-11-20 09:43:03'),
(177,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/laporan-semua','http://localhost:8080/index.php/kepaladinas/laporan-semua','GET','2025-11-20 09:43:07'),
(178,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/riwayat-permintaan','http://localhost:8080/index.php/kepaladinas/riwayat-permintaan','GET','2025-11-20 09:43:08'),
(179,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:43:09'),
(180,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/riwayat-permintaan','http://localhost:8080/index.php/kepaladinas/riwayat-permintaan','GET','2025-11-20 09:43:11'),
(181,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:43:14'),
(182,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/ajukan-permintaan','http://localhost:8080/index.php/laporan/ajukan-permintaan','GET','2025-11-20 09:43:15'),
(183,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store-permintaan','http://localhost:8080/index.php/laporan/store-permintaan','POST','2025-11-20 09:43:25'),
(184,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:43:25'),
(185,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:43:30'),
(186,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit/detail/3','http://localhost:8080/index.php/kepaladinas/permintaan-edit/detail/3','GET','2025-11-20 09:43:31'),
(187,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','kepaladinas/permintaan-edit/proses/3','http://localhost:8080/index.php/kepaladinas/permintaan-edit/proses/3','POST','2025-11-20 09:43:35'),
(188,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/index.php/kepaladinas/permintaan-edit','GET','2025-11-20 09:43:35'),
(189,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:43:38'),
(190,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:43:46'),
(191,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 09:43:48'),
(192,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:43:53'),
(193,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/edit/1','http://localhost:8080/index.php/laporan/edit/1','GET','2025-11-20 09:43:58'),
(194,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 09:43:58'),
(195,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:44:05'),
(196,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 09:49:02'),
(197,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 09:49:04'),
(198,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/permintaan','http://localhost:8080/index.php/laporan/permintaan','GET','2025-11-20 10:00:46'),
(199,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create/3','http://localhost:8080/index.php/laporan/create/3','GET','2025-11-20 10:00:48'),
(200,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/index.php/laporan/create','GET','2025-11-20 10:00:56'),
(201,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create/3','http://localhost:8080/index.php/laporan/create/3','GET','2025-11-20 10:01:02'),
(202,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create/3','http://localhost:8080/index.php/laporan/create/3','GET','2025-11-20 10:02:28'),
(203,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan/create/3','http://localhost:8080/index.php/laporan/create/3','GET','2025-11-20 10:03:59'),
(204,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/index.php/laporan/store','POST','2025-11-20 10:04:14'),
(205,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 10:04:14'),
(206,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/index.php/laporan','GET','2025-11-20 10:07:38'),
(207,4,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 10:07:42'),
(208,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 10:07:43'),
(209,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 10:08:39'),
(210,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:08:41'),
(211,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:09:30'),
(212,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 10:09:31'),
(213,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:18:24'),
(214,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:18:49'),
(215,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:19:33'),
(216,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:20:21'),
(217,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:22:07'),
(218,3,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/index.php/logout','GET','2025-11-20 10:22:45'),
(219,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','login','http://localhost:8080/index.php/login','GET','2025-11-20 10:22:45'),
(220,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','login','http://localhost:8080/index.php/login','POST','2025-11-20 10:22:50'),
(221,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/index.php/dashboard','GET','2025-11-20 10:22:50'),
(222,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 10:22:52'),
(223,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/2','http://localhost:8080/index.php/sekretaris/verifikasi/detail/2','GET','2025-11-20 10:22:55'),
(224,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','sekretaris/verifikasi/proses/2','http://localhost:8080/index.php/sekretaris/verifikasi/proses/2','POST','2025-11-20 10:23:03'),
(225,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 10:23:03'),
(226,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:23:09'),
(227,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:25:54'),
(228,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:26:03'),
(229,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:26:19'),
(230,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:26:29'),
(231,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:26:46'),
(232,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:26:54'),
(233,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:28:35'),
(234,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','','http://localhost:8080/index.php/','GET','2025-11-20 10:31:37'),
(235,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','home/getByDate','http://localhost:8080/index.php/home/getByDate','GET','2025-11-20 10:32:07'),
(236,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','home/getByDate','http://localhost:8080/index.php/home/getByDate','GET','2025-11-20 10:32:10'),
(237,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/3','http://localhost:8080/index.php/sekretaris/verifikasi/detail/3','GET','2025-11-20 10:32:24'),
(238,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','POST','sekretaris/verifikasi/proses/3','http://localhost:8080/index.php/sekretaris/verifikasi/proses/3','POST','2025-11-20 10:32:27'),
(239,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/index.php/sekretaris/verifikasi','GET','2025-11-20 10:32:27'),
(240,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','GET','home/getByDate','http://localhost:8080/index.php/home/getByDate','GET','2025-11-20 10:32:33'),
(241,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:11:16'),
(242,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:11:16'),
(243,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:11:16'),
(244,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:11:18'),
(245,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:01'),
(246,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:14'),
(247,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:14'),
(248,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:15'),
(249,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:31'),
(250,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:32'),
(251,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:13:33'),
(252,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:14:16'),
(253,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:14:18'),
(254,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:15:35'),
(255,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:16:04'),
(256,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:16:04'),
(257,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:16:19'),
(258,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:16:19'),
(259,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:16:31'),
(260,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:16:31'),
(261,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:16:34'),
(262,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:16:35'),
(263,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:16:36'),
(264,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:16:36'),
(265,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:16:38'),
(266,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:16:43'),
(267,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:13'),
(268,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:15'),
(269,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:19'),
(270,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:20'),
(271,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:21'),
(272,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:21'),
(273,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:21'),
(274,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:22'),
(275,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:22'),
(276,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:17:22'),
(277,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:18:28'),
(278,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:19:55'),
(279,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 12:20:28'),
(280,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:51:13'),
(281,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:02'),
(282,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:04'),
(283,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:05'),
(284,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:07'),
(285,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:08'),
(286,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:09'),
(287,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:23'),
(288,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:24'),
(289,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:52:48'),
(290,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:53:16'),
(291,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:53:18'),
(292,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:53:19'),
(293,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:53:40'),
(294,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:54:07'),
(295,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 12:54:10'),
(296,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:54:56'),
(297,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:55:13'),
(298,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:55:13'),
(299,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:55:17'),
(300,3,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 12:55:17'),
(301,3,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','kepaladinas/permintaan-edit','http://localhost:8080/kepaladinas/permintaan-edit','GET','2026-02-13 12:55:19'),
(302,3,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','kepaladinas/riwayat-permintaan','http://localhost:8080/kepaladinas/riwayat-permintaan','GET','2026-02-13 12:55:20'),
(303,3,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/logout','GET','2026-02-13 12:55:31'),
(304,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:55:31'),
(305,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:55:54'),
(306,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:55:54'),
(307,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 12:55:58'),
(308,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 12:55:58'),
(309,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:56:20'),
(310,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:56:21'),
(311,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:56:27'),
(312,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 12:56:30'),
(313,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:58:03'),
(314,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:58:05'),
(315,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 12:58:14'),
(316,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:58:29'),
(317,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:58:36'),
(318,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 12:58:44'),
(319,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:59:07'),
(320,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:59:09'),
(321,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 12:59:10'),
(322,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 12:59:18'),
(323,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:01:09'),
(324,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:01:10'),
(325,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:01:12'),
(326,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:05:38'),
(327,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:05:41'),
(328,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:07:39'),
(329,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:07:44'),
(330,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:07:46'),
(331,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:07:48'),
(332,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:09:14'),
(333,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:09:17'),
(334,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:09:18'),
(335,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:09:26'),
(336,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:09:26'),
(337,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:09:39'),
(338,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:09:39'),
(339,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:09:59'),
(340,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:10:01'),
(341,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:10:01'),
(342,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:10:05'),
(343,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 13:10:06'),
(344,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/bidang','http://localhost:8080/superadmin/bidang','GET','2026-02-13 13:10:07'),
(345,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:10:16'),
(346,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','superadmin/users/edit/4','http://localhost:8080/superadmin/users/edit/4','POST','2026-02-13 13:10:24'),
(347,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:10:24'),
(348,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 13:10:28'),
(349,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:10:35'),
(350,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/bidang','http://localhost:8080/superadmin/bidang','GET','2026-02-13 13:10:57'),
(351,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:10:58'),
(352,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users/hapus/2','http://localhost:8080/superadmin/users/hapus/2','GET','2026-02-13 13:11:52'),
(353,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:11:52'),
(354,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','superadmin/users/tambah','http://localhost:8080/superadmin/users/tambah','POST','2026-02-13 13:12:01'),
(355,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:12:01'),
(356,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','superadmin/users/tambah','http://localhost:8080/superadmin/users/tambah','POST','2026-02-13 13:12:16'),
(357,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','superadmin/users','http://localhost:8080/superadmin/users','GET','2026-02-13 13:12:16'),
(358,5,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/logout','GET','2026-02-13 13:12:21'),
(359,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:12:21'),
(360,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:12:25'),
(361,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 13:12:25'),
(362,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/laporan','GET','2026-02-13 13:12:26'),
(363,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/laporan/create','GET','2026-02-13 13:12:30'),
(364,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/laporan/store','POST','2026-02-13 13:12:42'),
(365,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/laporan/create','GET','2026-02-13 13:12:42'),
(366,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/laporan/store','POST','2026-02-13 13:12:53'),
(367,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/laporan/create','GET','2026-02-13 13:12:54'),
(368,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/laporan/store','POST','2026-02-13 13:13:04'),
(369,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/laporan','GET','2026-02-13 13:13:04'),
(370,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/logout','GET','2026-02-13 13:13:07'),
(371,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:13:07'),
(372,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:13:11'),
(373,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 13:13:12'),
(374,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/sekretaris/verifikasi','GET','2026-02-13 13:13:13'),
(375,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/4','http://localhost:8080/sekretaris/verifikasi/detail/4','GET','2026-02-13 13:13:16'),
(376,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/sekretaris/verifikasi','GET','2026-02-13 13:13:22'),
(377,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/1','http://localhost:8080/sekretaris/verifikasi/detail/1','GET','2026-02-13 13:13:24'),
(378,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/sekretaris/verifikasi','GET','2026-02-13 13:13:29'),
(379,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/4','http://localhost:8080/sekretaris/verifikasi/detail/4','GET','2026-02-13 13:13:31'),
(380,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','sekretaris/verifikasi/proses/4','http://localhost:8080/sekretaris/verifikasi/proses/4','POST','2026-02-13 13:13:47'),
(381,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/sekretaris/verifikasi','GET','2026-02-13 13:13:47'),
(382,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/logout','GET','2026-02-13 13:13:53'),
(383,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:13:53'),
(384,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:13:57'),
(385,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:14:03'),
(386,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:16:13'),
(387,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:16:34'),
(388,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:17:14'),
(389,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:17:16'),
(390,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:17:29'),
(391,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:17:35'),
(392,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:18:43'),
(393,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:19:07'),
(394,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:19:12'),
(395,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:19:16'),
(396,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:20:35'),
(397,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:20:40'),
(398,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 13:20:40'),
(399,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/laporan','GET','2026-02-13 13:20:41'),
(400,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan/create','http://localhost:8080/laporan/create','GET','2026-02-13 13:20:42'),
(401,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','laporan/store','http://localhost:8080/laporan/store','POST','2026-02-13 13:20:54'),
(402,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','laporan','http://localhost:8080/laporan','GET','2026-02-13 13:20:54'),
(403,4,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/logout','GET','2026-02-13 13:20:56'),
(404,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:20:56'),
(405,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:21:01'),
(406,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:21:01'),
(407,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','login','http://localhost:8080/login','POST','2026-02-13 13:21:05'),
(408,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','dashboard','http://localhost:8080/dashboard','GET','2026-02-13 13:21:05'),
(409,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/sekretaris/verifikasi','GET','2026-02-13 13:21:07'),
(410,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi/detail/5','http://localhost:8080/sekretaris/verifikasi/detail/5','GET','2026-02-13 13:21:08'),
(411,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','POST','sekretaris/verifikasi/proses/5','http://localhost:8080/sekretaris/verifikasi/proses/5','POST','2026-02-13 13:21:13'),
(412,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','sekretaris/verifikasi','http://localhost:8080/sekretaris/verifikasi','GET','2026-02-13 13:21:13'),
(413,6,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','logout','http://localhost:8080/logout','GET','2026-02-13 13:21:15'),
(414,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','login','http://localhost:8080/login','GET','2026-02-13 13:21:15'),
(415,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:21:19'),
(416,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:22:14'),
(417,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:22:51'),
(418,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:22:52'),
(419,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:23:05'),
(420,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:23:08'),
(421,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:23:11'),
(422,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:23:13'),
(423,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:23:27'),
(424,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:24:03'),
(425,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:24:12'),
(426,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:24:22'),
(427,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:24:23'),
(428,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:24:25'),
(429,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:24:35'),
(430,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:24:37'),
(431,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:26:02'),
(432,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:26:10'),
(433,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:26:15'),
(434,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:26:18'),
(435,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:26:24'),
(436,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:26:52'),
(437,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:08'),
(438,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:10'),
(439,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:11'),
(440,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:12'),
(441,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:24'),
(442,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:25'),
(443,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:27:27'),
(444,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:21'),
(445,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:24'),
(446,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:31'),
(447,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:35'),
(448,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:41'),
(449,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:44'),
(450,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:28:47'),
(451,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:29:00'),
(452,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:30:08'),
(453,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:30:10'),
(454,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:30:48'),
(455,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:31:12'),
(456,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:31:13'),
(457,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:31:18'),
(458,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:30'),
(459,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:32'),
(460,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:32'),
(461,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:33'),
(462,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:34'),
(463,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:34'),
(464,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:34'),
(465,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:47'),
(466,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:52'),
(467,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:53'),
(468,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:32:56'),
(469,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:33:10'),
(470,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:33:28'),
(471,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:33:29'),
(472,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:33:33'),
(473,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:33:34'),
(474,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:34:01'),
(475,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:34:07'),
(476,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:34:14'),
(477,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:34:16'),
(478,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:34:17'),
(479,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:34:48'),
(480,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:34:51'),
(481,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:35:20'),
(482,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:35:21'),
(483,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:35:22'),
(484,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:35:25'),
(485,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:35:48'),
(486,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:36:39'),
(487,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:37:01'),
(488,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:37:09'),
(489,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:37:09'),
(490,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:37:15'),
(491,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:37:16'),
(492,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:38:25'),
(493,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:38:32'),
(494,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:38:33'),
(495,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:38:39'),
(496,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:38:44'),
(497,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:38:48'),
(498,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:38:54'),
(499,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:40:15'),
(500,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:40:16'),
(501,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:40:21'),
(502,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:40:22'),
(503,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:40:28'),
(504,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:40:29'),
(505,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:40:35'),
(506,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:43:27'),
(507,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:43:39'),
(508,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:43:57'),
(509,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:44:03'),
(510,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:44:05'),
(511,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:46:13'),
(512,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:46:15'),
(513,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:46:20'),
(514,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:46:26'),
(515,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:47:34'),
(516,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:47:37'),
(517,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:50:05'),
(518,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:50:06'),
(519,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:50:07'),
(520,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:50:17'),
(521,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:50:18'),
(522,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:50:57'),
(523,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:50:58'),
(524,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:51:15'),
(525,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:51:17'),
(526,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:52:09'),
(527,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:52:12'),
(528,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:53:12'),
(529,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','home/downloadPDF','http://localhost:8080/home/downloadPDF','GET','2026-02-13 13:53:15'),
(530,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:55:40'),
(531,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:55:48'),
(532,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-02-13 13:56:05'),
(533,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-02-13 13:56:16'),
(534,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-03-03 22:03:04'),
(535,NULL,'::1','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/17.5 Mobile/15A5370a Safari/602.1','GET','','http://localhost:8080/','GET','2026-03-03 22:03:29'),
(536,NULL,'::1','Mozilla/5.0 (Linux; Android 12; Surface Duo) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.35 Mobile Safari/537.36 EdgA/45.11.4.5118','GET','','http://localhost:8080/','GET','2026-03-03 22:03:40'),
(537,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-03-04 00:59:15'),
(538,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-03-04 01:02:31'),
(539,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','GET','','http://localhost:8080/','GET','2026-03-04 01:02:33');
/*!40000 ALTER TABLE `log_activity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `permintaan_edit`
--

DROP TABLE IF EXISTS `permintaan_edit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permintaan_edit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `laporan_id` int(11) DEFAULT NULL,
  `tanggal_target` date NOT NULL,
  `jenis_permintaan` enum('tambah','edit','hapus') NOT NULL,
  `alasan` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `catatan_approval` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `laporan_id` (`laporan_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `permintaan_edit_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permintaan_edit_ibfk_2` FOREIGN KEY (`laporan_id`) REFERENCES `laporan_kinerja` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permintaan_edit_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permintaan_edit`
--

LOCK TABLES `permintaan_edit` WRITE;
/*!40000 ALTER TABLE `permintaan_edit` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `permintaan_edit` VALUES
(2,4,1,'0000-00-00','edit','asdasdasd asd ','approved',3,'2025-11-20 01:34:24','asdasdasd','2025-11-20 09:22:52','2025-11-20 09:34:24'),
(3,4,NULL,'2025-11-04','tambah','asd as da sd','approved',3,'2025-11-20 01:43:35','','2025-11-20 09:43:25','2025-11-20 09:43:35');
/*!40000 ALTER TABLE `permintaan_edit` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `security_logs`
--

DROP TABLE IF EXISTS `security_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` enum('login_failed','suspicious_activity','blocked_ip','sql_injection_attempt','xss_attempt') NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `severity` enum('low','medium','high','critical') DEFAULT 'medium',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_logs`
--

LOCK TABLES `security_logs` WRITE;
/*!40000 ALTER TABLE `security_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `security_logs` VALUES
(1,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: superadmin','medium','2026-02-13 12:16:04'),
(2,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: superadmin','medium','2026-02-13 12:16:19'),
(3,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: gilang','medium','2026-02-13 12:16:31'),
(4,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: Adrianto','medium','2026-02-13 12:55:13'),
(5,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: superadmin','medium','2026-02-13 12:55:54'),
(6,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: superadmin','medium','2026-02-13 12:55:58'),
(7,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: gilang','medium','2026-02-13 13:09:18'),
(8,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: gilang','medium','2026-02-13 13:09:26'),
(9,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: gilang','medium','2026-02-13 13:09:39'),
(10,'login_failed','::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','Failed login attempt for username: aqil','medium','2026-02-13 13:21:01');
/*!40000 ALTER TABLE `security_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` enum('super_admin','kepala_dinas','sekretaris','admin_bidang') NOT NULL,
  `bidang_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `bidang_id` (`bidang_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`bidang_id`) REFERENCES `bidang` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(3,'Adrianto','$2y$10$7MOJx6Z8c46ByJB/zFcfR.fbS3DKmyMLhfs6nocnGLDn0IMPOnWC.','Adrinto Wicaksono','kepala_dinas',NULL,1,'2025-11-20 08:31:28','2025-11-20 08:31:28'),
(4,'gilang','$2y$12$4YEy/zouDZYDuF2iCBKw.uniCyAKXWaXVJWP7Agvc0Nvf/JMCQKJW','Gilang Rizky Ramadhan','admin_bidang',1,1,'2025-11-20 08:31:43','2026-02-13 13:10:24'),
(5,'superadmin','$2y$12$c7Mvnk8TLBVeIH.Wuzey3.TBqC.qb58FeP0tTFdpwEh/GvbUE8wGq','Super Admin','super_admin',NULL,1,'2026-02-13 05:09:49','2026-02-13 05:09:49'),
(6,'aqil','$2y$12$NvWzB0e.fLTy5Wwv6q1D5O4WR3UA/AXA3qnrC6AjqmpK34yBC2uMi','Aqil','sekretaris',NULL,1,'2026-02-13 13:12:16','2026-02-13 13:12:16');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-06 18:52:56
