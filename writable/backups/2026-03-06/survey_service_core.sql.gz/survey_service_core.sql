/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.1-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: survey_service_core
-- ------------------------------------------------------
-- Server version	11.8.1-MariaDB-4deepin1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `ai_anomaly_detection`
--

DROP TABLE IF EXISTS `ai_anomaly_detection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_anomaly_detection` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` bigint(20) unsigned NOT NULL,
  `anomaly_type` enum('speed','pattern','duplicate') NOT NULL,
  `severity` enum('low','medium','high','critical') NOT NULL DEFAULT 'low',
  `description` text DEFAULT NULL,
  `confidence_score` decimal(5,4) DEFAULT NULL,
  `auto_flagged` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_anomaly_detection_response_id_index` (`response_id`),
  CONSTRAINT `ai_anomaly_detection_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_anomaly_detection`
--

LOCK TABLES `ai_anomaly_detection` WRITE;
/*!40000 ALTER TABLE `ai_anomaly_detection` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `ai_anomaly_detection` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ai_chat_conversations`
--

DROP TABLE IF EXISTS `ai_chat_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_chat_conversations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `session_id` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `response` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `intent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ai_chat_conversations_tenant_id_foreign` (`tenant_id`),
  KEY `ai_chat_conversations_user_id_foreign` (`user_id`),
  KEY `ai_chat_conversations_session_id_index` (`session_id`),
  CONSTRAINT `ai_chat_conversations_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_chat_conversations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_chat_conversations`
--

LOCK TABLES `ai_chat_conversations` WRITE;
/*!40000 ALTER TABLE `ai_chat_conversations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ai_chat_conversations` VALUES
(1,2,1,'yHFnOg8CJS','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:07'),
(2,3,1,'MvMIdj4yqi','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:07'),
(3,4,1,'RnD4OdHTds','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:08'),
(4,5,1,'kecBhRPcyN','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:08'),
(5,6,1,'n2G7BxTkiS','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:08'),
(6,7,1,'Wxne2tW4Ej','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:09'),
(7,8,1,'UVI3AKDMbj','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:09'),
(8,9,1,'S3LJTDA3P3','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:09'),
(9,10,1,'YS07xCWs02','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:10'),
(10,11,1,'qA2ipJohyx','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:56:10'),
(11,2,1,'vlRMc20ooV','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:04'),
(12,3,1,'XEnnGGz83L','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:04'),
(13,4,1,'3yJD1Os7nD','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:05'),
(14,5,1,'SpDxq1BKUR','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:05'),
(15,6,1,'XN7Pnoif6R','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:05'),
(16,7,1,'mXYjWcKOa5','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:06'),
(17,8,1,'baIFECB5D0','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:06'),
(18,9,1,'ZK1crpkpfX','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:06'),
(19,10,1,'fucS1iZcVO','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:07'),
(20,11,1,'ztHv3Q4x5p','Apa keluhan utama dari masyarakat bulan ini?','Keluhan utama adalah mengenai waktu tunggu di pagi hari antara jam 08:00 - 10:00.',NULL,'complaint_analysis','2026-02-17 05:57:07');
/*!40000 ALTER TABLE `ai_chat_conversations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ai_insights`
--

DROP TABLE IF EXISTS `ai_insights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_insights` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `insight_type` enum('summary','recommendation','trend') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `confidence_score` decimal(5,4) DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_insights_survey_id_foreign` (`survey_id`),
  CONSTRAINT `ai_insights_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_insights`
--

LOCK TABLES `ai_insights` WRITE;
/*!40000 ALTER TABLE `ai_insights` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ai_insights` VALUES
(1,3,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:55:22','2026-02-17 04:55:22','2026-02-17 04:55:22'),
(2,4,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(3,5,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(4,6,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(5,7,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(6,8,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(7,9,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(8,10,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(9,11,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(10,12,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(11,13,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(12,14,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(13,15,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(14,16,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(15,17,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(16,18,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(17,19,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(18,20,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(19,21,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(20,22,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07'),
(21,23,'summary','Ringkasan Kepuasan Layanan','Mayoritas responden merasa puas dengan kecepatan layanan, namun mencatat perlunya perbaikan pada fasilitas fisik.',NULL,0.9200,'2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `ai_insights` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ai_keyword_extraction`
--

DROP TABLE IF EXISTS `ai_keyword_extraction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_keyword_extraction` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `question_id` bigint(20) unsigned NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `frequency` int(11) NOT NULL DEFAULT 1,
  `relevance_score` decimal(5,4) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ai_keyword_extraction_question_id_foreign` (`question_id`),
  KEY `ai_keyword_extraction_survey_id_index` (`survey_id`),
  KEY `ai_keyword_extraction_keyword_index` (`keyword`),
  CONSTRAINT `ai_keyword_extraction_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_keyword_extraction_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_keyword_extraction`
--

LOCK TABLES `ai_keyword_extraction` WRITE;
/*!40000 ALTER TABLE `ai_keyword_extraction` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `ai_keyword_extraction` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ai_sentiment_analysis`
--

DROP TABLE IF EXISTS `ai_sentiment_analysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_sentiment_analysis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` bigint(20) unsigned NOT NULL,
  `question_id` bigint(20) unsigned NOT NULL,
  `answer_id` bigint(20) unsigned NOT NULL,
  `text_content` text NOT NULL,
  `sentiment` enum('positive','neutral','negative') NOT NULL,
  `confidence_score` decimal(5,4) NOT NULL,
  `emotion` enum('joy','sadness','anger','fear','surprise','neutral') DEFAULT NULL,
  `processed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_sentiment_analysis_question_id_foreign` (`question_id`),
  KEY `ai_sentiment_analysis_answer_id_foreign` (`answer_id`),
  KEY `ai_sentiment_analysis_response_id_index` (`response_id`),
  KEY `ai_sentiment_analysis_sentiment_index` (`sentiment`),
  CONSTRAINT `ai_sentiment_analysis_answer_id_foreign` FOREIGN KEY (`answer_id`) REFERENCES `response_answers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_sentiment_analysis_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_sentiment_analysis_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_sentiment_analysis`
--

LOCK TABLES `ai_sentiment_analysis` WRITE;
/*!40000 ALTER TABLE `ai_sentiment_analysis` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ai_sentiment_analysis` VALUES
(1,1,4,4,'Layanan sangat baik, mohon dipertahankan.','positive',0.9400,'joy','2026-02-17 05:53:23','2026-02-17 04:53:23','2026-02-17 04:53:23'),
(2,2,4,8,'Layanan sangat baik, mohon dipertahankan.','positive',0.8900,'neutral','2026-02-17 05:53:23','2026-02-17 04:53:23','2026-02-17 04:53:23'),
(3,3,4,12,'Layanan sangat membantu, mohon dipertahankan.','positive',0.9400,'neutral','2026-02-17 05:53:23','2026-02-17 04:53:23','2026-02-17 04:53:23'),
(4,4,4,16,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.8800,'neutral','2026-02-17 05:53:23','2026-02-17 04:53:23','2026-02-17 04:53:23'),
(5,5,4,20,'Layanan sangat baik, mohon dipertahankan.','positive',0.7700,'neutral','2026-02-17 05:53:23','2026-02-17 04:53:23','2026-02-17 04:53:23'),
(6,6,8,24,'Layanan sangat cepat, mohon dipertahankan.','negative',0.8600,'joy','2026-02-17 05:54:53','2026-02-17 04:54:53','2026-02-17 04:54:53'),
(7,7,8,28,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.9100,'joy','2026-02-17 05:54:53','2026-02-17 04:54:53','2026-02-17 04:54:53'),
(8,8,8,32,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8600,'neutral','2026-02-17 05:54:53','2026-02-17 04:54:53','2026-02-17 04:54:53'),
(9,9,8,36,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7100,'surprise','2026-02-17 05:54:53','2026-02-17 04:54:53','2026-02-17 04:54:53'),
(10,10,8,40,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.8000,'neutral','2026-02-17 05:54:53','2026-02-17 04:54:53','2026-02-17 04:54:53'),
(11,11,12,44,'Layanan sangat membantu, mohon dipertahankan.','neutral',0.7700,'neutral','2026-02-17 05:55:21','2026-02-17 04:55:21','2026-02-17 04:55:21'),
(12,12,12,48,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7400,'neutral','2026-02-17 05:55:21','2026-02-17 04:55:21','2026-02-17 04:55:21'),
(13,13,12,52,'Layanan sangat cepat, mohon dipertahankan.','negative',0.8900,'surprise','2026-02-17 05:55:21','2026-02-17 04:55:21','2026-02-17 04:55:21'),
(14,14,12,56,'Layanan sangat baik, mohon dipertahankan.','neutral',0.7600,'surprise','2026-02-17 05:55:21','2026-02-17 04:55:21','2026-02-17 04:55:21'),
(15,15,12,60,'Layanan sangat cepat, mohon dipertahankan.','negative',0.9900,'joy','2026-02-17 05:55:21','2026-02-17 04:55:21','2026-02-17 04:55:21'),
(16,16,16,64,'Layanan sangat bagus, mohon dipertahankan.','negative',0.8000,'surprise','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(17,17,16,68,'Layanan sangat membantu, mohon dipertahankan.','positive',0.8300,'surprise','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(18,18,16,72,'Layanan sangat membantu, mohon dipertahankan.','positive',0.9100,'surprise','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(19,19,16,76,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.7400,'neutral','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(20,20,16,80,'Layanan sangat baik, mohon dipertahankan.','negative',0.9700,'joy','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(21,21,20,84,'Layanan sangat membantu, mohon dipertahankan.','negative',0.9200,'joy','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(22,22,20,88,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.7600,'neutral','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(23,23,20,92,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8400,'neutral','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(24,24,20,96,'Layanan sangat bagus, mohon dipertahankan.','positive',0.9300,'neutral','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(25,25,20,100,'Layanan sangat bagus, mohon dipertahankan.','negative',0.9400,'surprise','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(26,26,24,104,'Layanan sangat baik, mohon dipertahankan.','neutral',0.8900,'joy','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(27,27,24,108,'Layanan sangat cepat, mohon dipertahankan.','positive',0.9400,'surprise','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(28,28,24,112,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8100,'surprise','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(29,29,24,116,'Layanan sangat cepat, mohon dipertahankan.','positive',0.7500,'neutral','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(30,30,24,120,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.7100,'neutral','2026-02-17 05:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(31,31,28,124,'Layanan sangat baik, mohon dipertahankan.','positive',0.7400,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(32,32,28,128,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.8900,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(33,33,28,132,'Layanan sangat membantu, mohon dipertahankan.','positive',0.7900,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(34,34,28,136,'Layanan sangat baik, mohon dipertahankan.','neutral',0.8600,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(35,35,28,140,'Layanan sangat baik, mohon dipertahankan.','neutral',0.8000,'joy','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(36,36,32,144,'Layanan sangat cepat, mohon dipertahankan.','negative',0.9400,'joy','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(37,37,32,148,'Layanan sangat membantu, mohon dipertahankan.','positive',0.8700,'joy','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(38,38,32,152,'Layanan sangat baik, mohon dipertahankan.','neutral',0.9500,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(39,39,32,156,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8100,'joy','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(40,40,32,160,'Layanan sangat bagus, mohon dipertahankan.','positive',0.8500,'joy','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(41,41,36,164,'Layanan sangat baik, mohon dipertahankan.','positive',0.8300,'surprise','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(42,42,36,168,'Layanan sangat membantu, mohon dipertahankan.','neutral',0.9200,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(43,43,36,172,'Layanan sangat baik, mohon dipertahankan.','negative',0.8100,'surprise','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(44,44,36,176,'Layanan sangat bagus, mohon dipertahankan.','negative',0.8600,'joy','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(45,45,36,180,'Layanan sangat baik, mohon dipertahankan.','positive',0.9800,'neutral','2026-02-17 05:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(46,46,40,184,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8300,'joy','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(47,47,40,188,'Layanan sangat cepat, mohon dipertahankan.','positive',0.8200,'neutral','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(48,48,40,192,'Layanan sangat bagus, mohon dipertahankan.','positive',0.8400,'joy','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(49,49,40,196,'Layanan sangat bagus, mohon dipertahankan.','negative',0.8100,'joy','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(50,50,40,200,'Layanan sangat bagus, mohon dipertahankan.','negative',0.7700,'surprise','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(51,51,44,204,'Layanan sangat bagus, mohon dipertahankan.','positive',0.9300,'neutral','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(52,52,44,208,'Layanan sangat baik, mohon dipertahankan.','positive',0.7500,'joy','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(53,53,44,212,'Layanan sangat baik, mohon dipertahankan.','positive',0.7200,'surprise','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(54,54,44,216,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.7400,'joy','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(55,55,44,220,'Layanan sangat membantu, mohon dipertahankan.','positive',0.7000,'neutral','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(56,56,48,224,'Layanan sangat cepat, mohon dipertahankan.','positive',0.7800,'joy','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(57,57,48,228,'Layanan sangat baik, mohon dipertahankan.','negative',0.7400,'surprise','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(58,58,48,232,'Layanan sangat cepat, mohon dipertahankan.','positive',0.9400,'neutral','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(59,59,48,236,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.7800,'surprise','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(60,60,48,240,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7100,'surprise','2026-02-17 05:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(61,61,52,244,'Layanan sangat cepat, mohon dipertahankan.','positive',0.8100,'surprise','2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(62,62,52,248,'Layanan sangat cepat, mohon dipertahankan.','negative',0.8900,'neutral','2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(63,63,52,252,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7900,'neutral','2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(64,64,52,256,'Layanan sangat baik, mohon dipertahankan.','negative',0.9500,'joy','2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(65,65,52,260,'Layanan sangat baik, mohon dipertahankan.','neutral',0.9500,'surprise','2026-02-17 05:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(66,66,56,264,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.9900,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(67,67,56,268,'Layanan sangat baik, mohon dipertahankan.','neutral',0.7700,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(68,68,56,272,'Layanan sangat baik, mohon dipertahankan.','positive',0.7500,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(69,69,56,276,'Layanan sangat baik, mohon dipertahankan.','positive',0.8400,'neutral','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(70,70,56,280,'Layanan sangat baik, mohon dipertahankan.','negative',0.9600,'joy','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(71,71,60,284,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.8000,'joy','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(72,72,60,288,'Layanan sangat baik, mohon dipertahankan.','neutral',0.8200,'neutral','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(73,73,60,292,'Layanan sangat bagus, mohon dipertahankan.','negative',0.7400,'neutral','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(74,74,60,296,'Layanan sangat membantu, mohon dipertahankan.','neutral',0.8000,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(75,75,60,300,'Layanan sangat cepat, mohon dipertahankan.','positive',0.7400,'joy','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(76,76,64,304,'Layanan sangat cepat, mohon dipertahankan.','negative',0.9300,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(77,77,64,308,'Layanan sangat cepat, mohon dipertahankan.','positive',0.7600,'joy','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(78,78,64,312,'Layanan sangat membantu, mohon dipertahankan.','positive',0.9100,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(79,79,64,316,'Layanan sangat baik, mohon dipertahankan.','positive',0.9400,'neutral','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(80,80,64,320,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.7200,'surprise','2026-02-17 05:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(81,81,68,324,'Layanan sangat baik, mohon dipertahankan.','neutral',0.9700,'surprise','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(82,82,68,328,'Layanan sangat bagus, mohon dipertahankan.','negative',0.8600,'neutral','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(83,83,68,332,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7900,'joy','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(84,84,68,336,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8200,'surprise','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(85,85,68,340,'Layanan sangat bagus, mohon dipertahankan.','negative',0.8200,'joy','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(86,86,72,344,'Layanan sangat baik, mohon dipertahankan.','negative',0.9500,'neutral','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(87,87,72,348,'Layanan sangat bagus, mohon dipertahankan.','negative',0.9300,'surprise','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(88,88,72,352,'Layanan sangat cepat, mohon dipertahankan.','positive',0.7200,'surprise','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(89,89,72,356,'Layanan sangat membantu, mohon dipertahankan.','negative',0.9900,'joy','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(90,90,72,360,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.9000,'neutral','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(91,91,76,364,'Layanan sangat membantu, mohon dipertahankan.','positive',0.7100,'surprise','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(92,92,76,368,'Layanan sangat membantu, mohon dipertahankan.','neutral',0.8800,'surprise','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(93,93,76,372,'Layanan sangat bagus, mohon dipertahankan.','positive',0.9100,'neutral','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(94,94,76,376,'Layanan sangat cepat, mohon dipertahankan.','negative',0.7800,'neutral','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(95,95,76,380,'Layanan sangat baik, mohon dipertahankan.','neutral',0.9600,'neutral','2026-02-17 05:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(96,96,80,384,'Layanan sangat baik, mohon dipertahankan.','negative',0.8600,'joy','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(97,97,80,388,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.7600,'joy','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(98,98,80,392,'Layanan sangat bagus, mohon dipertahankan.','positive',0.8700,'neutral','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(99,99,80,396,'Layanan sangat membantu, mohon dipertahankan.','negative',0.9900,'joy','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(100,100,80,400,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8100,'neutral','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(101,101,84,404,'Layanan sangat baik, mohon dipertahankan.','negative',0.9700,'surprise','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(102,102,84,408,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7100,'joy','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(103,103,84,412,'Layanan sangat bagus, mohon dipertahankan.','neutral',0.8700,'joy','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(104,104,84,416,'Layanan sangat cepat, mohon dipertahankan.','negative',0.8200,'surprise','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(105,105,84,420,'Layanan sangat baik, mohon dipertahankan.','negative',0.8400,'surprise','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(106,106,88,424,'Layanan sangat baik, mohon dipertahankan.','positive',0.9800,'neutral','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(107,107,88,428,'Layanan sangat membantu, mohon dipertahankan.','negative',0.9500,'surprise','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(108,108,88,432,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7100,'neutral','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(109,109,88,436,'Layanan sangat membantu, mohon dipertahankan.','negative',0.7300,'neutral','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(110,110,88,440,'Layanan sangat baik, mohon dipertahankan.','negative',0.7900,'neutral','2026-02-17 05:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(111,111,92,444,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.9400,'neutral','2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07'),
(112,112,92,448,'Layanan sangat cepat, mohon dipertahankan.','negative',0.8200,'surprise','2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07'),
(113,113,92,452,'Layanan sangat bagus, mohon dipertahankan.','positive',0.8800,'neutral','2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07'),
(114,114,92,456,'Layanan sangat cepat, mohon dipertahankan.','neutral',0.7900,'neutral','2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07'),
(115,115,92,460,'Layanan sangat baik, mohon dipertahankan.','negative',0.9400,'surprise','2026-02-17 05:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `ai_sentiment_analysis` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ai_settings`
--

DROP TABLE IF EXISTS `ai_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'persona',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ai_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_settings`
--

LOCK TABLES `ai_settings` WRITE;
/*!40000 ALTER TABLE `ai_settings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ai_settings` VALUES
(1,'system_prompt','System Instruction (Persona)','Anda adalah SurveiAI, asisten profesional resmi DPMPTSP Tanah Bumbu.\nAnda bertugas membantu masyarakat dengan memberikan informasi yang akurat, jelas, ramah, dan mudah dipahami terkait layanan perizinan dan non-perizinan.\n\nAnda harus berinteraksi secara natural seperti manusia, dengan gaya komunikasi profesional namun tetap hangat dan sopan. Gunakan bahasa Indonesia yang baik dan benar, tetapi tetap fleksibel mengikuti gaya bahasa pengguna (formal maupun semi-formal).\n\nPrinsip Perilaku SurveiAI:\n\nRamah dan Empatik\n\nSapa pengguna dengan sopan.\n\nTunjukkan empati jika pengguna mengalami kebingungan atau kesulitan.\n\nHindari jawaban kaku atau terlalu teknis tanpa penjelasan.\n\nJelas dan Informatif\n\nBerikan jawaban yang ringkas namun lengkap.\n\nJika pertanyaan kurang jelas, minta klarifikasi dengan sopan.\n\nGunakan poin-poin atau langkah-langkah jika menjelaskan prosedur.\n\nBerbasis Fakta dan Kebijakan\n\nHanya memberikan informasi yang sesuai dengan regulasi dan layanan resmi DPMPTSP Tanah Bumbu.\n\nJika informasi tidak tersedia, jawab dengan jujur dan arahkan ke petugas terkait.\n\nInteraktif\n\nAjukan pertanyaan lanjutan jika diperlukan untuk membantu pengguna lebih tepat.\n\nTawarkan bantuan tambahan setelah menjawab pertanyaan.\n\nBatasan\n\nTidak memberikan opini pribadi.\n\nTidak membahas isu politik, SARA, atau topik di luar lingkup layanan.\n\nTidak memberikan data pribadi atau informasi rahasia.','persona','Instruksi utama yang menentukan gaya bahasa dan identitas AI.',NULL,'2026-02-17 16:50:44'),
(2,'security_rules','Data Protection Rules','Aturan Utama:\n\nJANGAN PERNAH memberikan atau menampilkan data pribadi (PII) responden, termasuk namun tidak terbatas pada:\n\nNama lengkap\n\nNIK\n\nNomor HP\n\nEmail\n\nAlamat lengkap\n\nNomor dokumen perizinan yang bersifat pribadi\n\nData sensitif lainnya\n\nJika pengguna meminta data pribadi seseorang, jawab dengan sopan bahwa:\n\n\"Maaf, saya tidak dapat membagikan informasi pribadi demi menjaga keamanan dan privasi data.\"\n\nJangan menebak, mengarang, atau mengonfirmasi data pribadi meskipun pengguna mengklaim sebagai pemilik data tersebut.\n\nGunakan hanya informasi umum, prosedural, dan edukatif dalam setiap jawaban.\n\nJika percakapan mengandung data pribadi yang diketik oleh pengguna:\n\nJangan menyimpannya.\n\nJangan mengulanginya secara lengkap dalam jawaban.\n\nGunakan penyebutan umum seperti: “data yang Anda masukkan”.\n\nJika terjadi permintaan yang mencurigakan (misalnya meminta data orang lain, database, atau akses sistem internal), jawab dengan tegas namun sopan bahwa:\n\nInformasi tersebut tidak dapat diakses atau dibagikan.\n\nSarankan untuk menghubungi petugas resmi melalui kanal layanan DPMPTSP Tanah Bumbu.','security','Aturan ketat untuk melindungi privasi data.',NULL,'2026-02-17 16:52:06');
/*!40000 ALTER TABLE `ai_settings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `analytics_dashboard`
--

DROP TABLE IF EXISTS `analytics_dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_dashboard` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `survey_id` bigint(20) unsigned DEFAULT NULL,
  `dashboard_type` varchar(255) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `generated_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `analytics_dashboard_tenant_id_foreign` (`tenant_id`),
  KEY `analytics_dashboard_survey_id_foreign` (`survey_id`),
  CONSTRAINT `analytics_dashboard_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE SET NULL,
  CONSTRAINT `analytics_dashboard_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_dashboard`
--

LOCK TABLES `analytics_dashboard` WRITE;
/*!40000 ALTER TABLE `analytics_dashboard` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `analytics_dashboard` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `analytics_events`
--

DROP TABLE IF EXISTS `analytics_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `response_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` enum('view','start','answer','submit','dropoff') NOT NULL,
  `question_id` bigint(20) unsigned DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `analytics_events_response_id_foreign` (`response_id`),
  KEY `analytics_events_question_id_foreign` (`question_id`),
  KEY `analytics_events_survey_id_index` (`survey_id`),
  KEY `analytics_events_event_type_index` (`event_type`),
  KEY `analytics_events_created_at_index` (`created_at`),
  CONSTRAINT `analytics_events_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `analytics_events_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `analytics_events_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_events`
--

LOCK TABLES `analytics_events` WRITE;
/*!40000 ALTER TABLE `analytics_events` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `analytics_events` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `api_clients`
--

DROP TABLE IF EXISTS `api_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `client_id` varchar(100) NOT NULL,
  `client_secret` text NOT NULL,
  `redirect_uris` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`redirect_uris`)),
  `tier` enum('free','basic','premium','enterprise') NOT NULL DEFAULT 'free',
  `status` enum('active','suspended','revoked') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_clients_uuid_unique` (`uuid`),
  UNIQUE KEY `api_clients_client_id_unique` (`client_id`),
  KEY `api_clients_client_id_index` (`client_id`),
  KEY `api_clients_tenant_id_index` (`tenant_id`),
  KEY `api_clients_status_index` (`status`),
  CONSTRAINT `api_clients_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_clients`
--

LOCK TABLES `api_clients` WRITE;
/*!40000 ALTER TABLE `api_clients` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `api_clients` VALUES
(1,'d7f78a85-3bdf-44b1-a93a-6934a94a9314',2,'Aplikasi Internal - Dinas Pendidikan Jawa Barat','GrYRAfSCm5Np3UjJ','eyJpdiI6IldjY0NmL0VPdlN1T3g5TC9aUXkyQmc9PSIsInZhbHVlIjoiMC9YRzdmb1pvNER6MkxHVmtldDVzdjQ0eWJkVTBLUzlkMDFlM0NmU2NrZCtsRndaZU5NQmtORk92VG1td1ZNR2ZjMHBhSlFZc2xhcWpLK3lzMDNnN0E9PSIsIm1hYyI6ImUxMTQ0YjI1YTFiZmZkZTI1ZmM5NzdjNTFiMjZlMGI3NGYxN2UxZWU4NWZhMzc1NTM5MjY1ZGE5MDVhODMxNDUiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:53:23','2026-02-17 04:53:23',NULL),
(2,'a97121eb-4c26-4e13-a274-e3c7f130175c',2,'Aplikasi Internal - Dinas Pendidikan Jawa Barat','c9iLk8MKiRWZKz7t','eyJpdiI6ImNOd1NpOE1BMURHNVlvSlVuMUk2bEE9PSIsInZhbHVlIjoiRVVjbFJOdFFIVGZUUEpYN3hKTWJiNWg5ZDViMTFaL1QxdTkyOTgvRkNIQ0JKY3YrVXFtSG8vYTVaanBBYUhsckJ1cUFNN1N2ekU0OFpsK2Fna0d5QXc9PSIsIm1hYyI6ImQ4OTY5ZjUzZmQ1OWQ0MjQyMzRkZTdkNDk0NWQ4MjNjNGE0Mzc5YzY3N2JmMmEwYjViNDQ0MWZiYWU1ZTNjNWYiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:54:53','2026-02-17 04:54:53',NULL),
(3,'90d9d288-6982-4e9d-8ca9-fb2bc3fc6533',2,'Aplikasi Internal - Dinas Pendidikan Jawa Barat','3B3a1Uxgb5waXW8Z','eyJpdiI6InozczlySHZhVnEwck9oWEFhT3lCQlE9PSIsInZhbHVlIjoiRWZ2QUN2dkppcHdnZUxXOFZURFRNVy9kSmY4RTBPTS8xRlJDOWk2aDE1OXFPa1VmdWhUNGdDcW5zakhBRWp4ZFlXWVdRM2QwY1N0WFlCSElMdVNnd3c9PSIsIm1hYyI6IjE0ZDRiMTJlZTJjNGEzM2U5OWU2NTlkMmIzNmY1OTgwNmJkY2I5ZDAwZmJjMzYzOGFmMGJkM2IyZTE3OWE2YTciLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:55:22','2026-02-17 04:55:22',NULL),
(4,'65a2d4b7-099b-4b9f-b38f-26ef641db757',2,'Aplikasi Internal - Dinas Pendidikan Jawa Barat','sWpMpNu2kGfRwDLy','eyJpdiI6ImdTNTQ3M280Q0kxL1VEd1A3WDdpNGc9PSIsInZhbHVlIjoiSmJVd1hRWG1WZVc4c3dLWkxTZXloYTRQVXNHU3VoRVhMcUM1K2x6d1BQejY2c1RacWMwV3dMV3NscmtNVUs4T2lRMk1WODdLMzRyWWppZThJamFxWmc9PSIsIm1hYyI6IjhkNjkyOGI2MDA3MTE1MTVjZDk3YWU4NDc4NmNjNjkxMTBmOTI0ZTM5Yzc3NTM0Mzc0ODg2ZjIxMThlNjBiNmMiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(5,'1ae964f6-dc66-45be-99ea-f807abbbfd75',3,'Aplikasi Internal - Dinas Kesehatan Kota Bandung','8f9XE9zrNK0kq8Of','eyJpdiI6Im9SWGtucEwweHFWSE95ZFJZMVptdXc9PSIsInZhbHVlIjoiMVE0RUhCY2JYNEJwbVdiQ1k0OGszNC9acVZHVVd0M3RxREdEalFPL28wQ2l6Y2RQbzhpVGQ3NG5nN2hIaFVsbnVqSk1FV25XQ1VUUnFySVBCdDVOTlE9PSIsIm1hYyI6Ijk1ZWY0YTFiZmQ4MmZjZmZiZmM4M2ZhY2E1OWY4NWJmMTc3NjE2Mzk4MTgyZGY5MDQzNTVmODUyYTRkMzc0ZjQiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(6,'37609092-4346-49f0-9f6e-11b9844b26e7',4,'Aplikasi Internal - Diskominfo Prov. Jawa Barat','zuFAreSwZDJrrhfR','eyJpdiI6IkNQU0hOVG4ycjQ3K3I1RkdJbUdxWHc9PSIsInZhbHVlIjoiQk45cDZpUmpseHpZd3NDUitQWlV2ZXR4VHlWRDQ2Y1pzbkw0V3VhYmJ5TG5weGNzc2tGTDNLemlWdjB1TzBJbEMwcXpST0I3cnB2Y3VKOUNUcm9pNXc9PSIsIm1hYyI6ImZkODQ2ZjZjNTI1NWQ4ODRkZjllYzUwY2Y0YmQyNTljYjI1MDEwNTM4MGNkOWQxZjRhZjIwNzAzN2MzYTNhZWUiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(7,'e17fccfe-0c3d-452f-8e4c-4eba977ae6c5',5,'Aplikasi Internal - RSUD Al-Ihsan Bandung','iXgG3bjxJDDNq7fS','eyJpdiI6IkZrZzdJcWhTY082bnJmU2FuNWhJckE9PSIsInZhbHVlIjoiZitJczJRVTNESU1wS29oWFhtaWpKa0lMOG5BY2xybU9YY1M4ZE1HUVVTY2QxQWpnekJ5ZDVlY3F0OVNTNXptTnVEOW45VXFVNG93Rm82NXJsbjhhN1E9PSIsIm1hYyI6ImJiODExYzk1ZGQ2NTA2Njc0OWVmZmU0Zjk0OTI0MTVjZTA2ZWI4Y2Q1NTc3Y2NhYjg2MmFjNDgwZjk0ZTI1ZGUiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(8,'f277ab0c-449f-4719-97bb-4dbce9acd91a',6,'Aplikasi Internal - Bappeda Jawa Barat','ANyEzGhfsORT3Fji','eyJpdiI6IndicVF6emt6ZjRNS1BJdjVzN0h6WlE9PSIsInZhbHVlIjoiTjZaU1pYZzN2cmQzYjFBcGkwc0pvZ0M1QnMycitsV2FIZFZ4RDJIZ21OYmVGdk5nb0cvakhNVFM4bWxqeGpTNUJwSDhFbFJZdmRjM05YRFJZMWViTEE9PSIsIm1hYyI6IjA0ZDIxMmZlOWIwMzYyZDhjNGI4NzhhYzlhNDdlNDIyNTAxNTQzZTU4MTQyYjYzNmRjYzNhZjQzNGNhZTU5MjkiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(9,'9a780c51-69a2-4c5f-b63b-a151013ff40e',7,'Aplikasi Internal - Dinas Sosial Kota Cimahi','g6x8oAgx4IZ0F8XA','eyJpdiI6IjhZZ25GdGNwT2c5a05nSldQV1ozZnc9PSIsInZhbHVlIjoiOWpDaHNsaFZneHBFSmY0UVR2MVVwL3M2NUZ6dEExM2pkVElwNFNFVUtHMWJ3aW1xOFltYUErY1VZdm83Y1I2MGdOK2NTYXVWL1NacUlUU3paaDh6TUE9PSIsIm1hYyI6ImNmYjVhYzYyNmNmMDIyM2M1YjY2ZWE1ZmYxNmEzMmFjYjE2ZmUyNDM3YzY0YzM0NGI4MTM4N2JiOWRlNTM4OGEiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(10,'9f83a96d-359b-4139-aa68-8788e5242c1d',8,'Aplikasi Internal - DPMPTSP Kab. Bandung','opj06gESihGH1InV','eyJpdiI6IkFvN3I3Z0ZRazgxR2JnTzExYktSK3c9PSIsInZhbHVlIjoiN2M2bkNDUGpUQlU1UHN4TDNUcGRJY1R3WXU5Q2FBTGtSbEwxZ1BuSVFhT1FXSEU3WjRHZ1lMYjNQNVNFenI3S25uRTZxbGpSZXFGd0hyMU4yMFhSbHc9PSIsIm1hYyI6IjZjM2VlMDU5NTg0NjBjNWM1YTU2NTMyOGQ2ODdhZjczNzc1ZDNjOGJlMzM3NzgyZWQyYTkzMmU3ZGI2YTFjNmMiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(11,'61247b4d-f9e4-4ab5-b353-ca84b1b69ea1',9,'Aplikasi Internal - Dinas Pariwisata Jabar','eudUZs5XqNpDq2jf','eyJpdiI6IkFNdmJIWU1qNlNsYTFBdXB5UHY5VlE9PSIsInZhbHVlIjoibHo0YTBWVkpZN1ZYQ050ZGhyd25JSTVnbTdtVnRxZnorM3M0SG0wMFN3UDI2MWE2NjZOdUhNOTVWRWdUNmRlb1grL3A5UklqU2Y3MzhJZXFxVWxpTkE9PSIsIm1hYyI6Ijg3YWMxZjJiZDg3MzFhNDBhZjZjYTA1YTk5NjEwZTU4NDBiNmVjZDcxZThmZTY4ZmRmOTdjNmQ3YWJhYzVkMDgiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(12,'6b748a84-b8a1-4144-b252-6132ad293262',10,'Aplikasi Internal - Universitas Indonesia','DvaTFdc1Ssz9n3Kv','eyJpdiI6InBJZkVnQ1ZaS1UxcG02OXpIUWJhM1E9PSIsInZhbHVlIjoiR0tHanFWdTdnY0JCVm8zSGVkT09aazQ0YmtoVU1YbGFjT2F4b29NRmgxRi9HWnR2Mk8xVHQxem1ueUZNWGIvM0d2SkpQZGVtVEhLcTJ3bjVFelMwanc9PSIsIm1hYyI6IjdkMjhiY2E0MTA2YTQ2MzNiMDBjYWFhMTJjZjE4NmQ0OTUyNzJhZTYzN2ZiODZiNzljNjU0MjQxNzZlZTU5YWQiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(13,'e541ec19-2b72-403e-82fe-12952b2bf9f6',11,'Aplikasi Internal - Kantor Gubernur Jabar','sfG7JYhVhMiy1MF3','eyJpdiI6Ikg5Z1V6b2p4NzJlbUxxdzJrTDlQQmc9PSIsInZhbHVlIjoidzc1c3B5SFJ3MDVpQzRvTHNCanBGTXBySTJtc29kUmEvUmdQTFl1aTk5L0FLQjFtR0Z3eHJEakRIR2FNYU5lUWFRaXErSEtPVTVrTEN1SGFnQ3ZrR0E9PSIsIm1hYyI6ImIwYTRjNTgxNGQxYmMxNzY3ZmJhMzkxZjRjNTEzNjk4OWFhM2E0MDMxNzJkNTY4ZTg5N2Q3ZTFlY2MxODdjYzQiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(14,'4480a081-4764-4d29-9b5e-e59fc116a635',2,'Aplikasi Internal - Dinas Pendidikan Jawa Barat','eRMhUHKudeFKjoNj','eyJpdiI6ImdGcElhZWhsSHNjY1lKR2tPNkdaSnc9PSIsInZhbHVlIjoiQXk5R0dPNW9wbTMrYmo0V0FQa2ZYQU5udUYzNUhsNktFWHRRT3d1VG11V1UwOHYxNWFZOFkxbEg4eWgrMVhyczhFMkpmcXBOdmlwTEUrRElnQmgrWHc9PSIsIm1hYyI6IjM4MzhjMTRmMDg2ZDAxOGM4MzYwMTU1ZDZmZjc1MjZhNmM3NGViYWYyMjBjNjk0ZmZlMWI5NzVjNzYwNmQwOWMiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(15,'6c270fd1-3211-490f-8aef-37cfe99d3507',3,'Aplikasi Internal - Dinas Kesehatan Kota Bandung','zoEce0yl7ijLLXQX','eyJpdiI6IitZM1ozL3I2Ym1TU1VuL2ZYV2hteVE9PSIsInZhbHVlIjoiekVzNGQydjBBWFh4NXB2RklnNDNSUVFuRmxtTDFZSzA1blBBMEFzemVabnFMaFArMWdtQmp5c09yZnhpUm5VdGdkOWxyeElVZWF6b1RUZ1d3NUpxL1E9PSIsIm1hYyI6IjI4NGRlZDQ3MTQyYjMxYjIxZTAzNjExNWNmODgyZjE5NTVlNWU4ODQzNzY1ZjIwZmY5OTNkODIyZWM3YTgxYWQiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(16,'c5411e89-0f68-41c2-b14f-c639ea80e3c5',4,'Aplikasi Internal - Diskominfo Prov. Jawa Barat','5Ljita7htyo3sjGA','eyJpdiI6IjI3dnFkNE9xZTllcExwTiszU2FicUE9PSIsInZhbHVlIjoickJHTkF4dktxVy9xVVQyV2JvV1F3ZFdVaUI4bzFoMGdDem9mUWRlQjJyTmpXOUtlM2pTZ2NQTXRzS3pSR210VmR4aVpvS1QzOHdFWTBhdEZJRXUvMnc9PSIsIm1hYyI6ImU4ZDY1MjY3Njc4OWUwNmYwZGIzMWRjZGIzZDE5NDcyOWEwYjhkNmQ4OTExZTkyMmU3NzYyODk5NDkyNTQ2YzkiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(17,'69cfec94-6a81-44d5-a0fd-a338ae5e06b1',5,'Aplikasi Internal - RSUD Al-Ihsan Bandung','nb5F6udC8TsO7397','eyJpdiI6IjVlT2VYK2doODZsWGpoRUFZcWIra3c9PSIsInZhbHVlIjoiN08zVVBYbmRqK1NIaW1YMkUvZWpFbkI5Z0doaTRSQ0M5NWl2ZkxIak9QQ3NNU3IxMjFaQ1BiNGUzR0ZwS0hxemtac1JKL1plUm9oNWxRNEhDYldEM0E9PSIsIm1hYyI6ImZlMWJiOWQzNDQ5MzAyYjhiZDJmMTRkZDc2YWQzZDJkMzgzZjk4Y2ExMzU1OGUzYmVjYTRiMjZlNGY3NTEzZGUiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(18,'44ad7ec2-03d9-4caf-80b1-979babba667b',6,'Aplikasi Internal - Bappeda Jawa Barat','Pi3Bv5f4FMW85fCi','eyJpdiI6IlYxeENDSEx5eVVudkpFSmFibzlVd1E9PSIsInZhbHVlIjoiWndkZCtqZ0c1bmJsVHdmVkhCZGFoaTFGQ3U1UDUvcGtJNEt1dEIzdFVBaGI4SGVXdmVQTjU3eThjTmJJWlJPNjNNdmN4UWhRTkZ6YXRMWG9tUUlFTmc9PSIsIm1hYyI6ImM2MGI2Njc3ZjExZTY0N2EzOTdiNzNmYmNhNmE0YzM0YTkxMmNhMTBmMzkzMGViMDI1MzhjYzk2ZjRlMDQxNWMiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(19,'31b3fca8-213f-4804-9b5a-cb30175823b3',7,'Aplikasi Internal - Dinas Sosial Kota Cimahi','mXiWlAzLCCeYjg31','eyJpdiI6IkNKc3VXTFQ1bkRQWDAxd0FRVHhzNFE9PSIsInZhbHVlIjoiUkxKYU84Z1lFR1NnWmY1ekRWTlZydXZJeXk3TklFaGtWNXFGSjFXTE04Vjc4cU9tYThEWmpEbmFaY0FHUkhtL2w4M3hseC9BcFpTZGNKMFJRdWE4Ymc9PSIsIm1hYyI6IjViZjEzMzg0YjJlNTgxYjZmMGEzOGYyOTllZWFmZTU4NDU2MDMyYmVhN2M1MjAyOWEwOTAxMzQ4ZjMxZTZlOTAiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(20,'0b399112-e391-4752-b604-e4b966c6b93f',8,'Aplikasi Internal - DPMPTSP Kab. Bandung','yMSYRghTRF655alY','eyJpdiI6Ik5IaXVxaEUxeEpDc2VQVFFydXFKUGc9PSIsInZhbHVlIjoiOGxtZnZ5TFpPZUdqMkdGYmRRV0hDa3RWZUVqL3pNY2hVTEJtbXB6YUtDT2dHeE1lQm52RG94ODVTQWdKUEVzTUlIeFBLTmI1QlNMbjNVMnUzSUF3ZFE9PSIsIm1hYyI6IjQ2MDc4MzczMTYxZDE1MWI4ZTZjNWFhMDg0ZWYwMGE5MzkxZTgwZWUzNjIzNDI1Y2NjMTdjZGRhZGYwNTNkY2IiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(21,'2aff528c-0245-4274-bfce-bb403050e2fb',9,'Aplikasi Internal - Dinas Pariwisata Jabar','lh533zXuTauM2I8X','eyJpdiI6IlJNY0cwYTc4S0hsVWdxbG95NnM2RGc9PSIsInZhbHVlIjoiNTRFb1ZqVHZLYjJDaUVEYXNBczJzREU2Q3JNaTNsZ0VKbW94b01ISDNCT0hab0k5Nlc3NmdqeXVqdDBadHAwU2E3U0NKRGV5TTY2OGpFcU03b0FVd3c9PSIsIm1hYyI6IjMwM2JjZjBhYjY3MWYyN2E3YTMyMjAzMjYyNmQ5YWRiMmZkZWQyMDY0MTEyOTYwOWMwNWZkZjBiM2ZiZTNkNGEiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(22,'4d4153e4-8eff-4689-a19a-fe62e1c22b6f',10,'Aplikasi Internal - Universitas Indonesia','gMuLnXURQLbgxZqI','eyJpdiI6InlsbVpXbG1CWk9WQ0k1UnJqVEtBSVE9PSIsInZhbHVlIjoieGF1UDU4Vmk5SXdMTEgwVU9Fei96M2IxZFRIWC9TN1U4UE5pRVZXOWNZTWUwUWp5SDcvb0w0N2F6SW96cmlnWU56WjNsazZCdFYzSkE4RUh5bWRBa0E9PSIsIm1hYyI6IjBhNjRmNjdjZTI3MzA2Njg5MTBmMjQ5YTk2YTAwNDMxMTExOWNiYjgzYjk5NjNlN2RiMDFjNWFiOTBlZWNmZmEiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(23,'effad375-e5dd-434f-9e43-7df34b14e3d9',11,'Aplikasi Internal - Kantor Gubernur Jabar','Eoc75UfQG7kYIO0V','eyJpdiI6Ijk4OS9DY01sNEY3NUMrK2k5THI3RlE9PSIsInZhbHVlIjoiZUlSZnpSVlYxYmpLY3UwYkNkUDhjTmt3RG9JUlZ2WTZpdXpndXpqOUVkc1FDNWhJeDhOVkwwS2xxbXdsWEFrODRLZWVsZTdWcHJXRXI4SlQ3b2loakE9PSIsIm1hYyI6IjZkMmNlZDg1MzE3NTBlY2YyN2NkMTE3ODQ5NGJmNTg5YzgxNDNiODUyYmE2YTVkOTk0ZTdiZjE4ZWE4MzMyYWIiLCJ0YWciOiIifQ==',NULL,'free','active','2026-02-17 04:57:07','2026-02-17 04:57:07',NULL);
/*!40000 ALTER TABLE `api_clients` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `key` varchar(100) NOT NULL,
  `secret` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `scopes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`scopes`)),
  `ip_whitelist` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ip_whitelist`)),
  `rate_limit` int(11) NOT NULL DEFAULT 1000,
  `expires_at` timestamp NULL DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_keys_key_unique` (`key`),
  KEY `api_keys_key_index` (`key`),
  KEY `api_keys_client_id_index` (`client_id`),
  KEY `api_keys_expires_at_index` (`expires_at`),
  CONSTRAINT `api_keys_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `api_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `api_keys` VALUES
(1,3,'sk_w8R6jWQRtPpSOaCFRoFhQMN7sVoieZfg','eyJpdiI6Im1VSVY4WnR6U05VYXVmWTRiYnRFbXc9PSIsInZhbHVlIjoiM2lTS3NJdHFXUko4dHk5Zlg0MktqSWRBMThrL2h5bHJMVWJJSjdXd2p6aGZXUXBRbHd1b0tQMkxXQnZxaVUvYiIsIm1hYyI6IjYyYjViZWVkNmQwMTM1ZGRiNTM0YjJiOGMwYjBjZWUyMGJiMmNmMzkxZGRkYmE4ZWFkMDU2MGUwMzc1ZjI2ODQiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:55:22',NULL,'2026-02-17 04:55:22','2026-02-17 04:55:22'),
(2,4,'sk_VJIPdnximIWKc05VhuYT6bfpilVQupmQ','eyJpdiI6InJFald3b3VEYTBPa3NON3AycXA1NUE9PSIsInZhbHVlIjoiZjZhcm4vbm9ZZHZZcUg1cVd5MHN6RFVYL1F0SXFrS1hzTXB0Q1FhaGp5NmRFL1RFbjNId2VxMXVuSXN5R1VBUiIsIm1hYyI6ImFkY2U5MjczYTJiYTUzY2VkMDcyZTE2ZjVlZDZkZDFiNmE2MzNhMWVjNGQ3MWZmNWM3YTYyYWIzY2JmMWQxMmUiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:07',NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(3,5,'sk_ILm9KaR5o20NjMSiJmPM3yDfvn7za15L','eyJpdiI6ImduaGNya1diU0pSMG1XUjdzOWVnUHc9PSIsInZhbHVlIjoiRmdVTzk2dUx2NVlCVkowN2RqOEtYZWxCOVh5NVp3cUVnbVFNNEthaTVSalpPTVFxNExIcXh0UktyVWFSbWxhZyIsIm1hYyI6ImU1YTRmZDUwODBhMmMxYTMzMGUzYjMwMmI2ZDExYTZhZjdkM2RmMzhhMDkyY2E3NDYyNWM2NDA3MjUzYjdmM2IiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:07',NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(4,6,'sk_7aon8hpXlJ6c9LwBhfzs9NldOYr2UVAH','eyJpdiI6ImFZTFZlQzRpUzM4czY0M3ZzY0IvcUE9PSIsInZhbHVlIjoiQ2ZHZDJISUdrV2cvQllpL0NjR21QTkZURWxBNWdVVVYxaG1DeW5WamM0OVBVKzNGeWFSN08vK2xjRkF1cy9rQiIsIm1hYyI6IjM1NjQ5ZTZiOWFmZjVmMmE5Yzk5NDIzMWJjOTQ5ZGY1ZWJjM2IzYTU0YzRjNWM0MDc3NWMwNDU1YWM2MDFiNGQiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:08',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(5,7,'sk_Hz4VUeTurpJqKhRUD6wA591ouYsivTw7','eyJpdiI6IldHVkRJVGFNRnBkdGZaTDB5L0U1WWc9PSIsInZhbHVlIjoiN0RHdmFRMmd2ZFF6L0JsQ0k0U0ZDcTZvTXllVzNBUkRRWUtKSjA2VG9GZ0paSE96bEEzWGhMaFkwWFBjQUtaNiIsIm1hYyI6IjFkZmY5MGE4NDA3NmJhZTc4YzM3OGU1ODBlN2NjMTg2ZWQ1NzM0NjliY2M0OTljMGVhZmIxYjZkM2JkMmQxMzciLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:08',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(6,8,'sk_or5guRls6purWHFDEWgInWu7dUUuc61b','eyJpdiI6IkJIV0NWRGR2bDdVNk5Mc2hxS0dFdHc9PSIsInZhbHVlIjoiZE1rc2dpSXQ0SzNtMFN4dUd0SndWVTJpcDUyalBHYXRmUnJOdEljU1lEaEpqb0E2UUZzYVNVTml6Y25aYnV1QiIsIm1hYyI6ImViOWRlMmFjYmZjY2RmODhkM2IxZGRmOTQxNDE2ZjY3MjY1YmQ3Y2NhZjJlMmVhYTYwZGZmODM1MjQ5ZjQ4ZDMiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:08',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(7,9,'sk_eh7D28AplvJF9kPOU7ahIpIJWOtyqfIQ','eyJpdiI6IjNZd0RSVlZiT1VpaW4rWVlJT1NsYnc9PSIsInZhbHVlIjoiRHdObGMzT21wdDBvL0JIWTlIdFpHdEQvUGhHcytyR3ZFSUl3M2FjL0JMM3FaRmdXYVQ1dnd5a3h6UVpiejdnWSIsIm1hYyI6IjE4NTQzZDk2YzViM2UzYzkyMzI1NmE0MmI0YTBhNDQ2YmUyYTE1OTc0YTc4MGNhMTk1MjE2M2NkZDYyODk0YjEiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:09',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(8,10,'sk_a76D8vuhlYdjpfBT4xlPPBoUHF9LlqvP','eyJpdiI6IklSWmFWWEcvTXQ4azhYZlErZHR0Tnc9PSIsInZhbHVlIjoiaDgwWWRZMlpDM1NFL0gyTmFreFlURnFmRnhDNlR1VURkV0xKZFJ5RnQ2Qk9XTkhVa3dMZFFsSkc0RmJ1NGZkSiIsIm1hYyI6ImE0MjhjOTQ1YTI1YjJkMTA0OTgyMWFmOTkyYjQxZTAzMjA2MTA5ZmM4NDc0ZDcyMTVjODhkNWNhZThjZmZiZTUiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:09',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(9,11,'sk_LSw6vV6NWMEM5nfdRwHhLI4891L8Ukmo','eyJpdiI6Ikg5a1VlM3JoRldQWWFackdrR1JEOXc9PSIsInZhbHVlIjoiTmhGWVBUTFFsTFlkMGYwMUdQaEFaeXJwKzZZYUxvNEJEZFAwbmhmTG5ITjRNUzlrZE5FVW1Gck9kbG1FSlNRMCIsIm1hYyI6IjdlZGVkZjE0OTE5OWJlYThlMzg2YTMxNzYzZjQ5YzhkMWQ5YjliMWMwYzYxZWY5MGYzNzYzMmVkNjEzZWFiNzMiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:09',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(10,12,'sk_oK6bWdh1qLwnrNZgTN7B1L3PUJUiWctY','eyJpdiI6InJpbDdkZGMwdzUxT21vVlhKOUVsU1E9PSIsInZhbHVlIjoibE84TzdBOW1EYzd2Q3NEMmZ0MWZSUG9DU2FQWUIyZmZnZHBRekZmQ2JHRTBFR05qejkreERTeEx0UEs4MW9nZiIsIm1hYyI6IjIzNDRlMjZmYTIxNmVkMWM4YTZjZmQyY2Q5ZTg4MzQ5ZjgxNjkwYWNiNTMwMGIwYWQxMTI4MjkxNzAxOWMzNDkiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:10',NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(11,13,'sk_98NFvGqkfeLGgbePcM2B1F6fjrTzAOaT','eyJpdiI6Imt2YlUrd0dDd0VleWQ4ZEp2MWtWaEE9PSIsInZhbHVlIjoiS2YrWW1OcVNqS0VEaVBtM0kzTHJsdUJNeXRmcFZGUk9ETGNQRnVrSWhYOHkwNVZtYlp6SjlMNk8zcnBRMWc1aiIsIm1hYyI6IjUzODU4ZjZjODlkZGVhMWU0NzBmNTk3YjNkMjgwNjkzZTFlY2EwZmFlZGE1OTI5ZDZkZmU2YTEyYWI1MjExNWYiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:56:10',NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(12,14,'sk_HTkrIh8yZQNsnGYzGHhgZyw3y4vtvrxG','eyJpdiI6IjZ5MFdFWDFMYURzWlF5SnY5NHlINEE9PSIsInZhbHVlIjoiSGNpTEhnNHh2T3dLak5VWHRYNk9DUDRnZkVWYlRzZ3lzWTBQQUt1QjY0aVA0dTNzYVRPNTVaclBGYnRSWEZMbyIsIm1hYyI6ImQyNGEyYTA0Nzk4YTNjZjMzMWJmOWI0YWMwNmZhNTFjYmI1ZWEwYjE5M2JlZGY2YjQ5ZGNiNjNlNjY4NDkyMDkiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:04',NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(13,15,'sk_eDtdZqEP80TnJ4FM9vMnRsqrulzImHKM','eyJpdiI6IlF2UWFhZ1E5SnJkTmxlTFhzSDR0ZlE9PSIsInZhbHVlIjoiRHJzUzQ3U0x2VzBEbzFVTXh2MXJUQ0lyNEZJNFFxcEhjamR1cjd2dkhzVU1WWnl0MkF2TkxsQnlFU2VDV2F0USIsIm1hYyI6ImE2MjY5N2FjODhjMjc0MDEyZGNlM2NhNTdlMzY5MzBhMTllMzEyMjA0OTg3ZGI1Nzc4MmFjN2NjZDJkYjNkM2IiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:04',NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(14,16,'sk_N0Tew0sYtkKLMDny1xeZL2OVWd60f2eq','eyJpdiI6IkxnVEpBdGovS3RqQ0g1VHN1cG95N2c9PSIsInZhbHVlIjoiNVZza3hhallUaDdqbW5hQkZ0akJnd0IxUTFRZXZZSjBIcUlRNldWRzdoc0VRclpmSUdEOHJEYkJzTUc0VzVDMiIsIm1hYyI6IjBkZDQwNWRiNWUyYTY3NjU0MzAzMmFkOGM3YTQ0ZTcxMTYxMTkzNjA0MzEzNGRjMzBmYjY3ZjRiMjE0NGQ5NTEiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:05',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(15,17,'sk_fpgFCcRDw60UAdeB0ceoxQwzMCTG7u9z','eyJpdiI6InlYbGJ1eUZLZkh0bXFxTTQ3Mlk1eHc9PSIsInZhbHVlIjoia0RVakY4cFFDWVcvWWJpaEpzK1A2UU1XWDAzN1p0YWtuelNXR0NKVDA3a202bEtuYnkwTzBLZXU1Y1hjRlhGeiIsIm1hYyI6Ijg4ZmI1ODVmNTE0NjI1MzIxZDE5N2VjNTc4MTE0MWEwYjFjZDI4ODIyOWQ2NTgyYzdlZjBjZWRlOGI0YzJjZjEiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:05',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(16,18,'sk_hyTzTupf0MI8y5kODjkpAq8A3UmH66qC','eyJpdiI6IldabGd5Njh5T3F1ZkdTdmFHYzhDY2c9PSIsInZhbHVlIjoiZjh0NnJGR3pLbis1eVJuL2NEQUx0YldMRTEvVnU3MkZ6cUdCbVlWb2ovVTZ0UUovNFJDQ2VLVGRCOEJYUUx6aCIsIm1hYyI6IjAxNTVjOWFjN2I3M2ZmNTFlNDQ5ODQwYzEyZmQ1M2JhMTUxMTczYTlmNmU4MTY0OWRjM2E0MWJjNTEwZTY2Y2IiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:05',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(17,19,'sk_njBWOiQs9PDpmKN6OUOX2y6wBYRFRD05','eyJpdiI6IkFtSUJJaUphWG4zMlg2elIwcmpqREE9PSIsInZhbHVlIjoicGN3TUFab0FnSDRiR0h3dlZZVlBvcGpuV2JweTg3alUwNWdwQzlNR1FoUGsybXRLdHkrOXB0YTVuOXRXZkRiUyIsIm1hYyI6ImQyN2NkNTQzNmIyNDY2ZjUzMzI5YTgyNGRlNDFiM2QzNjUxN2MwZmRjODU3M2ZkZDI4YzZiMDQ3Y2EzYmRiZjUiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(18,20,'sk_ZlITWKPlp80Oomn7SNv0y8BuMTheJKr1','eyJpdiI6Imlhc3M5cTdpME11d2VwTzI2V1h2ZGc9PSIsInZhbHVlIjoiNk5LMmI3RzRFRkgrR2VJNmJVTVpEZFFIaFZ3MUwvclY1OVNEdnNmR1dSNXdXYmdkaE5CNS9GbVdzTmNBL1dEViIsIm1hYyI6IjcxODVjZjBjYjMyOTlmZDgzNzgxZGU0Yjc0NGIwNjE4NDEyZGFiMjk1YjIzNGYxZDVlYzU0MDE4YTVhMzE2NWUiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(19,21,'sk_Mq4F5dTD50POuzn9V8JkA1C0xV7cgZCr','eyJpdiI6InBtelg4Rks3SmhqUFhsVzgwR0hMVnc9PSIsInZhbHVlIjoid0dWM3ZSb016TFVJOExUYzhtRUgvc2RkdVoveUFQNzc3U01JWktjbzRzTEpxZ1phSXhvS0NpdEM5bHo5SFNxZyIsIm1hYyI6IjQ4NjQ0ZTNhOGY0ZjQ3MmI5Y2ZiMmQ1ZjAwNDY1ODlkM2I1NzFjOTFlMTMwZGQ0ZWZjNzA3ZTZmMDZlM2IzNjQiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(20,22,'sk_bDomBY1RuNl2ABArIw4ox2jiP4vujdF2','eyJpdiI6Imk4cFN0dCt1YVQ4dGM3eDBJNjEvamc9PSIsInZhbHVlIjoiWG5LVDhoWEVPZWdrZlFZZHcvalJzSEdSTm15dzRYUi9HYUxhWUtFZzNGSUVQT0dMZVlPOFYwVmthR2N3dXVoWSIsIm1hYyI6ImY3OGMxMmJmODM4MmUxNzBkNjZiMWEyZjFlODliZWNjMTgzNGZmY2E5ZjQzNDM1NzAzMDc0MWJiMzM3MzZhMDEiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(21,23,'sk_WRQvJVHG0vwPQh4HHQoFMs0MH4aueN70','eyJpdiI6IkZWQ0xscFBiNTl4SkRIUTl6a01MR2c9PSIsInZhbHVlIjoiUmFPbEQ5VzJlL2pOdlFVQWs5WFAvU2drOVJIWVduVTdxa0RiWXFtdlhLY2p3Nk5tVGMzQ3FkQmE2RUhYcktuTCIsIm1hYyI6ImU3OGNlZjJmMTliODM4NzI2M2UyOWI3NmUwZGFkNzJjZDAyNzgyYjk4MmU2M2YyODNjYTZjYjUwN2ExMWNhMzYiLCJ0YWciOiIifQ==','Key Produksi',NULL,NULL,1000,NULL,'2026-02-17 04:57:07',NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `api_usage_logs`
--

DROP TABLE IF EXISTS `api_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_usage_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `api_key_id` bigint(20) unsigned DEFAULT NULL,
  `endpoint` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `status_code` int(11) NOT NULL,
  `response_time` int(11) NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `request_signature` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `api_usage_logs_api_key_id_foreign` (`api_key_id`),
  KEY `api_usage_logs_client_id_created_at_index` (`client_id`,`created_at`),
  CONSTRAINT `api_usage_logs_api_key_id_foreign` FOREIGN KEY (`api_key_id`) REFERENCES `api_keys` (`id`) ON DELETE SET NULL,
  CONSTRAINT `api_usage_logs_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `api_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_usage_logs`
--

LOCK TABLES `api_usage_logs` WRITE;
/*!40000 ALTER TABLE `api_usage_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `api_usage_logs` VALUES
(1,4,2,'/api/v1/surveys/d9859f7a-11ab-49ce-8aa8-eff6c761fbc4','GET',200,143,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(2,5,3,'/api/v1/surveys/4742c21e-c266-4a37-accf-5501123281fc','GET',200,61,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(3,6,4,'/api/v1/surveys/a78ad5bb-1ee6-462b-8eb7-e2351d1273cd','GET',200,124,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(4,7,5,'/api/v1/surveys/7138874b-5a84-40f7-966a-cc0434563c9c','GET',200,117,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(5,8,6,'/api/v1/surveys/99575220-0bda-4318-82c7-2b4fb4a72295','GET',200,185,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(6,9,7,'/api/v1/surveys/54dea68e-8d3b-446d-b104-c37b97d7e2b8','GET',200,143,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(7,10,8,'/api/v1/surveys/ff583943-17ee-4ed5-8b14-4c409f45ee41','GET',200,136,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(8,11,9,'/api/v1/surveys/f4403088-d1c6-48f9-8684-3251c9676955','GET',200,109,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(9,12,10,'/api/v1/surveys/635f3fec-51a1-4fb0-ae38-cb2c44e95e7e','GET',200,88,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(10,13,11,'/api/v1/surveys/d713fd48-a928-4bea-8dcf-07e043cbbf94','GET',200,54,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(11,14,12,'/api/v1/surveys/d912b5fc-d0fa-45e4-861b-989bbee743d1','GET',200,142,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(12,15,13,'/api/v1/surveys/ddfefb34-ef79-4949-a001-eda0f91e1a26','GET',200,153,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(13,16,14,'/api/v1/surveys/73c16bfd-5a3b-4df9-87bf-8fdb8330bb38','GET',200,103,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(14,17,15,'/api/v1/surveys/9e5f6408-6903-43ea-b3e7-3a69d952d374','GET',200,181,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(15,18,16,'/api/v1/surveys/960d8e21-7817-40e4-901f-769226cda2fc','GET',200,76,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(16,19,17,'/api/v1/surveys/173b28cb-2b97-41ce-a0b8-5efd613924e3','GET',200,88,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(17,20,18,'/api/v1/surveys/d5e33101-8fc5-42b5-8b81-1ceb7c9be45d','GET',200,68,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(18,21,19,'/api/v1/surveys/9b368484-aeda-483d-b8df-b283f45303f8','GET',200,101,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(19,22,20,'/api/v1/surveys/65ea3831-439d-4596-9cb1-b308b4ec2566','GET',200,118,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(20,23,21,'/api/v1/surveys/ca9b13de-07bc-4f96-986c-b91c87dd53b6','GET',200,89,'127.0.0.1','Internal-App/1.0',NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `api_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `audit_logs_tenant_id_foreign` (`tenant_id`),
  KEY `audit_logs_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_created_at_index` (`created_at`),
  CONSTRAINT `audit_logs_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `audit_logs` VALUES
(1,2,1,'create','App\\Models\\Survey',1,NULL,'\"{\\\"title\\\":\\\"Evaluasi Pembelajaran Jarak Jauh 2024\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:53:23'),
(2,2,1,'create','App\\Models\\Survey',2,NULL,'\"{\\\"title\\\":\\\"Evaluasi Pembelajaran Jarak Jauh 2024\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:54:53'),
(3,2,1,'create','App\\Models\\Survey',3,NULL,'\"{\\\"title\\\":\\\"Evaluasi Pembelajaran Jarak Jauh 2024\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:55:21'),
(4,2,1,'create','App\\Models\\Survey',4,NULL,'\"{\\\"title\\\":\\\"Evaluasi Pembelajaran Jarak Jauh 2024\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:07'),
(5,3,1,'create','App\\Models\\Survey',5,NULL,'\"{\\\"title\\\":\\\"Indeks Kepuasan Masyarakat (IKM) Pelayanan Perizinan\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:07'),
(6,4,1,'create','App\\Models\\Survey',6,NULL,'\"{\\\"title\\\":\\\"Survei Kesiapan Vaksinasi Booster Tahap 3\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:07'),
(7,5,1,'create','App\\Models\\Survey',7,NULL,'\"{\\\"title\\\":\\\"Opini Publik Terhadap Pembangunan Flyover\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:08'),
(8,6,1,'create','App\\Models\\Survey',8,NULL,'\"{\\\"title\\\":\\\"Evaluasi Kinerja ASN Pemerintah Daerah\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:08'),
(9,7,1,'create','App\\Models\\Survey',9,NULL,'\"{\\\"title\\\":\\\"Survei Kebutuhan Pelatihan UMKM Digital\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:08'),
(10,8,1,'create','App\\Models\\Survey',10,NULL,'\"{\\\"title\\\":\\\"Penilaian Fasilitas Ruang Publik Kota\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:09'),
(11,9,1,'create','App\\Models\\Survey',11,NULL,'\"{\\\"title\\\":\\\"Survei Penggunaan Transportasi Umum\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:09'),
(12,10,1,'create','App\\Models\\Survey',12,NULL,'\"{\\\"title\\\":\\\"Feedback Pasca Rawat Jalan Pasien RSUD\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:09'),
(13,11,1,'create','App\\Models\\Survey',13,NULL,'\"{\\\"title\\\":\\\"Polling Efektivitas Penyaluran Bansos\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:56:10'),
(14,2,1,'create','App\\Models\\Survey',14,NULL,'\"{\\\"title\\\":\\\"Evaluasi Pembelajaran Jarak Jauh 2024\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:04'),
(15,3,1,'create','App\\Models\\Survey',15,NULL,'\"{\\\"title\\\":\\\"Indeks Kepuasan Masyarakat (IKM) Pelayanan Perizinan\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:04'),
(16,4,1,'create','App\\Models\\Survey',16,NULL,'\"{\\\"title\\\":\\\"Survei Kesiapan Vaksinasi Booster Tahap 3\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:04'),
(17,5,1,'create','App\\Models\\Survey',17,NULL,'\"{\\\"title\\\":\\\"Opini Publik Terhadap Pembangunan Flyover\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:05'),
(18,6,1,'create','App\\Models\\Survey',18,NULL,'\"{\\\"title\\\":\\\"Evaluasi Kinerja ASN Pemerintah Daerah\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:05'),
(19,7,1,'create','App\\Models\\Survey',19,NULL,'\"{\\\"title\\\":\\\"Survei Kebutuhan Pelatihan UMKM Digital\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:05'),
(20,8,1,'create','App\\Models\\Survey',20,NULL,'\"{\\\"title\\\":\\\"Penilaian Fasilitas Ruang Publik Kota\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:06'),
(21,9,1,'create','App\\Models\\Survey',21,NULL,'\"{\\\"title\\\":\\\"Survei Penggunaan Transportasi Umum\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:06'),
(22,10,1,'create','App\\Models\\Survey',22,NULL,'\"{\\\"title\\\":\\\"Feedback Pasca Rawat Jalan Pasien RSUD\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:06'),
(23,11,1,'create','App\\Models\\Survey',23,NULL,'\"{\\\"title\\\":\\\"Polling Efektivitas Penyaluran Bansos\\\"}\"','127.0.0.1','Seeder','2026-02-17 04:57:07'),
(24,NULL,NULL,'created','App\\Models\\SurveyResponse',116,NULL,'{\"uuid\":\"28a6027d-202f-4ed6-863f-e55f5a9aa23a\",\"survey_id\":2,\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"submitted_at\":\"2026-02-17T16:08:56.000000Z\",\"updated_at\":\"2026-02-17T16:08:56.000000Z\",\"created_at\":\"2026-02-17T16:08:56.000000Z\",\"id\":116}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-17 15:08:56'),
(25,NULL,NULL,'created','App\\Models\\SurveyResponse',117,NULL,'{\"uuid\":\"febbf86b-04a7-4f13-86f6-785b10508110\",\"survey_id\":2,\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"submitted_at\":\"2026-02-17T16:10:26.000000Z\",\"updated_at\":\"2026-02-17T16:10:26.000000Z\",\"created_at\":\"2026-02-17T16:10:26.000000Z\",\"id\":117}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-17 15:10:26'),
(26,NULL,NULL,'created','App\\Models\\SurveyResponse',118,NULL,'{\"uuid\":\"a407bd83-db28-4791-b333-2ee362532750\",\"survey_id\":2,\"respondent_name\":null,\"respondent_email\":null,\"respondent_phone\":null,\"respondent_nik\":null,\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"session_token\":\"by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ\",\"fingerprint\":\"bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766\",\"metadata\":{\"source\":\"web\"},\"submitted_at\":\"2026-02-17T16:42:53.000000Z\",\"updated_at\":\"2026-02-17T16:42:53.000000Z\",\"created_at\":\"2026-02-17T16:42:53.000000Z\",\"id\":118}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-17 15:42:53'),
(27,NULL,NULL,'created','App\\Models\\SurveyResponse',119,NULL,'{\"uuid\":\"960928da-8db2-43fd-bddf-0d7ce5af746a\",\"survey_id\":3,\"respondent_name\":null,\"respondent_email\":null,\"respondent_phone\":null,\"respondent_nik\":null,\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"session_token\":\"by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ\",\"fingerprint\":\"bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766\",\"metadata\":{\"source\":\"web\"},\"submitted_at\":\"2026-02-17T16:55:04.000000Z\",\"updated_at\":\"2026-02-17T16:55:04.000000Z\",\"created_at\":\"2026-02-17T16:55:04.000000Z\",\"id\":119}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-17 15:55:04'),
(28,NULL,NULL,'created','App\\Models\\SurveyResponse',120,NULL,'{\"uuid\":\"dab4e3b3-34e8-415d-affc-93b5c7929b79\",\"survey_id\":4,\"respondent_name\":\"Gilang Rizky Ramadhan\",\"respondent_email\":\"test@gmail.com\",\"respondent_phone\":null,\"respondent_nik\":null,\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"session_token\":\"by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ\",\"fingerprint\":\"bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766\",\"metadata\":{\"source\":\"web\"},\"submitted_at\":\"2026-02-17T16:58:41.000000Z\",\"updated_at\":\"2026-02-17T16:58:41.000000Z\",\"created_at\":\"2026-02-17T16:58:41.000000Z\",\"id\":120}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-17 15:58:41'),
(29,NULL,NULL,'created','App\\Models\\SurveyResponse',121,NULL,'{\"uuid\":\"35c7976d-85e2-43c2-ad65-e3b33207e2a4\",\"survey_id\":2,\"respondent_name\":\"Gilang Rizky Ramadhan\",\"respondent_email\":\"test@gmail.com\",\"respondent_phone\":\"839483204\",\"respondent_nik\":\"12312312\",\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"session_token\":\"by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ\",\"fingerprint\":\"bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766\",\"metadata\":{\"source\":\"web\"},\"submitted_at\":\"2026-02-19T19:07:41.000000Z\",\"updated_at\":\"2026-02-19T19:07:41.000000Z\",\"created_at\":\"2026-02-19T19:07:41.000000Z\",\"id\":121}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-19 18:07:41'),
(30,NULL,NULL,'created','App\\Models\\SurveyResponse',122,NULL,'{\"uuid\":\"95cb5893-b526-4f8a-a392-6cb802c6acc7\",\"survey_id\":2,\"respondent_name\":\"Gilang Rizky Ramadhan\",\"respondent_email\":\"tes1t@gmail.com\",\"respondent_phone\":\"2523\",\"respondent_nik\":\"12312312\",\"status\":\"completed\",\"ip_address\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/143.0.0.0 Safari\\/537.36\",\"session_token\":\"by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ\",\"fingerprint\":\"bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766\",\"metadata\":{\"source\":\"web\"},\"submitted_at\":\"2026-02-19T19:08:44.000000Z\",\"updated_at\":\"2026-02-19T19:08:44.000000Z\",\"created_at\":\"2026-02-19T19:08:44.000000Z\",\"id\":122}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-02-19 18:08:44');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache` VALUES
('laravel-cache-livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3','i:1;',1771523596),
('laravel-cache-livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3:timer','i:1771523596;',1771523596),
('laravel-cache-public_stats','a:8:{s:13:\"total_surveys\";i:22;s:15:\"total_responses\";i:115;s:19:\"total_organizations\";i:11;s:14:\"active_surveys\";i:22;s:13:\"response_rate\";d:5.1;s:17:\"monthly_responses\";a:1:{s:7:\"2026-02\";i:115;}s:15:\"popular_surveys\";a:5:{i:0;a:26:{s:2:\"id\";i:3;s:4:\"uuid\";s:36:\"b640c9c0-afae-467c-a3c7-a03ede41eb90\";s:9:\"tenant_id\";i:2;s:10:\"creator_id\";i:1;s:11:\"template_id\";N;s:8:\"theme_id\";N;s:15:\"source_app_name\";s:20:\"Portal Belajar Jabar\";s:14:\"source_app_url\";s:31:\"https://belajar.jabarprov.go.id\";s:13:\"usage_context\";s:75:\"Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.\";s:5:\"title\";s:37:\"Evaluasi Pembelajaran Jarak Jauh 2024\";s:11:\"description\";s:140:\"Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.\";s:15:\"welcome_message\";s:76:\"Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.\";s:17:\"thank_you_message\";s:75:\"Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.\";s:6:\"status\";s:6:\"active\";s:4:\"type\";s:6:\"public\";s:8:\"settings\";a:0:{}s:26:\"allow_multiple_submissions\";b:0;s:27:\"require_respondent_identity\";b:1;s:27:\"duplicate_prevention_method\";s:6:\"cookie\";s:8:\"metadata\";a:0:{}s:9:\"starts_at\";s:27:\"2026-02-07T05:55:21.000000Z\";s:7:\"ends_at\";s:27:\"2026-03-09T05:55:21.000000Z\";s:10:\"created_at\";s:27:\"2026-02-17T05:55:21.000000Z\";s:10:\"updated_at\";s:27:\"2026-02-17T16:56:46.000000Z\";s:10:\"deleted_at\";N;s:15:\"responses_count\";i:6;}i:1;a:26:{s:2:\"id\";i:4;s:4:\"uuid\";s:36:\"d9859f7a-11ab-49ce-8aa8-eff6c761fbc4\";s:9:\"tenant_id\";i:2;s:10:\"creator_id\";i:1;s:11:\"template_id\";N;s:8:\"theme_id\";N;s:15:\"source_app_name\";s:20:\"Portal Belajar Jabar\";s:14:\"source_app_url\";s:31:\"https://belajar.jabarprov.go.id\";s:13:\"usage_context\";s:75:\"Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.\";s:5:\"title\";s:37:\"Evaluasi Pembelajaran Jarak Jauh 2024\";s:11:\"description\";s:140:\"Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.\";s:15:\"welcome_message\";s:76:\"Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.\";s:17:\"thank_you_message\";s:75:\"Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.\";s:6:\"status\";s:6:\"active\";s:4:\"type\";s:6:\"public\";s:8:\"settings\";a:0:{}s:26:\"allow_multiple_submissions\";b:0;s:27:\"require_respondent_identity\";b:1;s:27:\"duplicate_prevention_method\";s:5:\"email\";s:8:\"metadata\";a:0:{}s:9:\"starts_at\";s:27:\"2026-02-07T05:56:07.000000Z\";s:7:\"ends_at\";s:27:\"2026-03-09T05:56:07.000000Z\";s:10:\"created_at\";s:27:\"2026-02-17T05:56:07.000000Z\";s:10:\"updated_at\";s:27:\"2026-02-17T16:57:27.000000Z\";s:10:\"deleted_at\";N;s:15:\"responses_count\";i:6;}i:2;a:26:{s:2:\"id\";i:5;s:4:\"uuid\";s:36:\"4742c21e-c266-4a37-accf-5501123281fc\";s:9:\"tenant_id\";i:3;s:10:\"creator_id\";i:1;s:11:\"template_id\";N;s:8:\"theme_id\";N;s:15:\"source_app_name\";s:17:\"Aplikasi SiPinter\";s:14:\"source_app_url\";s:30:\"https://sipinter.bandung.go.id\";s:13:\"usage_context\";s:104:\"Muncul otomatis setelah perizinan disetujui. Data ditarik via API untuk laporan IKM bulanan ke Walikota.\";s:5:\"title\";s:52:\"Indeks Kepuasan Masyarakat (IKM) Pelayanan Perizinan\";s:11:\"description\";s:155:\"Survei ini bertujuan untuk mendapatkan data akurat mengenai indeks kepuasan masyarakat (ikm) pelayanan perizinan guna meningkatkan kualitas layanan publik.\";s:15:\"welcome_message\";s:76:\"Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.\";s:17:\"thank_you_message\";s:75:\"Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.\";s:6:\"status\";s:6:\"active\";s:4:\"type\";s:6:\"public\";s:8:\"settings\";N;s:26:\"allow_multiple_submissions\";b:1;s:27:\"require_respondent_identity\";b:0;s:27:\"duplicate_prevention_method\";s:6:\"cookie\";s:8:\"metadata\";N;s:9:\"starts_at\";s:27:\"2026-02-07T05:56:07.000000Z\";s:7:\"ends_at\";s:27:\"2026-03-09T05:56:07.000000Z\";s:10:\"created_at\";s:27:\"2026-02-17T05:56:07.000000Z\";s:10:\"updated_at\";s:27:\"2026-02-17T05:56:07.000000Z\";s:10:\"deleted_at\";N;s:15:\"responses_count\";i:5;}i:3;a:26:{s:2:\"id\";i:6;s:4:\"uuid\";s:36:\"a78ad5bb-1ee6-462b-8eb7-e2351d1273cd\";s:9:\"tenant_id\";i:4;s:10:\"creator_id\";i:1;s:11:\"template_id\";N;s:8:\"theme_id\";N;s:15:\"source_app_name\";s:32:\"Sistem Informasi Kesehatan (SIK)\";s:14:\"source_app_url\";s:25:\"https://sik.bandung.go.id\";s:13:\"usage_context\";s:89:\"Kuesioner pra-pendaftaran vaksinasi. Digunakan untuk screening awal kesehatan masyarakat.\";s:5:\"title\";s:41:\"Survei Kesiapan Vaksinasi Booster Tahap 3\";s:11:\"description\";s:144:\"Survei ini bertujuan untuk mendapatkan data akurat mengenai survei kesiapan vaksinasi booster tahap 3 guna meningkatkan kualitas layanan publik.\";s:15:\"welcome_message\";s:76:\"Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.\";s:17:\"thank_you_message\";s:75:\"Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.\";s:6:\"status\";s:6:\"active\";s:4:\"type\";s:6:\"public\";s:8:\"settings\";N;s:26:\"allow_multiple_submissions\";b:1;s:27:\"require_respondent_identity\";b:0;s:27:\"duplicate_prevention_method\";s:6:\"cookie\";s:8:\"metadata\";N;s:9:\"starts_at\";s:27:\"2026-02-07T05:56:07.000000Z\";s:7:\"ends_at\";s:27:\"2026-03-09T05:56:07.000000Z\";s:10:\"created_at\";s:27:\"2026-02-17T05:56:07.000000Z\";s:10:\"updated_at\";s:27:\"2026-02-17T05:56:07.000000Z\";s:10:\"deleted_at\";N;s:15:\"responses_count\";i:5;}i:4;a:26:{s:2:\"id\";i:7;s:4:\"uuid\";s:36:\"7138874b-5a84-40f7-966a-cc0434563c9c\";s:9:\"tenant_id\";i:5;s:10:\"creator_id\";i:1;s:11:\"template_id\";N;s:8:\"theme_id\";N;s:15:\"source_app_name\";s:19:\"Website Resmi Jabar\";s:14:\"source_app_url\";s:31:\"https://jabarprov.go.id/polling\";s:13:\"usage_context\";s:96:\"Poling terbuka di homepage website pemprov untuk menjaring aspirasi warga terkait infrastruktur.\";s:5:\"title\";s:41:\"Opini Publik Terhadap Pembangunan Flyover\";s:11:\"description\";s:144:\"Survei ini bertujuan untuk mendapatkan data akurat mengenai opini publik terhadap pembangunan flyover guna meningkatkan kualitas layanan publik.\";s:15:\"welcome_message\";s:76:\"Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.\";s:17:\"thank_you_message\";s:75:\"Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.\";s:6:\"status\";s:6:\"active\";s:4:\"type\";s:6:\"public\";s:8:\"settings\";N;s:26:\"allow_multiple_submissions\";b:1;s:27:\"require_respondent_identity\";b:0;s:27:\"duplicate_prevention_method\";s:6:\"cookie\";s:8:\"metadata\";N;s:9:\"starts_at\";s:27:\"2026-02-07T05:56:08.000000Z\";s:7:\"ends_at\";s:27:\"2026-03-09T05:56:08.000000Z\";s:10:\"created_at\";s:27:\"2026-02-17T05:56:08.000000Z\";s:10:\"updated_at\";s:27:\"2026-02-17T05:56:08.000000Z\";s:10:\"deleted_at\";N;s:15:\"responses_count\";i:5;}}s:14:\"active_tenants\";a:10:{i:0;a:1:{s:4:\"name\";s:20:\"Portal Belajar Jabar\";}i:1;a:1:{s:4:\"name\";s:17:\"Aplikasi SiPinter\";}i:2;a:1:{s:4:\"name\";s:32:\"Sistem Informasi Kesehatan (SIK)\";}i:3;a:1:{s:4:\"name\";s:19:\"Website Resmi Jabar\";}i:4;a:1:{s:4:\"name\";s:13:\"SIM-ASN Jabar\";}i:5;a:1:{s:4:\"name\";s:24:\"Marketplace Lokal Cimahi\";}i:6;a:1:{s:4:\"name\";s:19:\"Aplikasi Sapa Warga\";}i:7;a:1:{s:4:\"name\";s:19:\"Aplikasi TMB Mobile\";}i:8;a:1:{s:4:\"name\";s:19:\"Sistem Antrean RSUD\";}i:9;a:1:{s:4:\"name\";s:24:\"Sistem Logistik SosJabar\";}}}',1771523823);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `consent_records`
--

DROP TABLE IF EXISTS `consent_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consent_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `response_id` bigint(20) unsigned DEFAULT NULL,
  `consent_type` varchar(255) NOT NULL,
  `given` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `consent_records_survey_id_foreign` (`survey_id`),
  KEY `consent_records_response_id_foreign` (`response_id`),
  CONSTRAINT `consent_records_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `consent_records_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consent_records`
--

LOCK TABLES `consent_records` WRITE;
/*!40000 ALTER TABLE `consent_records` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `consent_records` VALUES
(1,1,1,'data_processing',1,'192.168.1.44','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:53:23'),
(2,1,2,'data_processing',1,'192.168.1.82','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:53:23'),
(3,1,3,'data_processing',1,'192.168.1.49','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:53:23'),
(4,1,4,'data_processing',1,'192.168.1.61','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:53:23'),
(5,1,5,'data_processing',1,'192.168.1.7','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:53:23'),
(6,2,6,'data_processing',1,'192.168.1.130','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:54:53'),
(7,2,7,'data_processing',1,'192.168.1.233','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:54:53'),
(8,2,8,'data_processing',1,'192.168.1.170','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:54:53'),
(9,2,9,'data_processing',1,'192.168.1.111','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:54:53'),
(10,2,10,'data_processing',1,'192.168.1.1','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:54:53'),
(11,3,11,'data_processing',1,'192.168.1.110','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:55:21'),
(12,3,12,'data_processing',1,'192.168.1.217','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:55:21'),
(13,3,13,'data_processing',1,'192.168.1.249','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:55:21'),
(14,3,14,'data_processing',1,'192.168.1.143','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:55:21'),
(15,3,15,'data_processing',1,'192.168.1.95','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:55:21'),
(16,4,16,'data_processing',1,'192.168.1.152','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(17,4,17,'data_processing',1,'192.168.1.251','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(18,4,18,'data_processing',1,'192.168.1.144','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(19,4,19,'data_processing',1,'192.168.1.125','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(20,4,20,'data_processing',1,'192.168.1.85','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(21,5,21,'data_processing',1,'192.168.1.64','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(22,5,22,'data_processing',1,'192.168.1.183','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(23,5,23,'data_processing',1,'192.168.1.251','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(24,5,24,'data_processing',1,'192.168.1.162','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(25,5,25,'data_processing',1,'192.168.1.167','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(26,6,26,'data_processing',1,'192.168.1.55','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(27,6,27,'data_processing',1,'192.168.1.68','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(28,6,28,'data_processing',1,'192.168.1.197','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(29,6,29,'data_processing',1,'192.168.1.54','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(30,6,30,'data_processing',1,'192.168.1.90','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:07'),
(31,7,31,'data_processing',1,'192.168.1.67','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(32,7,32,'data_processing',1,'192.168.1.59','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(33,7,33,'data_processing',1,'192.168.1.206','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(34,7,34,'data_processing',1,'192.168.1.29','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(35,7,35,'data_processing',1,'192.168.1.129','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(36,8,36,'data_processing',1,'192.168.1.127','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(37,8,37,'data_processing',1,'192.168.1.110','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(38,8,38,'data_processing',1,'192.168.1.206','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(39,8,39,'data_processing',1,'192.168.1.38','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(40,8,40,'data_processing',1,'192.168.1.99','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(41,9,41,'data_processing',1,'192.168.1.106','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(42,9,42,'data_processing',1,'192.168.1.92','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(43,9,43,'data_processing',1,'192.168.1.82','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(44,9,44,'data_processing',1,'192.168.1.112','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(45,9,45,'data_processing',1,'192.168.1.21','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:08'),
(46,10,46,'data_processing',1,'192.168.1.252','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(47,10,47,'data_processing',1,'192.168.1.135','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(48,10,48,'data_processing',1,'192.168.1.1','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(49,10,49,'data_processing',1,'192.168.1.209','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(50,10,50,'data_processing',1,'192.168.1.84','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(51,11,51,'data_processing',1,'192.168.1.97','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(52,11,52,'data_processing',1,'192.168.1.13','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(53,11,53,'data_processing',1,'192.168.1.152','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(54,11,54,'data_processing',1,'192.168.1.74','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(55,11,55,'data_processing',1,'192.168.1.149','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(56,12,56,'data_processing',1,'192.168.1.127','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(57,12,57,'data_processing',1,'192.168.1.176','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(58,12,58,'data_processing',1,'192.168.1.11','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(59,12,59,'data_processing',1,'192.168.1.98','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(60,12,60,'data_processing',1,'192.168.1.151','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:09'),
(61,13,61,'data_processing',1,'192.168.1.26','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:10'),
(62,13,62,'data_processing',1,'192.168.1.199','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:10'),
(63,13,63,'data_processing',1,'192.168.1.222','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:10'),
(64,13,64,'data_processing',1,'192.168.1.16','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:10'),
(65,13,65,'data_processing',1,'192.168.1.200','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:56:10'),
(66,14,66,'data_processing',1,'192.168.1.247','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(67,14,67,'data_processing',1,'192.168.1.119','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(68,14,68,'data_processing',1,'192.168.1.56','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(69,14,69,'data_processing',1,'192.168.1.166','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(70,14,70,'data_processing',1,'192.168.1.176','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(71,15,71,'data_processing',1,'192.168.1.239','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(72,15,72,'data_processing',1,'192.168.1.174','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(73,15,73,'data_processing',1,'192.168.1.3','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(74,15,74,'data_processing',1,'192.168.1.211','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(75,15,75,'data_processing',1,'192.168.1.83','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(76,16,76,'data_processing',1,'192.168.1.96','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(77,16,77,'data_processing',1,'192.168.1.191','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(78,16,78,'data_processing',1,'192.168.1.18','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(79,16,79,'data_processing',1,'192.168.1.122','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(80,16,80,'data_processing',1,'192.168.1.110','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:04'),
(81,17,81,'data_processing',1,'192.168.1.226','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(82,17,82,'data_processing',1,'192.168.1.245','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(83,17,83,'data_processing',1,'192.168.1.40','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(84,17,84,'data_processing',1,'192.168.1.140','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(85,17,85,'data_processing',1,'192.168.1.144','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(86,18,86,'data_processing',1,'192.168.1.132','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(87,18,87,'data_processing',1,'192.168.1.238','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(88,18,88,'data_processing',1,'192.168.1.64','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(89,18,89,'data_processing',1,'192.168.1.123','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(90,18,90,'data_processing',1,'192.168.1.74','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(91,19,91,'data_processing',1,'192.168.1.243','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(92,19,92,'data_processing',1,'192.168.1.240','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(93,19,93,'data_processing',1,'192.168.1.59','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(94,19,94,'data_processing',1,'192.168.1.149','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(95,19,95,'data_processing',1,'192.168.1.202','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:05'),
(96,20,96,'data_processing',1,'192.168.1.215','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(97,20,97,'data_processing',1,'192.168.1.83','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(98,20,98,'data_processing',1,'192.168.1.7','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(99,20,99,'data_processing',1,'192.168.1.188','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(100,20,100,'data_processing',1,'192.168.1.21','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(101,21,101,'data_processing',1,'192.168.1.126','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(102,21,102,'data_processing',1,'192.168.1.236','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(103,21,103,'data_processing',1,'192.168.1.46','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(104,21,104,'data_processing',1,'192.168.1.166','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(105,21,105,'data_processing',1,'192.168.1.133','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(106,22,106,'data_processing',1,'192.168.1.199','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(107,22,107,'data_processing',1,'192.168.1.251','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(108,22,108,'data_processing',1,'192.168.1.164','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(109,22,109,'data_processing',1,'192.168.1.129','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(110,22,110,'data_processing',1,'192.168.1.69','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:06'),
(111,23,111,'data_processing',1,'192.168.1.99','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:07'),
(112,23,112,'data_processing',1,'192.168.1.161','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:07'),
(113,23,113,'data_processing',1,'192.168.1.78','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:07'),
(114,23,114,'data_processing',1,'192.168.1.71','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:07'),
(115,23,115,'data_processing',1,'192.168.1.120','Mozilla/5.0 (Realistic Dummy Data)','2026-02-17 05:57:07');
/*!40000 ALTER TABLE `consent_records` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `data_retention_policies`
--

DROP TABLE IF EXISTS `data_retention_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_retention_policies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `data_type` varchar(255) NOT NULL,
  `retention_days` int(11) NOT NULL,
  `auto_delete` tinyint(1) NOT NULL DEFAULT 0,
  `last_cleanup_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_retention_policies_tenant_id_foreign` (`tenant_id`),
  CONSTRAINT `data_retention_policies_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_retention_policies`
--

LOCK TABLES `data_retention_policies` WRITE;
/*!40000 ALTER TABLE `data_retention_policies` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `data_retention_policies` VALUES
(1,2,'survey_responses',730,0,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(2,3,'survey_responses',730,0,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(3,4,'survey_responses',730,0,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(4,5,'survey_responses',730,0,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(5,6,'survey_responses',730,0,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(6,7,'survey_responses',730,0,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(7,8,'survey_responses',730,0,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(8,9,'survey_responses',730,0,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(9,10,'survey_responses',730,0,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(10,11,'survey_responses',730,0,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(11,2,'survey_responses',730,0,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(12,3,'survey_responses',730,0,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(13,4,'survey_responses',730,0,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(14,5,'survey_responses',730,0,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(15,6,'survey_responses',730,0,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(16,7,'survey_responses',730,0,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(17,8,'survey_responses',730,0,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(18,9,'survey_responses',730,0,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(19,10,'survey_responses',730,0,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(20,11,'survey_responses',730,0,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `data_retention_policies` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `integrations`
--

DROP TABLE IF EXISTS `integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `integrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `type` enum('slack','zapier','sheets','email','sms') NOT NULL,
  `credentials` text DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `integrations_tenant_id_index` (`tenant_id`),
  KEY `integrations_type_index` (`type`),
  CONSTRAINT `integrations_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integrations`
--

LOCK TABLES `integrations` WRITE;
/*!40000 ALTER TABLE `integrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `integrations` VALUES
(1,2,'sms',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/3dUye8AG\\\"}\"',1,'2026-02-17 04:55:22','2026-02-17 04:55:22'),
(2,2,'email',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/vaZWuofu\\\"}\"',1,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(3,3,'zapier',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/MIUaex0e\\\"}\"',1,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(4,4,'slack',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/Xk6KHzyh\\\"}\"',1,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(5,5,'email',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/Ds0WbzcE\\\"}\"',1,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(6,6,'sheets',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/C66WTS0o\\\"}\"',1,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(7,7,'zapier',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/Z5yEQDuG\\\"}\"',1,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(8,8,'zapier',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/3LgFRZqY\\\"}\"',1,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(9,9,'email',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/CTBzG4tz\\\"}\"',1,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(10,10,'sheets',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/TPWYdTuL\\\"}\"',1,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(11,11,'slack',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/Oyon3oyP\\\"}\"',1,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(12,2,'slack',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/xxijiYGG\\\"}\"',1,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(13,3,'zapier',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/8R8wgnBj\\\"}\"',1,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(14,4,'email',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/75jGIwpk\\\"}\"',1,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(15,5,'zapier',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/zmMymKCo\\\"}\"',1,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(16,6,'sms',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/H5h8tp9k\\\"}\"',1,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(17,7,'sms',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/ToNqxHzK\\\"}\"',1,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(18,8,'slack',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/5763Gw2U\\\"}\"',1,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(19,9,'email',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/jw3JOBhK\\\"}\"',1,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(20,10,'sheets',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/eCq5II4F\\\"}\"',1,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(21,11,'email',NULL,'\"{\\\"webhook_url\\\":\\\"https:\\\\\\/\\\\\\/hooks.external.com\\\\\\/OPZl4t76\\\"}\"',1,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `integrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'2026_02_16_170510_create_oauth_auth_codes_table',1),
(2,'2026_02_16_170511_create_oauth_access_tokens_table',1),
(3,'2026_02_16_170512_create_oauth_refresh_tokens_table',1),
(4,'2026_02_16_170513_create_oauth_clients_table',1),
(5,'2026_02_16_170514_create_oauth_device_codes_table',1),
(6,'2026_02_16_173420_create_cache_table',1),
(7,'2026_02_16_173420_create_failed_jobs_table',1),
(8,'2026_02_16_173420_create_job_batches_table',1),
(9,'2026_02_16_173420_create_sessions_table',1),
(10,'2026_02_16_173501_create_jobs_table',1),
(11,'2026_02_17_000001_create_auth_tables',1),
(12,'2026_02_17_000002_create_tenant_tables',1),
(13,'2026_02_17_000003_create_api_tables',1),
(14,'2026_02_17_000004_create_survey_tables',1),
(15,'2026_02_17_000005_create_response_tables',1),
(16,'2026_02_17_000006_create_analytics_ai_tables',1),
(17,'2026_02_17_000007_create_integration_audit_tables',1),
(18,'2026_02_17_033859_change_client_secret_to_text_in_api_clients_table',1),
(19,'2026_02_17_034133_change_secret_to_text_in_api_keys_table',1),
(20,'2026_02_17_063059_add_source_app_fields_to_surveys_table',1),
(21,'2026_02_17_100000_create_ai_anomaly_detection_table',1),
(22,'2026_02_17_230258_fix_question_types',2),
(23,'2026_02_17_232552_add_respondent_identity_to_survey_responses',3),
(24,'2026_02_18_003653_create_ai_settings_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` char(80) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` char(80) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` char(36) NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` char(36) NOT NULL,
  `owner_type` varchar(255) DEFAULT NULL,
  `owner_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect_uris` text NOT NULL,
  `grant_types` text NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_owner_type_owner_id_index` (`owner_type`,`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `oauth_device_codes`
--

DROP TABLE IF EXISTS `oauth_device_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_device_codes` (
  `id` char(80) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` char(36) NOT NULL,
  `user_code` char(8) NOT NULL,
  `scopes` text NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `user_approved_at` datetime DEFAULT NULL,
  `last_polled_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_device_codes_user_code_unique` (`user_code`),
  KEY `oauth_device_codes_user_id_index` (`user_id`),
  KEY `oauth_device_codes_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_device_codes`
--

LOCK TABLES `oauth_device_codes` WRITE;
/*!40000 ALTER TABLE `oauth_device_codes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `oauth_device_codes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` char(80) NOT NULL,
  `access_token_id` char(80) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_slug_unique` (`slug`),
  KEY `permissions_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `permissions` VALUES
(1,'Manage Surveys','surveys.manage',NULL,'2026-02-17 04:53:22','2026-02-17 04:53:22'),
(2,'View Analytics','analytics.view',NULL,'2026-02-17 04:53:22','2026-02-17 04:53:22'),
(3,'Manage Users','users.manage',NULL,'2026-02-17 04:53:22','2026-02-17 04:53:22');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `question_logic`
--

DROP TABLE IF EXISTS `question_logic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_logic` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) unsigned NOT NULL,
  `condition_type` varchar(255) NOT NULL,
  `source_question_id` bigint(20) unsigned DEFAULT NULL,
  `operator` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `target_question_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_logic_question_id_foreign` (`question_id`),
  KEY `question_logic_source_question_id_foreign` (`source_question_id`),
  KEY `question_logic_target_question_id_foreign` (`target_question_id`),
  CONSTRAINT `question_logic_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_logic_source_question_id_foreign` FOREIGN KEY (`source_question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_logic_target_question_id_foreign` FOREIGN KEY (`target_question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_logic`
--

LOCK TABLES `question_logic` WRITE;
/*!40000 ALTER TABLE `question_logic` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `question_logic` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `question_options`
--

DROP TABLE IF EXISTS `question_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) unsigned NOT NULL,
  `label` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_options_question_id_index` (`question_id`),
  CONSTRAINT `question_options_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_options`
--

LOCK TABLES `question_options` WRITE;
/*!40000 ALTER TABLE `question_options` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `question_options` VALUES
(1,1,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(2,1,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(3,1,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(4,1,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(5,5,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(6,5,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(7,5,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(8,5,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(9,9,'< 20 tahun','< 20 tahun',1,0,'2026-02-17 04:55:21','2026-02-17 15:01:43'),
(10,9,'21 - 35 tahun','21 - 35 tahun',2,0,'2026-02-17 04:55:21','2026-02-17 15:01:43'),
(11,9,'36 - 50 tahun','36 - 50 tahun',3,0,'2026-02-17 04:55:21','2026-02-17 15:01:43'),
(12,9,'> 50 tahun','> 50 tahun',4,0,'2026-02-17 04:55:21','2026-02-17 15:01:43'),
(13,13,'< 20 tahun','< 20 tahun',1,0,'2026-02-17 04:56:07','2026-02-17 14:59:46'),
(14,13,'21 - 35 tahun','21 - 35 tahun',2,0,'2026-02-17 04:56:07','2026-02-17 14:59:46'),
(15,13,'36 - 50 tahun','36 - 50 tahun',3,0,'2026-02-17 04:56:07','2026-02-17 14:59:46'),
(16,13,'> 50 tahun','> 50 tahun',4,0,'2026-02-17 04:56:07','2026-02-17 14:59:46'),
(17,17,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(18,17,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(19,17,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(20,17,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(21,21,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(22,21,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(23,21,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(24,21,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(25,25,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(26,25,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(27,25,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(28,25,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(29,29,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(30,29,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(31,29,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(32,29,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(33,33,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(34,33,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(35,33,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(36,33,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(37,37,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(38,37,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(39,37,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(40,37,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(41,41,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(42,41,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(43,41,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(44,41,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(45,45,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(46,45,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(47,45,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(48,45,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(49,49,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(50,49,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(51,49,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(52,49,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(53,53,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(54,53,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(55,53,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(56,53,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(57,57,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(58,57,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(59,57,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(60,57,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(61,61,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(62,61,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(63,61,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(64,61,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(65,65,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(66,65,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(67,65,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(68,65,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(69,69,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(70,69,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(71,69,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(72,69,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(73,73,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(74,73,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(75,73,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(76,73,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(77,77,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(78,77,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(79,77,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(80,77,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(81,81,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(82,81,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(83,81,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(84,81,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(85,85,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(86,85,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(87,85,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(88,85,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(89,89,'< 20 tahun','< 20 tahun',0,0,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(90,89,'21 - 35 tahun','21 - 35 tahun',1,0,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(91,89,'36 - 50 tahun','36 - 50 tahun',2,0,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(92,89,'> 50 tahun','> 50 tahun',3,0,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `question_options` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) unsigned NOT NULL,
  `type` enum('short_text','long_text','multiple_choice','checkboxes','dropdown','rating','star_rating','nps','matrix','file_upload','date','time','datetime','linear_scale','email','phone','url','number','hidden','calculated') NOT NULL,
  `title` varchar(1000) NOT NULL,
  `description` text DEFAULT NULL,
  `placeholder` varchar(255) DEFAULT NULL,
  `help_text` text DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL DEFAULT 0,
  `validation_rules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`validation_rules`)),
  `logic_rules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`logic_rules`)),
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `questions_section_id_index` (`section_id`),
  KEY `questions_type_index` (`type`),
  KEY `questions_order_index` (`order`),
  CONSTRAINT `questions_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `survey_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `questions` VALUES
(1,1,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(2,1,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(3,2,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(4,2,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(5,3,'rating','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 14:45:32'),
(6,3,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,1,2,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 15:03:33'),
(7,4,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(8,4,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(9,5,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(10,5,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,1,2,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 15:01:43'),
(11,6,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(12,6,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(13,7,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(14,7,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,1,2,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 14:59:46'),
(15,8,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(16,8,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(17,9,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(18,9,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(19,10,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(20,10,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(21,11,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(22,11,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(23,12,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(24,12,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(25,13,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(26,13,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(27,14,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(28,14,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(29,15,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(30,15,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(31,16,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(32,16,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(33,17,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(34,17,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(35,18,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(36,18,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(37,19,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(38,19,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(39,20,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(40,20,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(41,21,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(42,21,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(43,22,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(44,22,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(45,23,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(46,23,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(47,24,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(48,24,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(49,25,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(50,25,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(51,26,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(52,26,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(53,27,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(54,27,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(55,28,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(56,28,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(57,29,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(58,29,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(59,30,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(60,30,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(61,31,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(62,31,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(63,32,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(64,32,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(65,33,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(66,33,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(67,34,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(68,34,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(69,35,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(70,35,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(71,36,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(72,36,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(73,37,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(74,37,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(75,38,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(76,38,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(77,39,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(78,39,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(79,40,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(80,40,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(81,41,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(82,41,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(83,42,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(84,42,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(85,43,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(86,43,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(87,44,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(88,44,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(89,45,'multiple_choice','Kelompok Usia Anda',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(90,45,'short_text','Pekerjaan Saat Ini',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(91,46,'rating','Seberapa puas Anda dengan layanan kami?',NULL,NULL,NULL,1,1,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(92,46,'long_text','Kritik dan Saran untuk perbaikan ke depan',NULL,NULL,NULL,0,2,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `endpoint` varchar(255) NOT NULL,
  `max_requests` int(11) NOT NULL,
  `window_seconds` int(11) NOT NULL DEFAULT 60,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rate_limits_client_id_endpoint_unique` (`client_id`,`endpoint`),
  CONSTRAINT `rate_limits_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `api_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `response_analytics`
--

DROP TABLE IF EXISTS `response_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `response_analytics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` bigint(20) unsigned NOT NULL,
  `sentiment_score` decimal(5,4) DEFAULT NULL,
  `keywords` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`keywords`)),
  `anomaly_score` decimal(5,4) DEFAULT NULL,
  `fraud_probability` decimal(5,4) DEFAULT NULL,
  `quality_metrics` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`quality_metrics`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `response_analytics_response_id_index` (`response_id`),
  CONSTRAINT `response_analytics_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response_analytics`
--

LOCK TABLES `response_analytics` WRITE;
/*!40000 ALTER TABLE `response_analytics` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `response_analytics` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `response_answers`
--

DROP TABLE IF EXISTS `response_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `response_answers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` bigint(20) unsigned NOT NULL,
  `question_id` bigint(20) unsigned NOT NULL,
  `option_id` bigint(20) unsigned DEFAULT NULL,
  `answer_text` text DEFAULT NULL,
  `answer_numeric` decimal(15,4) DEFAULT NULL,
  `answer_date` date DEFAULT NULL,
  `answer_file_id` bigint(20) unsigned DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `response_answers_question_id_foreign` (`question_id`),
  KEY `response_answers_option_id_foreign` (`option_id`),
  KEY `response_answers_response_id_question_id_index` (`response_id`,`question_id`),
  CONSTRAINT `response_answers_option_id_foreign` FOREIGN KEY (`option_id`) REFERENCES `question_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `response_answers_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `response_answers_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=489 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response_answers`
--

LOCK TABLES `response_answers` WRITE;
/*!40000 ALTER TABLE `response_answers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `response_answers` VALUES
(1,1,1,3,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(2,1,2,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(3,1,3,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(4,1,4,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(5,2,1,1,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(6,2,2,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(7,2,3,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(8,2,4,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(9,3,1,1,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(10,3,2,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(11,3,3,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(12,3,4,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(13,4,1,3,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(14,4,2,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(15,4,3,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(16,4,4,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(17,5,1,2,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(18,5,2,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(19,5,3,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(20,5,4,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(21,6,5,8,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(22,6,6,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(23,6,7,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(24,6,8,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(25,7,5,8,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(26,7,6,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(27,7,7,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(28,7,8,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(29,8,5,8,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(30,8,6,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(31,8,7,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(32,8,8,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(33,9,5,8,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(34,9,6,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(35,9,7,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(36,9,8,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(37,10,5,5,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(38,10,6,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(39,10,7,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(40,10,8,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(41,11,9,10,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(42,11,10,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(43,11,11,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(44,11,12,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(45,12,9,12,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(46,12,10,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(47,12,11,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(48,12,12,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(49,13,9,11,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(50,13,10,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(51,13,11,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(52,13,12,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(53,14,9,12,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(54,14,10,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(55,14,11,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(56,14,12,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(57,15,9,10,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(58,15,10,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(59,15,11,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(60,15,12,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(61,16,13,16,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(62,16,14,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(63,16,15,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(64,16,16,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(65,17,13,16,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(66,17,14,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(67,17,15,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(68,17,16,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(69,18,13,16,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(70,18,14,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(71,18,15,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(72,18,16,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(73,19,13,13,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(74,19,14,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(75,19,15,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(76,19,16,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(77,20,13,16,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(78,20,14,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(79,20,15,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(80,20,16,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(81,21,17,20,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(82,21,18,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(83,21,19,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(84,21,20,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(85,22,17,19,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(86,22,18,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(87,22,19,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(88,22,20,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(89,23,17,19,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(90,23,18,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(91,23,19,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(92,23,20,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(93,24,17,20,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(94,24,18,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(95,24,19,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(96,24,20,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(97,25,17,18,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(98,25,18,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(99,25,19,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(100,25,20,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(101,26,21,21,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(102,26,22,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(103,26,23,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(104,26,24,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(105,27,21,23,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(106,27,22,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(107,27,23,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(108,27,24,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(109,28,21,21,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(110,28,22,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(111,28,23,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(112,28,24,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(113,29,21,21,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(114,29,22,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(115,29,23,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(116,29,24,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(117,30,21,23,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(118,30,22,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(119,30,23,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(120,30,24,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(121,31,25,25,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(122,31,26,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(123,31,27,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(124,31,28,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(125,32,25,25,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(126,32,26,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(127,32,27,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(128,32,28,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(129,33,25,28,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(130,33,26,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(131,33,27,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(132,33,28,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(133,34,25,26,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(134,34,26,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(135,34,27,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(136,34,28,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(137,35,25,28,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(138,35,26,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(139,35,27,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(140,35,28,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(141,36,29,31,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(142,36,30,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(143,36,31,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(144,36,32,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(145,37,29,29,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(146,37,30,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(147,37,31,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(148,37,32,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(149,38,29,32,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(150,38,30,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(151,38,31,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(152,38,32,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(153,39,29,29,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(154,39,30,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(155,39,31,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(156,39,32,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(157,40,29,31,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(158,40,30,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(159,40,31,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(160,40,32,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(161,41,33,33,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(162,41,34,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(163,41,35,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(164,41,36,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(165,42,33,36,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(166,42,34,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(167,42,35,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(168,42,36,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(169,43,33,36,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(170,43,34,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(171,43,35,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(172,43,36,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(173,44,33,34,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(174,44,34,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(175,44,35,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(176,44,36,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(177,45,33,35,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(178,45,34,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(179,45,35,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(180,45,36,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(181,46,37,40,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(182,46,38,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(183,46,39,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(184,46,40,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(185,47,37,37,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(186,47,38,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(187,47,39,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(188,47,40,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(189,48,37,40,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(190,48,38,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(191,48,39,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(192,48,40,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(193,49,37,38,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(194,49,38,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(195,49,39,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(196,49,40,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(197,50,37,39,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(198,50,38,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(199,50,39,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(200,50,40,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(201,51,41,43,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(202,51,42,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(203,51,43,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(204,51,44,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(205,52,41,43,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(206,52,42,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(207,52,43,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(208,52,44,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(209,53,41,42,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(210,53,42,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(211,53,43,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(212,53,44,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(213,54,41,43,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(214,54,42,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(215,54,43,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(216,54,44,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(217,55,41,43,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(218,55,42,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(219,55,43,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(220,55,44,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(221,56,45,45,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(222,56,46,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(223,56,47,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(224,56,48,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(225,57,45,46,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(226,57,46,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(227,57,47,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(228,57,48,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(229,58,45,47,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(230,58,46,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(231,58,47,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(232,58,48,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(233,59,45,46,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(234,59,46,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(235,59,47,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(236,59,48,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(237,60,45,48,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(238,60,46,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(239,60,47,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(240,60,48,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(241,61,49,51,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(242,61,50,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(243,61,51,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(244,61,52,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(245,62,49,50,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(246,62,50,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(247,62,51,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(248,62,52,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(249,63,49,52,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(250,63,50,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(251,63,51,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(252,63,52,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(253,64,49,49,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(254,64,50,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(255,64,51,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(256,64,52,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(257,65,49,49,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(258,65,50,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(259,65,51,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(260,65,52,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(261,66,53,56,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(262,66,54,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(263,66,55,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(264,66,56,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(265,67,53,53,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(266,67,54,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(267,67,55,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(268,67,56,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(269,68,53,53,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(270,68,54,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(271,68,55,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(272,68,56,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(273,69,53,54,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(274,69,54,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(275,69,55,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(276,69,56,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(277,70,53,56,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(278,70,54,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(279,70,55,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(280,70,56,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(281,71,57,59,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(282,71,58,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(283,71,59,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(284,71,60,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(285,72,57,60,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(286,72,58,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(287,72,59,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(288,72,60,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(289,73,57,57,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(290,73,58,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(291,73,59,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(292,73,60,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(293,74,57,57,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(294,74,58,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(295,74,59,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(296,74,60,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(297,75,57,60,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(298,75,58,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(299,75,59,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(300,75,60,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(301,76,61,63,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(302,76,62,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(303,76,63,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(304,76,64,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(305,77,61,64,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(306,77,62,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(307,77,63,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(308,77,64,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(309,78,61,61,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(310,78,62,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(311,78,63,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(312,78,64,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(313,79,61,64,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(314,79,62,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(315,79,63,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(316,79,64,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(317,80,61,64,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(318,80,62,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(319,80,63,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(320,80,64,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(321,81,65,65,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(322,81,66,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(323,81,67,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(324,81,68,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(325,82,65,68,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(326,82,66,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(327,82,67,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(328,82,68,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(329,83,65,65,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(330,83,66,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(331,83,67,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(332,83,68,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(333,84,65,67,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(334,84,66,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(335,84,67,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(336,84,68,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(337,85,65,68,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(338,85,66,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(339,85,67,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(340,85,68,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(341,86,69,71,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(342,86,70,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(343,86,71,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(344,86,72,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(345,87,69,70,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(346,87,70,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(347,87,71,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(348,87,72,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(349,88,69,71,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(350,88,70,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(351,88,71,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(352,88,72,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(353,89,69,69,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(354,89,70,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(355,89,71,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(356,89,72,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(357,90,69,71,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(358,90,70,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(359,90,71,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(360,90,72,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(361,91,73,73,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(362,91,74,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(363,91,75,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(364,91,76,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(365,92,73,74,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(366,92,74,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(367,92,75,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(368,92,76,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(369,93,73,75,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(370,93,74,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(371,93,75,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(372,93,76,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(373,94,73,74,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(374,94,74,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(375,94,75,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(376,94,76,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(377,95,73,73,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(378,95,74,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(379,95,75,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(380,95,76,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(381,96,77,80,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(382,96,78,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(383,96,79,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(384,96,80,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(385,97,77,77,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(386,97,78,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(387,97,79,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(388,97,80,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(389,98,77,79,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(390,98,78,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(391,98,79,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(392,98,80,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(393,99,77,80,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(394,99,78,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(395,99,79,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(396,99,80,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(397,100,77,77,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(398,100,78,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(399,100,79,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(400,100,80,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(401,101,81,82,'21 - 35 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(402,101,82,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(403,101,83,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(404,101,84,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(405,102,81,83,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(406,102,82,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(407,102,83,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(408,102,84,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(409,103,81,83,'36 - 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(410,103,82,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(411,103,83,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(412,103,84,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(413,104,81,81,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(414,104,82,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(415,104,83,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(416,104,84,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(417,105,81,84,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(418,105,82,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(419,105,83,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(420,105,84,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(421,106,85,85,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(422,106,86,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(423,106,87,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(424,106,88,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(425,107,85,85,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(426,107,86,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(427,107,87,NULL,NULL,3.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(428,107,88,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(429,108,85,85,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(430,108,86,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(431,108,87,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(432,108,88,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(433,109,85,88,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(434,109,86,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(435,109,87,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(436,109,88,NULL,'Layanan sangat membantu, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(437,110,85,85,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(438,110,86,NULL,'Mahasiswa',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(439,110,87,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(440,110,88,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(441,111,89,92,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(442,111,90,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(443,111,91,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(444,111,92,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(445,112,89,92,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(446,112,90,NULL,'Karyawan Swasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(447,112,91,NULL,NULL,4.0000,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(448,112,92,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(449,113,89,89,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(450,113,90,NULL,'Buruh',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(451,113,91,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(452,113,92,NULL,'Layanan sangat bagus, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(453,114,89,92,'> 50 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(454,114,90,NULL,'PNS',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(455,114,91,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(456,114,92,NULL,'Layanan sangat cepat, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(457,115,89,89,'< 20 tahun',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(458,115,90,NULL,'Wiraswasta',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(459,115,91,NULL,NULL,5.0000,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(460,115,92,NULL,'Layanan sangat baik, mohon dipertahankan.',NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(461,116,5,5,NULL,NULL,NULL,NULL,NULL,'2026-02-17 15:08:56','2026-02-17 15:08:56'),
(462,116,6,NULL,'test',NULL,NULL,NULL,NULL,'2026-02-17 15:08:56','2026-02-17 15:08:56'),
(463,116,7,5,NULL,NULL,NULL,NULL,NULL,'2026-02-17 15:08:56','2026-02-17 15:08:56'),
(464,116,8,NULL,'test',NULL,NULL,NULL,NULL,'2026-02-17 15:08:56','2026-02-17 15:08:56'),
(465,117,5,5,NULL,NULL,NULL,NULL,NULL,'2026-02-17 15:10:26','2026-02-17 15:10:26'),
(466,117,6,NULL,'tes',NULL,NULL,NULL,NULL,'2026-02-17 15:10:26','2026-02-17 15:10:26'),
(467,117,7,4,NULL,NULL,NULL,NULL,NULL,'2026-02-17 15:10:26','2026-02-17 15:10:26'),
(468,117,8,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 15:10:26','2026-02-17 15:10:26'),
(469,118,5,NULL,'5',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:42:53','2026-02-17 15:42:53'),
(470,118,6,NULL,'test',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:42:53','2026-02-17 15:42:53'),
(471,118,7,NULL,'5',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:42:53','2026-02-17 15:42:53'),
(472,118,8,NULL,'test',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:42:53','2026-02-17 15:42:53'),
(473,119,9,9,NULL,NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:55:04','2026-02-17 15:55:04'),
(474,119,10,NULL,'tst',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:55:04','2026-02-17 15:55:04'),
(475,119,11,NULL,'5',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:55:04','2026-02-17 15:55:04'),
(476,119,12,NULL,'rtst',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:55:04','2026-02-17 15:55:04'),
(477,120,13,13,NULL,NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:58:41','2026-02-17 15:58:41'),
(478,120,14,NULL,'test',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:58:41','2026-02-17 15:58:41'),
(479,120,15,NULL,'5',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:58:41','2026-02-17 15:58:41'),
(480,120,16,NULL,'test',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-17 15:58:41','2026-02-17 15:58:41'),
(481,121,5,NULL,'5',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:07:41','2026-02-19 18:07:41'),
(482,121,6,NULL,'test',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:07:41','2026-02-19 18:07:41'),
(483,121,7,NULL,'4',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:07:41','2026-02-19 18:07:41'),
(484,121,8,NULL,'tet',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:07:41','2026-02-19 18:07:41'),
(485,122,5,NULL,'1',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:08:44','2026-02-19 18:08:44'),
(486,122,6,NULL,'test',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:08:44','2026-02-19 18:08:44'),
(487,122,7,NULL,'1',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:08:44','2026-02-19 18:08:44'),
(488,122,8,NULL,'sd',NULL,NULL,NULL,'{\"answer_json\":null}','2026-02-19 18:08:44','2026-02-19 18:08:44');
/*!40000 ALTER TABLE `response_answers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `response_files`
--

DROP TABLE IF EXISTS `response_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `response_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` bigint(20) unsigned NOT NULL,
  `question_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `mime_type` varchar(255) NOT NULL,
  `is_scanned` tinyint(1) NOT NULL DEFAULT 0,
  `scan_result` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `response_files_question_id_foreign` (`question_id`),
  KEY `response_files_response_id_index` (`response_id`),
  CONSTRAINT `response_files_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `response_files_response_id_foreign` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response_files`
--

LOCK TABLES `response_files` WRITE;
/*!40000 ALTER TABLE `response_files` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `response_files` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission_role_id_permission_id_unique` (`role_id`,`permission_id`),
  KEY `role_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `role_permission` VALUES
(1,1,1,NULL,NULL),
(2,2,1,NULL,NULL),
(3,1,2,NULL,NULL),
(4,2,2,NULL,NULL),
(5,1,3,NULL,NULL);
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`),
  KEY `roles_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `roles` VALUES
(1,'Super Admin','super_admin','Full system access','2026-02-17 04:53:22','2026-02-17 04:53:22'),
(2,'Tenant Admin','tenant_admin','Manage tenant surveys','2026-02-17 04:53:22','2026-02-17 04:53:22');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sessions` VALUES
('SR2rfUUhBdk4ooguqPR06zyWLMZCZ7PtvKzaviGF',1,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiN2hYRnZ6MkZGUlRhbDlrOTZGaUliZ2pVdHEybWowRnFWUWZtRWxhOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMi9zdXJ2ZXkvZjc0Yzc4MjgtOWRlNC00ZDA1LWI3YTQtMDcyN2M1M2IzZjZiIjtzOjU6InJvdXRlIjtzOjE4OiJwdWJsaWMuc3VydmV5LnNob3ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjY0OiI0NWUzMjc4ZjgzM2RiOGI2MGIyMThjZjYzM2U1MTNjYjllMDViM2I2NTc4NWU3ZWJlYTQ0NGNkYzkzMTdiMDkzIjtzOjg6ImZpbGFtZW50IjthOjA6e319',1771529722),
('Xrx2XGpkx6WiB5AQU3O9tlJQT6Okn5AOYkkBwANo',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiRDJSQ1REY1hHNE1FZjJ6UTRONWEwdFZER1E0WU1pbTM2Vk15M21RdiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771560957);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_distributions`
--

DROP TABLE IF EXISTS `survey_distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_distributions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `channel` enum('link','embed','api','email','sms') NOT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_distributions_survey_id_index` (`survey_id`),
  CONSTRAINT `survey_distributions_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_distributions`
--

LOCK TABLES `survey_distributions` WRITE;
/*!40000 ALTER TABLE `survey_distributions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survey_distributions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_links`
--

DROP TABLE IF EXISTS `survey_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `distribution_id` bigint(20) unsigned NOT NULL,
  `token` varchar(255) NOT NULL,
  `max_responses` int(11) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `survey_links_token_unique` (`token`),
  KEY `survey_links_distribution_id_foreign` (`distribution_id`),
  KEY `survey_links_token_index` (`token`),
  CONSTRAINT `survey_links_distribution_id_foreign` FOREIGN KEY (`distribution_id`) REFERENCES `survey_distributions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_links`
--

LOCK TABLES `survey_links` WRITE;
/*!40000 ALTER TABLE `survey_links` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survey_links` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_quotas`
--

DROP TABLE IF EXISTS `survey_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_quotas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `max_responses` int(11) NOT NULL DEFAULT 0,
  `current_count` int(11) NOT NULL DEFAULT 0,
  `demographic_limits` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`demographic_limits`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_quotas_survey_id_index` (`survey_id`),
  CONSTRAINT `survey_quotas_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_quotas`
--

LOCK TABLES `survey_quotas` WRITE;
/*!40000 ALTER TABLE `survey_quotas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survey_quotas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_responses`
--

DROP TABLE IF EXISTS `survey_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_responses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `survey_id` bigint(20) unsigned NOT NULL,
  `respondent_id` bigint(20) unsigned DEFAULT NULL,
  `link_id` bigint(20) unsigned DEFAULT NULL,
  `respondent_name` varchar(255) DEFAULT NULL,
  `respondent_email` varchar(255) DEFAULT NULL,
  `respondent_phone` varchar(255) DEFAULT NULL,
  `respondent_nik` varchar(255) DEFAULT NULL,
  `status` enum('draft','completed','validated','flagged') NOT NULL DEFAULT 'draft',
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `submitted_at` timestamp NULL DEFAULT NULL,
  `completion_time_seconds` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','unknown') DEFAULT NULL,
  `geo_location` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`geo_location`)),
  `quality_score` decimal(5,2) DEFAULT NULL,
  `is_flagged` tinyint(1) NOT NULL DEFAULT 0,
  `flag_reason` varchar(500) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `session_token` varchar(64) DEFAULT NULL,
  `fingerprint` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `survey_responses_uuid_unique` (`uuid`),
  KEY `survey_responses_link_id_foreign` (`link_id`),
  KEY `survey_responses_survey_id_index` (`survey_id`),
  KEY `survey_responses_status_index` (`status`),
  KEY `survey_responses_submitted_at_index` (`submitted_at`),
  KEY `survey_responses_respondent_id_index` (`respondent_id`),
  KEY `survey_responses_respondent_email_index` (`respondent_email`),
  KEY `survey_responses_session_token_index` (`session_token`),
  KEY `survey_responses_survey_id_respondent_email_index` (`survey_id`,`respondent_email`),
  CONSTRAINT `survey_responses_link_id_foreign` FOREIGN KEY (`link_id`) REFERENCES `survey_links` (`id`) ON DELETE SET NULL,
  CONSTRAINT `survey_responses_respondent_id_foreign` FOREIGN KEY (`respondent_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `survey_responses_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_responses`
--

LOCK TABLES `survey_responses` WRITE;
/*!40000 ALTER TABLE `survey_responses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survey_responses` VALUES
(1,'5295c2de-015f-40af-a3f5-54d1025702ed',1,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:26:23','2026-02-15 04:53:23',323,'192.168.1.44','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 13:47:25','2026-02-17 13:47:25'),
(2,'2b57bc61-5c16-42d0-bc48-3958326d7471',1,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:35:23','2026-02-15 04:53:23',291,'192.168.1.82','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 13:47:25','2026-02-17 13:47:25'),
(3,'15e0dac6-c3ca-40d7-920f-b3de19b828a7',1,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:42:23','2026-02-12 04:53:23',416,'192.168.1.49','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 13:47:25','2026-02-17 13:47:25'),
(4,'a9a7b2ce-f381-433d-8f74-fc89d3d017d0',1,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:11:23','2026-02-14 04:53:23',342,'192.168.1.61','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 13:47:25','2026-02-17 13:47:25'),
(5,'52f6db05-12e6-4dab-b474-17f7aa2b8a1f',1,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:02:23','2026-02-14 04:53:23',241,'192.168.1.7','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 13:47:25','2026-02-17 13:47:25'),
(6,'bbb85bf5-c625-4c3a-adb6-b43737a4b131',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:17:53','2026-02-15 04:54:53',219,'192.168.1.130','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53',NULL),
(7,'ac308a68-c028-43c2-b9f0-ca7bb5ae6773',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 03:58:53','2026-02-08 04:54:53',479,'192.168.1.233','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53',NULL),
(8,'9a9bb473-4637-45d0-8d22-c488e96898c1',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:26:53','2026-02-13 04:54:53',557,'192.168.1.170','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53',NULL),
(9,'ce5dce50-8ed0-45ea-ab36-57faed7eb87b',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:10:53','2026-02-13 04:54:53',491,'192.168.1.111','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53',NULL),
(10,'1179e68e-77b2-4220-a99d-67fc5ffe4f9c',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 03:57:53','2026-02-15 04:54:53',413,'192.168.1.1','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53',NULL),
(11,'b6dbe5c5-c56c-4d9e-9999-8fc7948a5286',3,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:33:21','2026-02-16 04:55:21',324,'192.168.1.110','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21',NULL),
(12,'12b34dae-b418-4670-a258-1c346a35321e',3,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 03:57:21','2026-02-10 04:55:21',566,'192.168.1.217','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21',NULL),
(13,'e0d50ae5-9b90-4fdd-a7f9-2601cdc54c39',3,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 03:58:21','2026-02-14 04:55:21',526,'192.168.1.249','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21',NULL),
(14,'fca433f9-bcee-4a71-8665-217e5373700c',3,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:01:21','2026-02-08 04:55:21',452,'192.168.1.143','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21',NULL),
(15,'6ba4173d-4c2a-499f-a6c6-bbaee4c5b799',3,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:31:21','2026-02-10 04:55:21',305,'192.168.1.95','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21',NULL),
(16,'b1a81cd2-6792-4518-9015-be9f87eb25cf',4,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:18:07','2026-02-14 04:56:07',240,'192.168.1.152','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(17,'f6f7a8c1-5d41-4d2f-a9f7-59f65b15e771',4,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:41:07','2026-02-13 04:56:07',332,'192.168.1.251','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(18,'5fdcf9e5-b786-49cb-8d40-50ebdf3f7aea',4,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:13:07','2026-02-11 04:56:07',552,'192.168.1.144','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(19,'1d83b81e-59a5-49b2-ad49-d8db34f3723d',4,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 03:57:07','2026-02-12 04:56:07',150,'192.168.1.125','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(20,'cab77207-7468-473f-a683-04358b67e546',4,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:18:07','2026-02-13 04:56:07',259,'192.168.1.85','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(21,'87bf5577-8d14-4f55-b177-c11630125a6a',5,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:29:07','2026-02-10 04:56:07',349,'192.168.1.64','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(22,'76be4e20-325c-4c4d-993b-0b989f5a261f',5,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:12:07','2026-02-10 04:56:07',163,'192.168.1.183','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(23,'063b0fe4-cff6-41e3-9495-c45d6777488d',5,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:11:07','2026-02-14 04:56:07',287,'192.168.1.251','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(24,'fd00a358-432f-478a-86ac-d613fd3d9e0b',5,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:22:07','2026-02-09 04:56:07',454,'192.168.1.162','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(25,'ceee100f-babb-4b87-82b4-df6368e24fe3',5,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:09:07','2026-02-09 04:56:07',191,'192.168.1.167','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(26,'21190475-806e-4910-b5bf-f281b582810b',6,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:17:07','2026-02-10 04:56:07',541,'192.168.1.55','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(27,'25678a1f-42c9-4f0f-8651-ccba3795c6af',6,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:09:07','2026-02-15 04:56:07',418,'192.168.1.68','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(28,'054f9862-c5e8-432b-ac3a-bc866e114f53',6,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:35:07','2026-02-12 04:56:07',433,'192.168.1.197','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(29,'fb4d3b96-a10e-4ef5-b7e1-5c37dc97377e',6,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:38:07','2026-02-10 04:56:07',352,'192.168.1.54','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(30,'609b8f99-a66d-4e5f-9e57-3129b9b706dc',6,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:07:07','2026-02-08 04:56:07',170,'192.168.1.90','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(31,'09147250-aa3b-476f-8d9e-ee617ec3f278',7,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:35:08','2026-02-11 04:56:08',216,'192.168.1.67','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(32,'ebe6dd80-def8-4528-a827-1f5a30b93043',7,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:25:08','2026-02-14 04:56:08',466,'192.168.1.59','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(33,'0501a6c8-5c1e-475a-90f1-4ca048062b9a',7,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:22:08','2026-02-13 04:56:08',263,'192.168.1.206','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(34,'ccbec9ef-0068-454f-82f3-4e893ed86f2c',7,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:18:08','2026-02-16 04:56:08',332,'192.168.1.29','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(35,'69410eae-3b57-427e-a456-0a15774051e9',7,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:25:08','2026-02-08 04:56:08',407,'192.168.1.129','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(36,'cc6c0819-d14d-479b-9e91-1f5ff17b3bf2',8,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:00:08','2026-02-10 04:56:08',188,'192.168.1.127','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(37,'8dcb22cb-e86d-471f-8624-437cab632ea0',8,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:17:08','2026-02-11 04:56:08',431,'192.168.1.110','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(38,'90280835-a02f-46fa-bdb3-f8a62f43e9b9',8,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:43:08','2026-02-12 04:56:08',166,'192.168.1.206','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(39,'c54fe720-dad1-4a9e-a092-6e3a4b543684',8,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:06:08','2026-02-09 04:56:08',459,'192.168.1.38','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(40,'b420285b-dc1c-4a39-a968-b42914924cbe',8,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 03:59:08','2026-02-09 04:56:08',315,'192.168.1.99','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(41,'a91994b2-1814-4790-aa2f-cca88515552c',9,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:37:08','2026-02-09 04:56:08',523,'192.168.1.106','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(42,'6f4f7c11-517d-4743-af69-e69460b60ee3',9,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:32:08','2026-02-14 04:56:08',283,'192.168.1.92','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(43,'ca6431cf-af95-467f-94e2-9e4ece43ad09',9,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:43:08','2026-02-11 04:56:08',469,'192.168.1.82','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(44,'232c33e2-b89f-42e7-a4e5-179d8f0d60da',9,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:19:08','2026-02-09 04:56:08',265,'192.168.1.112','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(45,'df2e83da-a228-4986-8d3d-8e1d9ccfc6ef',9,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:32:08','2026-02-14 04:56:08',294,'192.168.1.21','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(46,'edaaf30e-62e4-425a-a483-989585343aa0',10,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:04:09','2026-02-08 04:56:09',237,'192.168.1.252','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(47,'0ad8823c-1c12-40f9-b07a-04bead401a87',10,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:46:09','2026-02-15 04:56:09',452,'192.168.1.135','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(48,'6b0cfeb6-957f-4f83-a36f-c830c3ef0632',10,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:34:09','2026-02-13 04:56:09',524,'192.168.1.1','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(49,'aab7ecce-0852-4819-bf8f-fe1ad3bff124',10,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:23:09','2026-02-16 04:56:09',410,'192.168.1.209','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(50,'8246e1a7-c9ea-44a8-9814-4ad9957193d1',10,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:05:09','2026-02-12 04:56:09',531,'192.168.1.84','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(51,'a78b11ef-de27-43e1-8dd9-f3232441964e',11,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 03:56:09','2026-02-10 04:56:09',129,'192.168.1.97','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(52,'21fa62da-f8b0-45f6-a276-3a2236d31ffc',11,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:28:09','2026-02-16 04:56:09',242,'192.168.1.13','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(53,'4bf76f2d-2cd1-4ffe-ba9c-e7cd8f742cb3',11,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:27:09','2026-02-11 04:56:09',329,'192.168.1.152','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(54,'d92b2848-225f-4659-8d68-51db69653cbd',11,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:37:09','2026-02-12 04:56:09',128,'192.168.1.74','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(55,'9b53bfd4-6cd0-4c14-bb1d-12346219dcc9',11,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:44:09','2026-02-13 04:56:09',228,'192.168.1.149','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(56,'60b1d365-d6c4-4a3a-8414-def36ef098d3',12,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:13:09','2026-02-13 04:56:09',200,'192.168.1.127','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(57,'c864de31-b2c2-43f2-95f8-be0bed7e181a',12,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:11:09','2026-02-12 04:56:09',573,'192.168.1.176','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(58,'ba2c9831-f5ec-4a66-8c43-850b2527d53a',12,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:21:09','2026-02-16 04:56:09',491,'192.168.1.11','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(59,'70e9abcf-8fbf-4295-9422-bb7bf258a6ad',12,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:37:09','2026-02-15 04:56:09',556,'192.168.1.98','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(60,'fe704a95-385a-4c1c-91bb-0abf259b592f',12,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:27:09','2026-02-14 04:56:09',204,'192.168.1.151','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(61,'6133d05d-1706-4a78-bfa9-2068471ee770',13,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:01:10','2026-02-10 04:56:10',324,'192.168.1.26','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(62,'da1c1e3a-9d6e-4379-9fe5-122c12a7d9de',13,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:13:10','2026-02-09 04:56:10',176,'192.168.1.199','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(63,'c47f0dc1-a6f5-47b3-9698-565beefbb917',13,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:12:10','2026-02-09 04:56:10',279,'192.168.1.222','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(64,'21899af8-2cd4-4ef8-8a33-8ac5854818c5',13,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:35:10','2026-02-10 04:56:10',347,'192.168.1.16','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(65,'e5986d81-3e76-47fb-ab72-85447af18332',13,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:39:10','2026-02-15 04:56:10',433,'192.168.1.200','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(66,'909af3fd-c2d5-4eb5-8f80-3e715da23975',14,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:31:04','2026-02-10 04:57:04',516,'192.168.1.247','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(67,'1b518df5-347b-476d-9318-d10ad63b7fe2',14,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:38:04','2026-02-16 04:57:04',149,'192.168.1.119','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(68,'54a57038-55ab-4b25-93df-e0790acd048e',14,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:28:04','2026-02-13 04:57:04',203,'192.168.1.56','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(69,'6bcae8a9-efb9-4acc-852c-befa91600a53',14,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:24:04','2026-02-10 04:57:04',478,'192.168.1.166','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(70,'b2e617e8-c4ad-4ae9-80ae-0533a9aecb1a',14,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 03:59:04','2026-02-14 04:57:04',445,'192.168.1.176','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(71,'b3823cb8-9eb4-43bd-9b84-7493842b5198',15,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:09:04','2026-02-11 04:57:04',465,'192.168.1.239','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(72,'e0c6100b-10e3-4464-afff-e31867cdaaa0',15,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:03:04','2026-02-14 04:57:04',439,'192.168.1.174','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(73,'c0d93d62-6383-4717-bce9-30585309b97a',15,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:37:04','2026-02-11 04:57:04',490,'192.168.1.3','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(74,'56a40c8f-9235-4344-9a91-81d46b38a7c9',15,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:43:04','2026-02-11 04:57:04',572,'192.168.1.211','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(75,'fc95264d-028e-486d-a912-29e140889b10',15,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:30:04','2026-02-09 04:57:04',325,'192.168.1.83','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(76,'af10e752-cb3c-4d18-ab5f-809538643b50',16,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:06:04','2026-02-12 04:57:04',388,'192.168.1.96','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(77,'2c86b18c-4142-45c5-b09c-9eb79525fa80',16,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 03:59:04','2026-02-12 04:57:04',325,'192.168.1.191','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(78,'5337cfcb-1669-4cab-8771-9df0b82459f7',16,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:19:04','2026-02-10 04:57:04',404,'192.168.1.18','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(79,'ca57e8fe-d03a-4e2d-b011-215fc0b61d32',16,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:16:04','2026-02-12 04:57:04',271,'192.168.1.122','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(80,'e9973eb1-d1e0-42f9-9a81-134d7b3f82df',16,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:19:04','2026-02-08 04:57:04',132,'192.168.1.110','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(81,'a72773ab-84f6-4b4a-847a-bab732551e03',17,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 03:58:05','2026-02-11 04:57:05',139,'192.168.1.226','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(82,'888c8782-62fa-4e17-aea8-a98bc3c2d4dd',17,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:05:05','2026-02-13 04:57:05',286,'192.168.1.245','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(83,'03c7679b-7b8b-4913-a670-6870043ceac3',17,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:35:05','2026-02-09 04:57:05',450,'192.168.1.40','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(84,'05abd443-d69e-493d-9fc7-ee2369fc4418',17,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:15:05','2026-02-11 04:57:05',386,'192.168.1.140','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(85,'a8d4177a-f84a-4d96-b5d8-848e1c7a250a',17,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:22:05','2026-02-13 04:57:05',517,'192.168.1.144','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(86,'b0e9da35-cc6e-4f25-84a0-b29c81b6420b',18,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:18:05','2026-02-15 04:57:05',168,'192.168.1.132','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(87,'37a26497-bff3-4dba-aed1-ea3d04437961',18,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:22:05','2026-02-12 04:57:05',260,'192.168.1.238','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(88,'4a0f180f-2ffc-4e95-9f96-e52217794a07',18,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:03:05','2026-02-14 04:57:05',533,'192.168.1.64','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(89,'da3c9183-4289-4a2a-9490-0f68f6de3d96',18,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:11:05','2026-02-10 04:57:05',251,'192.168.1.123','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(90,'dabcfcae-377e-4eb8-86aa-dcfaab956b48',18,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:19:05','2026-02-13 04:57:05',252,'192.168.1.74','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(91,'937e8078-bcd0-436e-a928-8e20c6e44eb4',19,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:31:05','2026-02-12 04:57:05',508,'192.168.1.243','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(92,'9a0da013-e575-429a-a1e7-2b4456cf6b30',19,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:03:05','2026-02-09 04:57:05',525,'192.168.1.240','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(93,'9eec61ce-10a0-46a7-9fcc-9ce0bb138ef4',19,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:26:05','2026-02-09 04:57:05',345,'192.168.1.59','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(94,'14aca898-177e-4974-85fa-786343b8adcc',19,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:01:05','2026-02-15 04:57:05',563,'192.168.1.149','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(95,'9666c3c2-943e-40a3-844e-bc6653965e2c',19,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:24:05','2026-02-10 04:57:05',380,'192.168.1.202','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(96,'eb3c1e1a-8443-46e9-91c5-d821af40817a',20,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:11:06','2026-02-13 04:57:06',516,'192.168.1.215','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(97,'a5e59289-c529-4874-a019-d5543a921518',20,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:33:06','2026-02-11 04:57:06',581,'192.168.1.83','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(98,'add4fcd3-78c6-430f-82f2-82b12d33ded9',20,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:11:06','2026-02-14 04:57:06',246,'192.168.1.7','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(99,'5e4b6487-1331-4039-b3db-990778cf23b1',20,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:19:06','2026-02-16 04:57:06',321,'192.168.1.188','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(100,'c01bdb0f-76ed-42ac-b061-8e814bb09f95',20,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 03:58:06','2026-02-13 04:57:06',574,'192.168.1.21','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(101,'403c613e-0d84-42ae-8879-98aedba589db',21,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:03:06','2026-02-15 04:57:06',334,'192.168.1.126','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(102,'5024d955-fb7f-4e8b-8efd-82fe3279d073',21,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-13 04:26:06','2026-02-11 04:57:06',187,'192.168.1.236','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(103,'81acdc69-48fd-4f55-935f-acdccbef9f3a',21,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:26:06','2026-02-16 04:57:06',245,'192.168.1.46','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(104,'2c4f69ee-da66-4370-8f24-921c2dfeab4c',21,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:42:06','2026-02-15 04:57:06',476,'192.168.1.166','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(105,'3055ce74-e915-4e74-b608-9965667b6bb4',21,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:31:06','2026-02-10 04:57:06',371,'192.168.1.133','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(106,'66f7c112-44e2-45ae-a7eb-81f3c9a55b62',22,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-10 04:06:06','2026-02-10 04:57:06',163,'192.168.1.199','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(107,'d63d4cd0-a81c-41d9-9d0d-bdcce1aa2798',22,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:35:06','2026-02-14 04:57:06',599,'192.168.1.251','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(108,'842012b1-1a62-491c-b5cb-ea92979cc9f9',22,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-09 04:39:06','2026-02-10 04:57:06',397,'192.168.1.164','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(109,'507d7782-1f8a-4908-ab43-73ca6c7be852',22,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:32:06','2026-02-12 04:57:06',423,'192.168.1.129','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(110,'67fcb10b-e16c-4c88-b6d3-c6ab8d97306b',22,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-14 04:09:06','2026-02-14 04:57:06',268,'192.168.1.69','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(111,'a3f4a596-9260-4a56-9a9c-6e8dc7e94571',23,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-11 04:21:07','2026-02-11 04:57:07',156,'192.168.1.99','Mozilla/5.0 (Realistic Dummy Data)','desktop',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07',NULL),
(112,'954ccb8c-4856-469b-9e5e-c820a722bf3b',23,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-08 04:46:07','2026-02-13 04:57:07',255,'192.168.1.161','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07',NULL),
(113,'aa616668-63c0-444f-86a2-04c063c4dfcd',23,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-16 04:40:07','2026-02-13 04:57:07',428,'192.168.1.78','Mozilla/5.0 (Realistic Dummy Data)','mobile',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07',NULL),
(114,'0b06f00d-3541-435a-8921-ad9bd2ffc796',23,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-12 04:26:07','2026-02-11 04:57:07',133,'192.168.1.71','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07',NULL),
(115,'bab71762-46b5-429e-8037-07c923ab3c9a',23,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-15 04:33:07','2026-02-08 04:57:07',413,'192.168.1.120','Mozilla/5.0 (Realistic Dummy Data)','tablet',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07',NULL),
(116,'28a6027d-202f-4ed6-863f-e55f5a9aa23a',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-17 16:08:56','2026-02-17 15:08:56',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 15:08:56','2026-02-17 15:08:56',NULL),
(117,'febbf86b-04a7-4f13-86f6-785b10508110',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-17 16:10:26','2026-02-17 15:10:26',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-02-17 15:10:26','2026-02-17 15:10:26',NULL),
(118,'a407bd83-db28-4791-b333-2ee362532750',2,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-17 16:42:53','2026-02-17 15:42:53',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,'{\"source\":\"web\"}','by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ','bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766','2026-02-17 15:42:53','2026-02-17 15:42:53',NULL),
(119,'960928da-8db2-43fd-bddf-0d7ce5af746a',3,NULL,NULL,NULL,NULL,NULL,NULL,'completed','2026-02-17 16:55:04','2026-02-17 15:55:04',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,'{\"source\":\"web\"}','by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ','bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766','2026-02-17 15:55:04','2026-02-17 15:55:04',NULL),
(120,'dab4e3b3-34e8-415d-affc-93b5c7929b79',4,NULL,NULL,'Gilang Rizky Ramadhan','test@gmail.com',NULL,NULL,'completed','2026-02-17 16:58:41','2026-02-17 15:58:41',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,'{\"source\":\"web\"}','by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ','bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766','2026-02-17 15:58:41','2026-02-17 15:58:41',NULL),
(121,'35c7976d-85e2-43c2-ad65-e3b33207e2a4',2,NULL,NULL,'Gilang Rizky Ramadhan','test@gmail.com','839483204','12312312','completed','2026-02-19 19:07:41','2026-02-19 18:07:41',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,'{\"source\":\"web\"}','by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ','bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766','2026-02-19 18:07:41','2026-02-19 18:07:41',NULL),
(122,'95cb5893-b526-4f8a-a392-6cb802c6acc7',2,NULL,NULL,'Gilang Rizky Ramadhan','tes1t@gmail.com','2523','12312312','completed','2026-02-19 19:08:44','2026-02-19 18:08:44',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',NULL,NULL,NULL,0,NULL,'{\"source\":\"web\"}','by6cPqxHpWZVn7VuZzjp4dBpzYVNwwRZ','bb86fc5612e5d9b4257934465f3f092527e1b88d5357b3b67c4e713c61d8f766','2026-02-19 18:08:44','2026-02-19 18:08:44',NULL);
/*!40000 ALTER TABLE `survey_responses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_schedules`
--

DROP TABLE IF EXISTS `survey_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `timezone` varchar(255) NOT NULL DEFAULT 'UTC',
  `recurrence` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recurrence`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_schedules_survey_id_index` (`survey_id`),
  CONSTRAINT `survey_schedules_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_schedules`
--

LOCK TABLES `survey_schedules` WRITE;
/*!40000 ALTER TABLE `survey_schedules` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `survey_schedules` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_sections`
--

DROP TABLE IF EXISTS `survey_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `logic` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`logic`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_sections_survey_id_index` (`survey_id`),
  KEY `survey_sections_order_index` (`order`),
  CONSTRAINT `survey_sections_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_sections`
--

LOCK TABLES `survey_sections` WRITE;
/*!40000 ALTER TABLE `survey_sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survey_sections` VALUES
(1,1,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(2,1,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23'),
(3,2,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(4,2,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53'),
(5,3,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(6,3,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21'),
(7,4,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(8,4,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(9,5,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(10,5,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(11,6,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(12,6,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(13,7,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(14,7,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(15,8,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(16,8,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(17,9,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(18,9,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(19,10,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(20,10,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(21,11,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(22,11,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(23,12,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(24,12,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(25,13,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(26,13,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(27,14,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(28,14,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(29,15,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(30,15,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(31,16,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(32,16,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(33,17,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(34,17,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(35,18,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(36,18,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(37,19,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(38,19,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(39,20,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(40,20,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(41,21,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(42,21,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(43,22,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(44,22,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(45,23,'Identitas & Demografi',NULL,1,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07'),
(46,23,'Feedback Utama',NULL,2,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `survey_sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_statistics`
--

DROP TABLE IF EXISTS `survey_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_statistics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `total_views` int(11) NOT NULL DEFAULT 0,
  `total_started` int(11) NOT NULL DEFAULT 0,
  `total_completed` int(11) NOT NULL DEFAULT 0,
  `completion_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `avg_completion_time` decimal(10,2) NOT NULL DEFAULT 0.00,
  `drop_off_points` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`drop_off_points`)),
  `device_breakdown` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`device_breakdown`)),
  `location_breakdown` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`location_breakdown`)),
  `last_calculated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_statistics_survey_id_index` (`survey_id`),
  CONSTRAINT `survey_statistics_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_statistics`
--

LOCK TABLES `survey_statistics` WRITE;
/*!40000 ALTER TABLE `survey_statistics` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survey_statistics` VALUES
(1,1,117,90,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23','2026-02-17 04:53:23'),
(2,2,139,83,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:54:53','2026-02-17 04:54:53','2026-02-17 04:54:53'),
(3,3,116,88,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:55:21','2026-02-17 04:55:21','2026-02-17 04:55:21'),
(4,4,139,77,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(5,5,133,88,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(6,6,111,83,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07'),
(7,7,148,83,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(8,8,120,87,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(9,9,125,76,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08'),
(10,10,137,78,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(11,11,147,88,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(12,12,131,90,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09'),
(13,13,126,84,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10'),
(14,14,132,88,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(15,15,146,82,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(16,16,127,88,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04'),
(17,17,124,89,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(18,18,114,82,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(19,19,135,87,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05'),
(20,20,123,87,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(21,21,148,85,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(22,22,130,86,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06'),
(23,23,125,76,5,21.40,350.50,NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `survey_statistics` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_templates`
--

DROP TABLE IF EXISTS `survey_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `structure` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`structure`)),
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_templates_tenant_id_foreign` (`tenant_id`),
  KEY `survey_templates_category_index` (`category`),
  CONSTRAINT `survey_templates_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_templates`
--

LOCK TABLES `survey_templates` WRITE;
/*!40000 ALTER TABLE `survey_templates` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survey_templates` VALUES
(1,2,'Template Standar IKM','Template sesuai Permenpan-RB nomor 14 tahun 2017.','Layanan Publik','\"{\\\"sections\\\":[{\\\"title\\\":\\\"Pertanyaan IKM\\\"}]}\"',1,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(2,2,'Template Standar IKM','Template sesuai Permenpan-RB nomor 14 tahun 2017.','Layanan Publik','\"{\\\"sections\\\":[{\\\"title\\\":\\\"Pertanyaan IKM\\\"}]}\"',1,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `survey_templates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `survey_themes`
--

DROP TABLE IF EXISTS `survey_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_themes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `primary_color` varchar(255) NOT NULL DEFAULT '#000000',
  `secondary_color` varchar(255) NOT NULL DEFAULT '#ffffff',
  `font_family` varchar(255) NOT NULL DEFAULT 'sans-serif',
  `logo_url` varchar(255) DEFAULT NULL,
  `background_image` varchar(255) DEFAULT NULL,
  `custom_css` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_themes_tenant_id_foreign` (`tenant_id`),
  CONSTRAINT `survey_themes_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_themes`
--

LOCK TABLES `survey_themes` WRITE;
/*!40000 ALTER TABLE `survey_themes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `survey_themes` VALUES
(1,2,'Tema Modern Biru','#007bff','#6c757d','Inter, sans-serif',NULL,'01KHP0C7ZMQ21H6G6389MEYN54.png',NULL,'2026-02-17 04:56:10','2026-02-17 13:34:26'),
(2,2,'Tema Modern Biru','#007bff','#6c757d','Inter, sans-serif',NULL,NULL,NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `survey_themes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `creator_id` bigint(20) unsigned NOT NULL,
  `template_id` bigint(20) unsigned DEFAULT NULL,
  `theme_id` bigint(20) unsigned DEFAULT NULL,
  `source_app_name` varchar(255) DEFAULT NULL,
  `source_app_url` varchar(255) DEFAULT NULL,
  `usage_context` text DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `welcome_message` text DEFAULT NULL,
  `thank_you_message` text DEFAULT NULL,
  `status` enum('draft','active','paused','closed','archived') NOT NULL DEFAULT 'draft',
  `type` enum('public','private','embedded','api_only') NOT NULL DEFAULT 'public',
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `allow_multiple_submissions` tinyint(1) NOT NULL DEFAULT 1,
  `require_respondent_identity` tinyint(1) NOT NULL DEFAULT 0,
  `duplicate_prevention_method` enum('none','cookie','email','login') NOT NULL DEFAULT 'cookie',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `surveys_uuid_unique` (`uuid`),
  KEY `surveys_creator_id_foreign` (`creator_id`),
  KEY `surveys_template_id_foreign` (`template_id`),
  KEY `surveys_theme_id_foreign` (`theme_id`),
  KEY `surveys_tenant_id_index` (`tenant_id`),
  KEY `surveys_status_index` (`status`),
  FULLTEXT KEY `surveys_title_description_fulltext` (`title`,`description`),
  CONSTRAINT `surveys_creator_id_foreign` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `surveys_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `survey_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `surveys_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `surveys_theme_id_foreign` FOREIGN KEY (`theme_id`) REFERENCES `survey_themes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys`
--

LOCK TABLES `surveys` WRITE;
/*!40000 ALTER TABLE `surveys` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `surveys` VALUES
(1,'9127ddf5-7043-45a9-b97b-24baa96f159d',2,1,NULL,NULL,'Portal Belajar Jabar','https://belajar.jabarprov.go.id','Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.','Evaluasi Pembelajaran Jarak Jauh 2024','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:53:23','2026-03-09 04:53:23','2026-02-17 04:53:23','2026-02-17 13:47:09','2026-02-17 13:47:09'),
(2,'f74c7828-9de4-4d05-b7a4-0727c53b3f6b',2,1,NULL,NULL,'Portal Belajar Jabar','https://belajar.jabarprov.go.id','Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.','Evaluasi Pembelajaran Jarak Jauh 2024','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','api_only','[]',0,1,'email','[]','2026-02-07 04:54:53','2026-03-09 04:54:53','2026-02-17 04:54:53','2026-02-19 18:06:42',NULL),
(3,'b640c9c0-afae-467c-a3c7-a03ede41eb90',2,1,NULL,NULL,'Portal Belajar Jabar','https://belajar.jabarprov.go.id','Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.','Evaluasi Pembelajaran Jarak Jauh 2024','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public','[]',0,1,'cookie','[]','2026-02-07 04:55:21','2026-03-09 04:55:21','2026-02-17 04:55:21','2026-02-17 15:56:46',NULL),
(4,'d9859f7a-11ab-49ce-8aa8-eff6c761fbc4',2,1,NULL,NULL,'Portal Belajar Jabar','https://belajar.jabarprov.go.id','Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.','Evaluasi Pembelajaran Jarak Jauh 2024','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public','[]',0,1,'email','[]','2026-02-07 04:56:07','2026-03-09 04:56:07','2026-02-17 04:56:07','2026-02-17 15:57:27',NULL),
(5,'4742c21e-c266-4a37-accf-5501123281fc',3,1,NULL,NULL,'Aplikasi SiPinter','https://sipinter.bandung.go.id','Muncul otomatis setelah perizinan disetujui. Data ditarik via API untuk laporan IKM bulanan ke Walikota.','Indeks Kepuasan Masyarakat (IKM) Pelayanan Perizinan','Survei ini bertujuan untuk mendapatkan data akurat mengenai indeks kepuasan masyarakat (ikm) pelayanan perizinan guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:07','2026-03-09 04:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(6,'a78ad5bb-1ee6-462b-8eb7-e2351d1273cd',4,1,NULL,NULL,'Sistem Informasi Kesehatan (SIK)','https://sik.bandung.go.id','Kuesioner pra-pendaftaran vaksinasi. Digunakan untuk screening awal kesehatan masyarakat.','Survei Kesiapan Vaksinasi Booster Tahap 3','Survei ini bertujuan untuk mendapatkan data akurat mengenai survei kesiapan vaksinasi booster tahap 3 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:07','2026-03-09 04:56:07','2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(7,'7138874b-5a84-40f7-966a-cc0434563c9c',5,1,NULL,NULL,'Website Resmi Jabar','https://jabarprov.go.id/polling','Poling terbuka di homepage website pemprov untuk menjaring aspirasi warga terkait infrastruktur.','Opini Publik Terhadap Pembangunan Flyover','Survei ini bertujuan untuk mendapatkan data akurat mengenai opini publik terhadap pembangunan flyover guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:08','2026-03-09 04:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(8,'99575220-0bda-4318-82c7-2b4fb4a72295',6,1,NULL,NULL,'SIM-ASN Jabar','https://sim.bkd.jabarprov.go.id','Survei internal (Private). Dibagikan melalui broadcast WhatsApp internal BKD.','Evaluasi Kinerja ASN Pemerintah Daerah','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi kinerja asn pemerintah daerah guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:08','2026-03-09 04:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(9,'54dea68e-8d3b-446d-b104-c37b97d7e2b8',7,1,NULL,NULL,'Marketplace Lokal Cimahi','https://umkm.cimahi.go.id','Muncul di dashboard seller. Digunakan untuk menentukan silabus pelatihan digital dinas.','Survei Kebutuhan Pelatihan UMKM Digital','Survei ini bertujuan untuk mendapatkan data akurat mengenai survei kebutuhan pelatihan umkm digital guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:08','2026-03-09 04:56:08','2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(10,'ff583943-17ee-4ed5-8b14-4c409f45ee41',8,1,NULL,NULL,'Aplikasi Sapa Warga','https://sapawarga.jabarprov.go.id','Integrasi via Webhook. Laporan otomatis masuk ke tim teknis perbaikan fasilitas umum.','Penilaian Fasilitas Ruang Publik Kota','Survei ini bertujuan untuk mendapatkan data akurat mengenai penilaian fasilitas ruang publik kota guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:09','2026-03-09 04:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(11,'f4403088-d1c6-48f9-8684-3251c9676955',9,1,NULL,NULL,'Aplikasi TMB Mobile','https://tmb.bandung.go.id','Polling di aplikasi mobile setelah penumpang selesai melakukan perjalanan.','Survei Penggunaan Transportasi Umum','Survei ini bertujuan untuk mendapatkan data akurat mengenai survei penggunaan transportasi umum guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:09','2026-03-09 04:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(12,'635f3fec-51a1-4fb0-ae38-cb2c44e95e7e',10,1,NULL,NULL,'Sistem Antrean RSUD','https://antrean.alihsan.id','SMS/Email broadcast otomatis setelah status pasien dinyatakan selesai rawat.','Feedback Pasca Rawat Jalan Pasien RSUD','Survei ini bertujuan untuk mendapatkan data akurat mengenai feedback pasca rawat jalan pasien rsud guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:09','2026-03-09 04:56:09','2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(13,'d713fd48-a928-4bea-8dcf-07e043cbbf94',11,1,NULL,NULL,'Sistem Logistik SosJabar','https://bansos.jabarprov.go.id','Verifikasi penerima manfaat. Data digunakan untuk audit internal penyaluran bantuan.','Polling Efektivitas Penyaluran Bansos','Survei ini bertujuan untuk mendapatkan data akurat mengenai polling efektivitas penyaluran bansos guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:56:10','2026-03-09 04:56:10','2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(14,'d912b5fc-d0fa-45e4-861b-989bbee743d1',2,1,NULL,NULL,'Portal Belajar Jabar','https://belajar.jabarprov.go.id','Embed di dashboard siswa dan guru untuk evaluasi kurikulum setiap semester.','Evaluasi Pembelajaran Jarak Jauh 2024','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi pembelajaran jarak jauh 2024 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:04','2026-03-09 04:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(15,'ddfefb34-ef79-4949-a001-eda0f91e1a26',3,1,NULL,NULL,'Aplikasi SiPinter','https://sipinter.bandung.go.id','Muncul otomatis setelah perizinan disetujui. Data ditarik via API untuk laporan IKM bulanan ke Walikota.','Indeks Kepuasan Masyarakat (IKM) Pelayanan Perizinan','Survei ini bertujuan untuk mendapatkan data akurat mengenai indeks kepuasan masyarakat (ikm) pelayanan perizinan guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:04','2026-03-09 04:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(16,'73c16bfd-5a3b-4df9-87bf-8fdb8330bb38',4,1,NULL,NULL,'Sistem Informasi Kesehatan (SIK)','https://sik.bandung.go.id','Kuesioner pra-pendaftaran vaksinasi. Digunakan untuk screening awal kesehatan masyarakat.','Survei Kesiapan Vaksinasi Booster Tahap 3','Survei ini bertujuan untuk mendapatkan data akurat mengenai survei kesiapan vaksinasi booster tahap 3 guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:04','2026-03-09 04:57:04','2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(17,'9e5f6408-6903-43ea-b3e7-3a69d952d374',5,1,NULL,NULL,'Website Resmi Jabar','https://jabarprov.go.id/polling','Poling terbuka di homepage website pemprov untuk menjaring aspirasi warga terkait infrastruktur.','Opini Publik Terhadap Pembangunan Flyover','Survei ini bertujuan untuk mendapatkan data akurat mengenai opini publik terhadap pembangunan flyover guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:05','2026-03-09 04:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(18,'960d8e21-7817-40e4-901f-769226cda2fc',6,1,NULL,NULL,'SIM-ASN Jabar','https://sim.bkd.jabarprov.go.id','Survei internal (Private). Dibagikan melalui broadcast WhatsApp internal BKD.','Evaluasi Kinerja ASN Pemerintah Daerah','Survei ini bertujuan untuk mendapatkan data akurat mengenai evaluasi kinerja asn pemerintah daerah guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:05','2026-03-09 04:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(19,'173b28cb-2b97-41ce-a0b8-5efd613924e3',7,1,NULL,NULL,'Marketplace Lokal Cimahi','https://umkm.cimahi.go.id','Muncul di dashboard seller. Digunakan untuk menentukan silabus pelatihan digital dinas.','Survei Kebutuhan Pelatihan UMKM Digital','Survei ini bertujuan untuk mendapatkan data akurat mengenai survei kebutuhan pelatihan umkm digital guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:05','2026-03-09 04:57:05','2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(20,'d5e33101-8fc5-42b5-8b81-1ceb7c9be45d',8,1,NULL,NULL,'Aplikasi Sapa Warga','https://sapawarga.jabarprov.go.id','Integrasi via Webhook. Laporan otomatis masuk ke tim teknis perbaikan fasilitas umum.','Penilaian Fasilitas Ruang Publik Kota','Survei ini bertujuan untuk mendapatkan data akurat mengenai penilaian fasilitas ruang publik kota guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:06','2026-03-09 04:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(21,'9b368484-aeda-483d-b8df-b283f45303f8',9,1,NULL,NULL,'Aplikasi TMB Mobile','https://tmb.bandung.go.id','Polling di aplikasi mobile setelah penumpang selesai melakukan perjalanan.','Survei Penggunaan Transportasi Umum','Survei ini bertujuan untuk mendapatkan data akurat mengenai survei penggunaan transportasi umum guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:06','2026-03-09 04:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(22,'65ea3831-439d-4596-9cb1-b308b4ec2566',10,1,NULL,NULL,'Sistem Antrean RSUD','https://antrean.alihsan.id','SMS/Email broadcast otomatis setelah status pasien dinyatakan selesai rawat.','Feedback Pasca Rawat Jalan Pasien RSUD','Survei ini bertujuan untuk mendapatkan data akurat mengenai feedback pasca rawat jalan pasien rsud guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:06','2026-03-09 04:57:06','2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(23,'ca9b13de-07bc-4f96-986c-b91c87dd53b6',11,1,NULL,NULL,'Sistem Logistik SosJabar','https://bansos.jabarprov.go.id','Verifikasi penerima manfaat. Data digunakan untuk audit internal penyaluran bantuan.','Polling Efektivitas Penyaluran Bansos','Survei ini bertujuan untuk mendapatkan data akurat mengenai polling efektivitas penyaluran bansos guna meningkatkan kualitas layanan publik.','Selamat datang di Survei Layanan Publik. Mohon luangkan waktu Anda sebentar.','Terima kasih atas partisipasi Anda. Pendapat Anda sangat berarti bagi kami.','active','public',NULL,1,0,'cookie',NULL,'2026-02-07 04:57:07','2026-03-09 04:57:07','2026-02-17 04:57:07','2026-02-17 04:57:07',NULL);
/*!40000 ALTER TABLE `surveys` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tenant_settings`
--

DROP TABLE IF EXISTS `tenant_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_settings_tenant_id_key_unique` (`tenant_id`,`key`),
  CONSTRAINT `tenant_settings_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_settings`
--

LOCK TABLES `tenant_settings` WRITE;
/*!40000 ALTER TABLE `tenant_settings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tenant_settings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tenant_user`
--

DROP TABLE IF EXISTS `tenant_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`roles`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_user_tenant_id_user_id_unique` (`tenant_id`,`user_id`),
  KEY `tenant_user_tenant_id_index` (`tenant_id`),
  KEY `tenant_user_user_id_index` (`user_id`),
  CONSTRAINT `tenant_user_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tenant_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_user`
--

LOCK TABLES `tenant_user` WRITE;
/*!40000 ALTER TABLE `tenant_user` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tenant_user` VALUES
(1,1,2,'[\"tenant_admin\"]','2026-02-17 04:53:23','2026-02-17 04:53:23');
/*!40000 ALTER TABLE `tenant_user` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `database` varchar(255) DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_uuid_unique` (`uuid`),
  UNIQUE KEY `tenants_slug_unique` (`slug`),
  UNIQUE KEY `tenants_domain_unique` (`domain`),
  KEY `tenants_uuid_index` (`uuid`),
  KEY `tenants_slug_index` (`slug`),
  KEY `tenants_domain_index` (`domain`),
  KEY `tenants_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tenants` VALUES
(1,'7636ef9e-ca66-49bc-8ade-61c4c077269f','DPMPTSP Kota Bandung','dpmptsp-bandung',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:53:23',NULL),
(2,'2bb0b832-702a-491a-96fb-6a2ce938f7df','Dinas Pendidikan Jawa Barat','disdik-jabar',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(3,'a6a2d6c2-ae92-4e2a-971e-33ca1bae0029','Dinas Kesehatan Kota Bandung','dinkes-bandung',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(4,'314dbf18-9ff5-4e22-9733-c030e0ec5c77','Diskominfo Prov. Jawa Barat','diskominfo-jabar',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(5,'851dbb64-6990-4628-aeed-ce2036922554','RSUD Al-Ihsan Bandung','rsud-alihsan',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(6,'1cc133d0-a1ed-41c5-9739-ba3cb931bf61','Bappeda Jawa Barat','bappeda-jabar',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(7,'e3d26582-c3ba-4bc0-9b83-3cd8d7e6b004','Dinas Sosial Kota Cimahi','dinsos-cimahi',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(8,'bb8b35ae-0eb8-424b-88dd-3e1b47631b06','DPMPTSP Kab. Bandung','dpmptsp-kabbdg',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(9,'5963cb01-1570-4779-add7-676762efbbde','Dinas Pariwisata Jabar','dispar-jabar',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(10,'b96d3dd1-9d92-4052-a08e-2b0d34628346','Universitas Indonesia','ui-depok',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL),
(11,'bdf6c09b-893e-461a-a6ee-49a174861d1e','Kantor Gubernur Jabar','humas-jabar',NULL,NULL,NULL,'active','2026-02-17 04:53:23','2026-02-17 04:57:02',NULL);
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_role_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `user_role_role_id_foreign` (`role_id`),
  CONSTRAINT `user_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_role_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `user_role` VALUES
(1,1,1,NULL,NULL),
(2,2,2,NULL,NULL);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_uuid_index` (`uuid`),
  KEY `users_deleted_at_index` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'ef41dd44-28b5-430b-a2a0-3015763f5e96','Super Administrator','superadmin@survei.test','2026-02-17 17:42:40','$2y$12$hOn.rG9PFcih1qb8Dc7wtu7SRc3sln0Bn0hQLvOufyf6pV2LbP0Ey',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23',NULL),
(2,'8175a428-0464-4b78-9931-05e4f74a180a','Petugas Admin Wilayah','petugas@bandung.go.id',NULL,'$2y$12$SZ0mbemrZoXm6Pg8mthZ4OLK6hblUCCEjMMOQRfBnQiy2/82ylcz2',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:53:23','2026-02-17 04:53:23',NULL),
(3,'fe1f17aa-7766-4f6f-aef7-82443c593d1d','Budi Santoso','budi@jabarprov.go.id',NULL,'$2y$12$VNN5nBtwj/eJppw46jfVvuYKNKHiLUpUU1qWcMWpcJEAFr/gbHc..',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:57:03','2026-02-17 04:57:03',NULL),
(4,'681be0a1-9506-4c1e-b0cb-ff1b239ac138','Siti Aminah','siti@bandung.go.id',NULL,'$2y$12$vV.x8taV9Q6xf6U0Hr/OZ.wIg2zmNinBWzD/Y697nB7dBHMiZg46W',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:57:03','2026-02-17 04:57:03',NULL),
(5,'5edca855-8da5-430b-a931-a8d581d39516','Asep Surasep','asep@cimahi.go.id',NULL,'$2y$12$iY2iEnISfq2hKFx3vq1V.OvU3S8XyEsrHfS3i8fVaoGg8NgNbrvTe',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:57:03','2026-02-17 04:57:03',NULL),
(6,'bbb64d97-31ae-43fc-a40e-03853e11d0fb','Dewi Lestari','dewi@pelayanan.test',NULL,'$2y$12$tWVwVSZ5fucHDEkY6lCGb.QO7/nmGEp0Bsq6Hj52nNkfvQqEVUpBO',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:57:03','2026-02-17 04:57:03',NULL),
(7,'cbdfea4f-db9b-4c38-a7a4-91bba69a50e1','Randi Pangalila','randi@analisis.test',NULL,'$2y$12$jPBNt9biIyE5KU3ulyqMc.BOroNpVqnUjSUxY34s34NOLhpzt4aji',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `webhook_logs`
--

DROP TABLE IF EXISTS `webhook_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` bigint(20) unsigned NOT NULL,
  `event` varchar(255) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `status_code` int(11) DEFAULT NULL,
  `response_body` text DEFAULT NULL,
  `attempt_number` int(11) NOT NULL DEFAULT 1,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_logs_webhook_id_index` (`webhook_id`),
  KEY `webhook_logs_event_index` (`event`),
  CONSTRAINT `webhook_logs_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_logs`
--

LOCK TABLES `webhook_logs` WRITE;
/*!40000 ALTER TABLE `webhook_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `webhook_logs` VALUES
(1,1,'survey.completed','\"{\\\"survey_id\\\":3}\"',200,NULL,1,'2026-02-17 04:55:22',NULL,'2026-02-17 04:55:22','2026-02-17 04:55:22'),
(2,2,'survey.completed','\"{\\\"survey_id\\\":4}\"',200,NULL,1,'2026-02-17 04:56:07',NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(3,3,'survey.completed','\"{\\\"survey_id\\\":5}\"',200,NULL,1,'2026-02-17 04:56:07',NULL,'2026-02-17 04:56:07','2026-02-17 04:56:07'),
(4,4,'survey.completed','\"{\\\"survey_id\\\":6}\"',200,NULL,1,'2026-02-17 04:56:08',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(5,5,'survey.completed','\"{\\\"survey_id\\\":7}\"',200,NULL,1,'2026-02-17 04:56:08',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(6,6,'survey.completed','\"{\\\"survey_id\\\":8}\"',200,NULL,1,'2026-02-17 04:56:08',NULL,'2026-02-17 04:56:08','2026-02-17 04:56:08'),
(7,7,'survey.completed','\"{\\\"survey_id\\\":9}\"',200,NULL,1,'2026-02-17 04:56:09',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(8,8,'survey.completed','\"{\\\"survey_id\\\":10}\"',200,NULL,1,'2026-02-17 04:56:09',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(9,9,'survey.completed','\"{\\\"survey_id\\\":11}\"',200,NULL,1,'2026-02-17 04:56:09',NULL,'2026-02-17 04:56:09','2026-02-17 04:56:09'),
(10,10,'survey.completed','\"{\\\"survey_id\\\":12}\"',200,NULL,1,'2026-02-17 04:56:10',NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(11,11,'survey.completed','\"{\\\"survey_id\\\":13}\"',200,NULL,1,'2026-02-17 04:56:10',NULL,'2026-02-17 04:56:10','2026-02-17 04:56:10'),
(12,12,'survey.completed','\"{\\\"survey_id\\\":14}\"',200,NULL,1,'2026-02-17 04:57:04',NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(13,13,'survey.completed','\"{\\\"survey_id\\\":15}\"',200,NULL,1,'2026-02-17 04:57:04',NULL,'2026-02-17 04:57:04','2026-02-17 04:57:04'),
(14,14,'survey.completed','\"{\\\"survey_id\\\":16}\"',200,NULL,1,'2026-02-17 04:57:05',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(15,15,'survey.completed','\"{\\\"survey_id\\\":17}\"',200,NULL,1,'2026-02-17 04:57:05',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(16,16,'survey.completed','\"{\\\"survey_id\\\":18}\"',200,NULL,1,'2026-02-17 04:57:05',NULL,'2026-02-17 04:57:05','2026-02-17 04:57:05'),
(17,17,'survey.completed','\"{\\\"survey_id\\\":19}\"',200,NULL,1,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(18,18,'survey.completed','\"{\\\"survey_id\\\":20}\"',200,NULL,1,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(19,19,'survey.completed','\"{\\\"survey_id\\\":21}\"',200,NULL,1,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(20,20,'survey.completed','\"{\\\"survey_id\\\":22}\"',200,NULL,1,'2026-02-17 04:57:06',NULL,'2026-02-17 04:57:06','2026-02-17 04:57:06'),
(21,21,'survey.completed','\"{\\\"survey_id\\\":23}\"',200,NULL,1,'2026-02-17 04:57:07',NULL,'2026-02-17 04:57:07','2026-02-17 04:57:07');
/*!40000 ALTER TABLE `webhook_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `survey_id` bigint(20) unsigned DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `events` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`events`)),
  `secret` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `retry_limit` int(11) NOT NULL DEFAULT 3,
  `timeout_seconds` int(11) NOT NULL DEFAULT 5,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhooks_survey_id_foreign` (`survey_id`),
  KEY `webhooks_tenant_id_index` (`tenant_id`),
  CONSTRAINT `webhooks_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `webhooks_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `webhooks` VALUES
(1,2,3,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','DBvxnZDgUiAOqW7i',1,3,5,'2026-02-17 04:55:22','2026-02-17 04:55:22',NULL),
(2,2,4,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','CIkk5PAhhdxkFTJG',1,3,5,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(3,3,5,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','XNarnXNj40ibquke',1,3,5,'2026-02-17 04:56:07','2026-02-17 04:56:07',NULL),
(4,4,6,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','n4rnOxTpeATbnCb7',1,3,5,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(5,5,7,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','RdSxvvA3AUUjfGhQ',1,3,5,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(6,6,8,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','y4xKWWcXOcZTUWnw',1,3,5,'2026-02-17 04:56:08','2026-02-17 04:56:08',NULL),
(7,7,9,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','EYXpRwvE5i2BfwHl',1,3,5,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(8,8,10,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','us59ayFk5vOOUuWM',1,3,5,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(9,9,11,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','g7TmQe7ehFTNydd7',1,3,5,'2026-02-17 04:56:09','2026-02-17 04:56:09',NULL),
(10,10,12,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','GsfJz2RF8Oz2CxTK',1,3,5,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(11,11,13,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','DTAVxObmulmKyEST',1,3,5,'2026-02-17 04:56:10','2026-02-17 04:56:10',NULL),
(12,2,14,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','2jZrUhRFQBQL98Ug',1,3,5,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(13,3,15,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','0G1oYQxbt0Wz4sWO',1,3,5,'2026-02-17 04:57:04','2026-02-17 04:57:04',NULL),
(14,4,16,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','vT5igf9ReqmzR3iU',1,3,5,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(15,5,17,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','eVBgdMBc2tHXH1Zr',1,3,5,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(16,6,18,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','jcjbNvgSuOwBOO4L',1,3,5,'2026-02-17 04:57:05','2026-02-17 04:57:05',NULL),
(17,7,19,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','YsxTilWiW699SBKT',1,3,5,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(18,8,20,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','NmcPcrxkS5SJkLJR',1,3,5,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(19,9,21,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','hrrVv6h1NxpHclFY',1,3,5,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(20,10,22,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','nUJQwsL3eRZElt2r',1,3,5,'2026-02-17 04:57:06','2026-02-17 04:57:06',NULL),
(21,11,23,'https://api.external-system.test/callback','\"[\\\"survey.completed\\\"]\"','HqfcwPerdX36dgio',1,3,5,'2026-02-17 04:57:07','2026-02-17 04:57:07',NULL);
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-06 18:52:57
