/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.1-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: arsip_digital
-- ------------------------------------------------------
-- Server version	11.8.1-MariaDB-4deepin1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `action` varchar(255) NOT NULL,
  `document_id` int(11) unsigned DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `activity_logs` VALUES
(1,1,'upload',1,'::1','2026-03-02 18:40:21'),
(2,1,'view',1,'::1','2026-03-02 18:40:25'),
(3,1,'view',1,'::1','2026-03-02 18:40:28'),
(4,1,'chat',NULL,'::1','2026-03-02 18:40:39'),
(5,1,'view',1,'::1','2026-03-02 18:51:15'),
(6,1,'view',1,'::1','2026-03-02 18:55:45'),
(7,1,'chat',NULL,'::1','2026-03-02 18:57:38'),
(8,1,'delete',NULL,'::1','2026-03-02 19:02:16'),
(9,1,'upload',2,'::1','2026-03-02 19:02:32'),
(10,1,'view',2,'::1','2026-03-02 19:02:48');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `auth_groups_users`
--

DROP TABLE IF EXISTS `auth_groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_groups_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_groups_users_user_id_foreign` (`user_id`),
  CONSTRAINT `auth_groups_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_groups_users`
--

LOCK TABLES `auth_groups_users` WRITE;
/*!40000 ALTER TABLE `auth_groups_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `auth_groups_users` VALUES
(1,1,'super_admin','2026-03-02 18:30:57');
/*!40000 ALTER TABLE `auth_groups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `auth_identities`
--

DROP TABLE IF EXISTS `auth_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_identities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `secret` varchar(255) NOT NULL,
  `secret2` varchar(255) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `extra` text DEFAULT NULL,
  `force_reset` tinyint(1) NOT NULL DEFAULT 0,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_secret` (`type`,`secret`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `auth_identities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_identities`
--

LOCK TABLES `auth_identities` WRITE;
/*!40000 ALTER TABLE `auth_identities` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `auth_identities` VALUES
(1,1,'email_password',NULL,'admin@arsip.local','$2y$12$wNQFbFwKjxRPH1vrrz2GtusGbbMUHDOSTrh5dVeCanxntBddnZRp2',NULL,NULL,0,'2026-03-02 18:39:56','2026-03-02 18:30:57','2026-03-02 18:39:56');
/*!40000 ALTER TABLE `auth_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `auth_logins`
--

DROP TABLE IF EXISTS `auth_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_logins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `id_type` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_type_identifier` (`id_type`,`identifier`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_logins`
--

LOCK TABLES `auth_logins` WRITE;
/*!40000 ALTER TABLE `auth_logins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `auth_logins` VALUES
(1,'::1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','email_password','admin@arsip.local',1,'2026-03-02 18:39:56',1);
/*!40000 ALTER TABLE `auth_logins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `auth_permissions_users`
--

DROP TABLE IF EXISTS `auth_permissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permissions_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `permission` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_permissions_users_user_id_foreign` (`user_id`),
  CONSTRAINT `auth_permissions_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permissions_users`
--

LOCK TABLES `auth_permissions_users` WRITE;
/*!40000 ALTER TABLE `auth_permissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `auth_permissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `auth_remember_tokens`
--

DROP TABLE IF EXISTS `auth_remember_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_remember_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `selector` varchar(255) NOT NULL,
  `hashedValidator` varchar(255) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `expires` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `selector` (`selector`),
  KEY `auth_remember_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `auth_remember_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_remember_tokens`
--

LOCK TABLES `auth_remember_tokens` WRITE;
/*!40000 ALTER TABLE `auth_remember_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `auth_remember_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `auth_token_logins`
--

DROP TABLE IF EXISTS `auth_token_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_token_logins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `id_type` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_type_identifier` (`id_type`,`identifier`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_token_logins`
--

LOCK TABLES `auth_token_logins` WRITE;
/*!40000 ALTER TABLE `auth_token_logins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `auth_token_logins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `chat_logs`
--

DROP TABLE IF EXISTS `chat_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `question` text NOT NULL,
  `ai_answer` text NOT NULL,
  `context_document_ids` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_logs`
--

LOCK TABLES `chat_logs` WRITE;
/*!40000 ALTER TABLE `chat_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `chat_logs` VALUES
(1,1,'hai','API Key tidak ditemukan.','[]','2026-03-02 18:40:39'),
(2,1,'test','API Key tidak ditemukan.','[]','2026-03-02 18:57:38');
/*!40000 ALTER TABLE `chat_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `document_chunks`
--

DROP TABLE IF EXISTS `document_chunks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_chunks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(11) unsigned NOT NULL,
  `chunk_index` int(11) NOT NULL,
  `chunk_text` longtext NOT NULL,
  `embedding_vector` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_chunks_document_id_foreign` (`document_id`),
  CONSTRAINT `document_chunks_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_chunks`
--

LOCK TABLES `document_chunks` WRITE;
/*!40000 ALTER TABLE `document_chunks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `document_chunks` VALUES
(5,2,0,'                                                              PEMERINTAH KABUPATEN TANAH BUMBU\n                                                           DINAS PENANAMAN MODAL\n                                                      DAN PELAYANAN TERPADU SATU PINTU\n                                                      Alamat : Jln. Dharma Praja Kel. Gunung Tinggi Kec. Batulicin Kab. Tanah Bumbu\n                                                    Prov. Kalimantan Selatan – Kode Pos 72714 Telp : (0518) 70664 - Fax: (0518) 75264\n                                                   Laman : www.dpmptsp.tanahbumbukab.go.id Pos-el : dpmptsp@tanahbumbukab.go.id\n\n\n                                                                                                                        Batulicin, 3 Februari 2026\n\n\n                                   Nomor    : B/500.16.3.5/ 044 / DPMPTSP-P.1/II/2026\n                                   Sifat    : Biasa\n                                   Lampiran : -\n    ','[]','2026-03-02 19:02:32'),
(6,2,1,'                               Hal      : Permohonan Penyesuaian Domain Website Kemitraan UMKM\n\n                                   Yth. Kepala Dinas Komunikasi dan Informatika Kabupaten Tanah Bumbu\n                                        u.p. Bidang Aptika\n\n                                   Di -\n                                          Batulicin\n\n                                            Dalam rangka mendukung peningkatan pelayanan informasi penanaman modal serta\n                                   penguatan kemitraan UMKM di Kabupaten Tanah Bumbu, bersama ini kami sampaikan bahwa\n                                   Website Kemitraan UMKM (Mitra UMKM Tanbu) yang sebelumnya menggunakan domain\n                                   https://mitraumkm.tanahbumbukab.go.id/ telah dilakukan perubahan domain menjadi\n                                   https://investmentbridge.tanahbumbukab.go.id/. Website tersebut digunakan sebagai platform\n                                   kemitraan antara pela','[]','2026-03-02 19:02:32'),
(7,2,2,'ku usaha besar dan UMKM lokal di Kabupaten Tanah Bumbu.\n\n                                            Sehubungan dengan hal tersebut, kami mohon kepada Dinas Komunikasi, Informatika,\n                                   Statistik dan Persandian Kabupaten Tanah Bumbu melalui Bidang Aplikasi dan Informatika\n                                   (APTIKA) untuk dapat melakukan penyesuaian atas perubahan domain dimaksud.\n\n                                         Demikian surat ini kami sampaikan. Atas perhatian dan kerja sama yang baik, kami\n                                   ucapkan terima kasih.\n\n                                                                                                Plt Kepala Dinas,\n\n\n\n                                                                                                     ${ttd}\n\n\n\n                                                                                                Briyan Ajisoko, ST.M.Sos\n                                                        ','[]','2026-03-02 19:02:32'),
(8,2,3,'                                        Pembina / IV.a\n                                                                                                NIP. 198503192010011017\n\n\n\n\n                                                   Dokumen ini telah ditandatangani secara elektronik menggunakan sertifikat elektronik\n                                           yang diterbitkan oleh Balai Besar Sertifikasi Elektronik (BSrE), Badan Siber dan Sandi Negara (BSSN).\n\nPowered by TCPDF (www.tcpdf.org)\n','[]','2026-03-02 19:02:32');
/*!40000 ALTER TABLE `document_chunks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `document_number` varchar(100) DEFAULT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `nib` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `summary` longtext DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `raw_text` longtext DEFAULT NULL,
  `status` enum('processing','completed','error') NOT NULL DEFAULT 'processing',
  `uploaded_by` int(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `documents` VALUES
(2,'ERR-NO-KEY','Izin',2026,'Pelayanan','OpenAI API Key Missing','-',NULL,NULL,NULL,'Sistem belum dikonfigurasi dengan API Key OpenAI.','uploads/2026/izin/1772478152_0f7d3420abbacd297f20.pdf','                                                              PEMERINTAH KABUPATEN TANAH BUMBU\n                                                           DINAS PENANAMAN MODAL\n                                                      DAN PELAYANAN TERPADU SATU PINTU\n                                                      Alamat : Jln. Dharma Praja Kel. Gunung Tinggi Kec. Batulicin Kab. Tanah Bumbu\n                                                    Prov. Kalimantan Selatan – Kode Pos 72714 Telp : (0518) 70664 - Fax: (0518) 75264\n                                                   Laman : www.dpmptsp.tanahbumbukab.go.id Pos-el : dpmptsp@tanahbumbukab.go.id\n\n\n                                                                                                                        Batulicin, 3 Februari 2026\n\n\n                                   Nomor    : B/500.16.3.5/ 044 / DPMPTSP-P.1/II/2026\n                                   Sifat    : Biasa\n                                   Lampiran : -\n                                   Hal      : Permohonan Penyesuaian Domain Website Kemitraan UMKM\n\n                                   Yth. Kepala Dinas Komunikasi dan Informatika Kabupaten Tanah Bumbu\n                                        u.p. Bidang Aptika\n\n                                   Di -\n                                          Batulicin\n\n                                            Dalam rangka mendukung peningkatan pelayanan informasi penanaman modal serta\n                                   penguatan kemitraan UMKM di Kabupaten Tanah Bumbu, bersama ini kami sampaikan bahwa\n                                   Website Kemitraan UMKM (Mitra UMKM Tanbu) yang sebelumnya menggunakan domain\n                                   https://mitraumkm.tanahbumbukab.go.id/ telah dilakukan perubahan domain menjadi\n                                   https://investmentbridge.tanahbumbukab.go.id/. Website tersebut digunakan sebagai platform\n                                   kemitraan antara pelaku usaha besar dan UMKM lokal di Kabupaten Tanah Bumbu.\n\n                                            Sehubungan dengan hal tersebut, kami mohon kepada Dinas Komunikasi, Informatika,\n                                   Statistik dan Persandian Kabupaten Tanah Bumbu melalui Bidang Aplikasi dan Informatika\n                                   (APTIKA) untuk dapat melakukan penyesuaian atas perubahan domain dimaksud.\n\n                                         Demikian surat ini kami sampaikan. Atas perhatian dan kerja sama yang baik, kami\n                                   ucapkan terima kasih.\n\n                                                                                                Plt Kepala Dinas,\n\n\n\n                                                                                                     ${ttd}\n\n\n\n                                                                                                Briyan Ajisoko, ST.M.Sos\n                                                                                                Pembina / IV.a\n                                                                                                NIP. 198503192010011017\n\n\n\n\n                                                   Dokumen ini telah ditandatangani secara elektronik menggunakan sertifikat elektronik\n                                           yang diterbitkan oleh Balai Besar Sertifikasi Elektronik (BSrE), Badan Siber dan Sandi Negara (BSSN).\n\nPowered by TCPDF (www.tcpdf.org)\n','completed',1,'2026-03-02 19:02:32','2026-03-02 19:02:32');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'2020-12-28-223112','CodeIgniter\\Shield\\Database\\Migrations\\CreateAuthTables','default','CodeIgniter\\Shield',1772475967,1),
(2,'2021-07-04-041948','CodeIgniter\\Settings\\Database\\Migrations\\CreateSettingsTable','default','CodeIgniter\\Settings',1772475967,1),
(3,'2021-11-14-143905','CodeIgniter\\Settings\\Database\\Migrations\\AddContextColumn','default','CodeIgniter\\Settings',1772475967,1),
(4,'2026-03-02-182614','App\\Database\\Migrations\\CreateArsipTables','default','App',1772476002,2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `roles` VALUES
(1,'super_admin','2026-03-02 19:01:37'),
(2,'admin_arsip','2026-03-02 19:01:37'),
(3,'operator','2026-03-02 19:01:37'),
(4,'pimpinan','2026-03-02 19:01:37'),
(5,'auditor','2026-03-02 19:01:37'),
(6,'viewer','2026-03-02 19:01:37');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `class` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(31) NOT NULL DEFAULT 'string',
  `context` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `role_id` int(11) unsigned DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `last_active` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'Administrator Arsip','admin',NULL,'active',1,NULL,0,'2026-03-02 19:30:48','2026-03-02 18:30:57','2026-03-02 18:30:57',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-06 18:52:55
