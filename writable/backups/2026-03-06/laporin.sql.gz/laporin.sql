/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.1-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: laporin
-- ------------------------------------------------------
-- Server version	11.8.1-MariaDB-4deepin1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_critical` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Aplikasi kritikal akan meningkatkan prioritas laporan',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_critical` (`is_critical`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `applications` VALUES
(10,'Penilaian','',0,1,'2025-12-09 05:42:18','2025-12-09 11:56:14'),
(11,'Perjadin','',0,1,'2025-12-09 05:42:27','2025-12-09 11:56:21'),
(12,'Pengaduan','',0,1,'2025-12-09 05:42:39','2025-12-09 11:56:08'),
(13,'Sistem Statistik Tepadu','',0,1,'2025-12-09 05:42:59','2025-12-09 11:56:00');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int(11) unsigned NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `uploaded_by` int(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attachments_uploaded_by_foreign` (`uploaded_by`),
  KEY `complaint_id` (`complaint_id`),
  CONSTRAINT `attachments_complaint_id_foreign` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `attachments_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categories` VALUES
(1,'Error System','Error atau bug pada sistem yang menyebabkan aplikasi tidak berfungsi',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(2,'Performance Issue','Masalah performa seperti loading lambat atau aplikasi lemot',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(3,'Login Problem','Masalah saat login atau autentikasi',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(4,'Data Issue','Masalah terkait data tidak muncul, data hilang, atau data tidak akurat',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(5,'Feature Request','Permintaan fitur baru atau penyempurnaan fitur yang ada',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(6,'UI/UX Issue','Masalah tampilan atau pengalaman pengguna',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(7,'Integration Problem','Masalah integrasi antar sistem',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(8,'Security Issue','Masalah keamanan atau akses tidak authorized',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(9,'Lainnya','Kategori lainnya yang tidak masuk dalam kategori di atas',1,'2025-12-06 19:05:32','2025-12-06 19:05:32');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `chats`
--

DROP TABLE IF EXISTS `chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chats` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `message` text NOT NULL,
  `is_internal_note` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Catatan internal admin (tidak terlihat user)',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chats_user_id_foreign` (`user_id`),
  KEY `complaint_id` (`complaint_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `chats_complaint_id_foreign` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chats_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chats`
--

LOCK TABLES `chats` WRITE;
/*!40000 ALTER TABLE `chats` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `chats` VALUES
(32,21,7,'Tolong di bantu arahannya',0,'2025-12-09 11:58:25'),
(33,21,2,'Silahkan di cek kembali',0,'2025-12-09 12:00:00');
/*!40000 ALTER TABLE `chats` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `complaint_history`
--

DROP TABLE IF EXISTS `complaint_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaint_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `action` varchar(100) NOT NULL COMMENT 'created, status_changed, priority_changed, assigned, etc',
  `old_value` varchar(255) DEFAULT NULL,
  `new_value` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaint_history_user_id_foreign` (`user_id`),
  KEY `complaint_id` (`complaint_id`),
  CONSTRAINT `complaint_history_complaint_id_foreign` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `complaint_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint_history`
--

LOCK TABLES `complaint_history` WRITE;
/*!40000 ALTER TABLE `complaint_history` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `complaint_history` VALUES
(69,21,7,'Demo Account','demo@example.com','created',NULL,NULL,'Laporan dibuat dengan prioritas: normal','2025-12-09 11:57:45'),
(70,21,2,'Administrator','admin@example.com','assigned',NULL,'Administrator','Laporan ditugaskan ke Administrator','2025-12-09 11:58:57'),
(71,21,2,'Administrator','admin@example.com','status_changed','in_progress','resolved','Status diubah dari in_progress menjadi resolved','2025-12-09 11:59:15'),
(72,21,7,'Demo Account','demo@example.com','closed','resolved','closed','Laporan ditutup setelah user memberikan feedback (Rating: 5/5)','2025-12-09 12:01:00');
/*!40000 ALTER TABLE `complaint_history` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaints` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `impact_type` enum('cannot_use','specific_bug','slow_performance','other') NOT NULL COMMENT 'User pilih dampak, sistem tentukan prioritas',
  `priority` enum('normal','important','urgent') NOT NULL DEFAULT 'normal' COMMENT 'Auto-calculated by system, dapat di-override admin',
  `status` enum('pending','in_progress','resolved','closed') NOT NULL DEFAULT 'pending',
  `assigned_to` int(11) unsigned DEFAULT NULL COMMENT 'Admin yang handle laporan ini',
  `resolved_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaints_application_id_foreign` (`application_id`),
  KEY `complaints_category_id_foreign` (`category_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `assigned_to` (`assigned_to`),
  CONSTRAINT `complaints_application_id_foreign` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `complaints_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `complaints_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `complaints_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaints`
--

LOCK TABLES `complaints` WRITE;
/*!40000 ALTER TABLE `complaints` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `complaints` VALUES
(21,7,13,4,'Gagal Mengapload Data','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, urna eget tincidunt tempus, augue tortor cursus sapien, eget molestie justo lorem sed nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Integer dictum magna id velit efficitur, eu sagittis arcu feugiat. Donec at tortor nec magna facilisis malesuada. Mauris sodales justo eget mi efficitur, sed viverra urna mattis. Suspendisse potenti. Praesent euismod nisl in dapibus tristique, at fermentum neque dapibus.','specific_bug','normal','closed',2,'2025-12-09 11:59:15','2025-12-09 12:01:00','2025-12-09 11:57:44','2025-12-09 12:01:00');
/*!40000 ALTER TABLE `complaints` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedbacks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `rating` tinyint(1) NOT NULL COMMENT 'Rating 1-5',
  `comment` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feedbacks_user_id_foreign` (`user_id`),
  KEY `complaint_id` (`complaint_id`),
  CONSTRAINT `feedbacks_complaint_id_foreign` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `feedbacks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedbacks`
--

LOCK TABLES `feedbacks` WRITE;
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `feedbacks` VALUES
(16,21,7,5,'Menangani masalah dengan cepat','2025-12-09 12:01:00');
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `knowledge_base`
--

DROP TABLE IF EXISTS `knowledge_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `application_id` int(11) unsigned DEFAULT NULL,
  `category_id` int(11) unsigned DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL COMMENT 'Comma separated tags',
  `view_count` int(11) NOT NULL DEFAULT 0,
  `is_published` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_base_category_id_foreign` (`category_id`),
  KEY `knowledge_base_created_by_foreign` (`created_by`),
  KEY `application_id` (`application_id`),
  CONSTRAINT `knowledge_base_application_id_foreign` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `knowledge_base_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `knowledge_base_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base`
--

LOCK TABLES `knowledge_base` WRITE;
/*!40000 ALTER TABLE `knowledge_base` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `knowledge_base` VALUES
(1,'Cara Reset Password Akun','<h3>Lupa Password?</h3><p>Jika Anda lupa password, silakan hubungi administrator IT untuk reset password. Jangan bagikan password Anda kepada siapapun.</p><p><strong>Langkah-langkah:</strong></p><ol><li>Hubungi admin IT via email atau telepon</li><li>Verifikasi identitas Anda</li><li>Admin akan mengirim password baru ke email Anda</li><li>Login dan segera ubah password</li></ol>',NULL,3,'password,reset,login',5,1,1,'2025-12-06 19:05:32','2025-12-07 08:23:01'),
(2,'Aplikasi Lambat? Coba Cara Ini','<h3>Tips Mengatasi Aplikasi Lambat</h3><p>Jika aplikasi terasa lambat, coba langkah berikut:</p><ul><li><strong>Clear Cache Browser:</strong> Tekan Ctrl+Shift+Delete dan hapus cache</li><li><strong>Tutup Tab yang Tidak Digunakan:</strong> Terlalu banyak tab membuat browser lambat</li><li><strong>Cek Koneksi Internet:</strong> Pastikan koneksi internet stabil</li><li><strong>Restart Browser:</strong> Tutup dan buka kembali browser</li><li><strong>Update Browser:</strong> Gunakan browser versi terbaru</li></ul><p>Jika masih lambat, laporkan ke admin IT.</p>',NULL,2,'performance,lambat,slow,cache',4,1,1,'2025-12-06 19:05:32','2025-12-07 12:30:12'),
(3,'Cara Upload File dengan Benar','<h3>Panduan Upload File</h3><p><strong>Format File yang Didukung:</strong></p><ul><li>Gambar: JPG, PNG, GIF (max 5MB)</li><li>Dokumen: PDF, DOC, DOCX, XLS, XLSX (max 10MB)</li><li>Video: MP4, AVI (max 50MB)</li></ul><p><strong>Cara Upload:</strong></p><ol><li>Klik tombol \"Pilih File\" atau \"Browse\"</li><li>Pilih file dari komputer Anda</li><li>Tunggu hingga progress bar selesai</li><li>Jangan tutup halaman saat upload</li></ol><p><strong>Troubleshooting:</strong></p><ul><li>Jika gagal, cek ukuran file</li><li>Pastikan format file sesuai</li><li>Coba gunakan koneksi internet yang lebih stabil</li></ul>',NULL,NULL,'upload,file,attachment',1,1,1,'2025-12-06 19:05:32','2025-12-07 01:15:24'),
(4,'Error 404 Not Found','<h3>Apa itu Error 404?</h3><p>Error 404 berarti halaman yang Anda cari tidak ditemukan.</p><p><strong>Penyebab Umum:</strong></p><ul><li>URL salah atau typo</li><li>Halaman sudah dihapus atau dipindahkan</li><li>Link broken dari sumber lain</li></ul><p><strong>Solusi:</strong></p><ol><li>Cek kembali URL yang Anda ketik</li><li>Kembali ke halaman utama</li><li>Gunakan fitur search</li><li>Hubungi admin jika masalah berlanjut</li></ol>',NULL,1,'error,404,not found',9,1,1,'2025-12-06 19:05:32','2025-12-07 08:22:57'),
(5,'Tips Keamanan Akun','<h3>Jaga Keamanan Akun Anda</h3><p><strong>Password yang Aman:</strong></p><ul><li>Minimal 8 karakter</li><li>Kombinasi huruf besar, kecil, angka, dan simbol</li><li>Jangan gunakan tanggal lahir atau nama</li><li>Ubah password secara berkala</li></ul><p><strong>Jangan Pernah:</strong></p><ul><li>Berbagi password dengan orang lain</li><li>Tulis password di tempat yang mudah dilihat</li><li>Gunakan password yang sama untuk semua akun</li><li>Login dari komputer publik tanpa logout</li></ul><p><strong>Jika Akun Diretas:</strong></p><ol><li>Segera hubungi admin IT</li><li>Ganti password semua akun terkait</li><li>Laporkan aktivitas mencurigakan</li></ol>',NULL,8,'security,password,keamanan',1,1,1,'2025-12-06 19:05:32','2025-12-07 01:27:55');
/*!40000 ALTER TABLE `knowledge_base` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'2025-12-06-184923','App\\Database\\Migrations\\CreateUsersTable','default','App',1765047487,1),
(2,'2025-12-06-185028','App\\Database\\Migrations\\CreateApplicationsTable','default','App',1765047487,1),
(3,'2025-12-06-185057','App\\Database\\Migrations\\CreateCategoriesTable','default','App',1765047487,1),
(4,'2025-12-06-185120','App\\Database\\Migrations\\CreateComplaintsTable','default','App',1765047487,1),
(5,'2025-12-06-185143','App\\Database\\Migrations\\CreateAttachmentsTable','default','App',1765047487,1),
(6,'2025-12-06-185206','App\\Database\\Migrations\\CreateChatsTable','default','App',1765047487,1),
(7,'2025-12-06-185227','App\\Database\\Migrations\\CreateComplaintHistoryTable','default','App',1765047487,1),
(8,'2025-12-06-185252','App\\Database\\Migrations\\CreateKnowledgeBaseTable','default','App',1765047487,1),
(9,'2025-12-06-185311','App\\Database\\Migrations\\CreateNotificationsTable','default','App',1765047487,1),
(10,'2025-12-06-185329','App\\Database\\Migrations\\CreateFeedbacksTable','default','App',1765047487,1),
(11,'2025-12-08-120000','App\\Database\\Migrations\\AddUserFieldsToComplaintHistory','default','App',1765160160,2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `complaint_id` int(11) unsigned DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_complaint_id_foreign` (`complaint_id`),
  KEY `user_id` (`user_id`),
  KEY `is_read` (`is_read`),
  CONSTRAINT `notifications_complaint_id_foreign` FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `notifications` VALUES
(54,2,NULL,'Laporan Baru','Laporan baru telah dibuat: Data Error',1,'2025-12-08 02:16:06'),
(55,1,NULL,'Laporan Baru','Laporan baru telah dibuat: Data Error',1,'2025-12-08 02:16:06'),
(59,2,NULL,'Laporan Baru','Laporan baru telah dibuat: aasasasasfewffdsfdsf3121r',1,'2025-12-08 04:10:03'),
(60,1,NULL,'Laporan Baru','Laporan baru telah dibuat: aasasasasfewffdsfdsf3121r',1,'2025-12-08 04:10:03'),
(64,2,NULL,'Pesan Baru','User Demo 2 mengirim pesan baru pada laporan Anda',1,'2025-12-08 04:13:02'),
(65,2,NULL,'Pesan Baru dari User','User Demo 2 mengirim pesan pada laporan #14',1,'2025-12-08 04:15:00'),
(66,1,NULL,'Pesan Baru dari User','User Demo 2 mengirim pesan pada laporan #14',1,'2025-12-08 04:15:00'),
(118,2,21,'Laporan Baru','Laporan baru telah dibuat: Gagal Mengapload Data',0,'2025-12-09 11:57:45'),
(119,1,21,'Laporan Baru','Laporan baru telah dibuat: Gagal Mengapload Data',0,'2025-12-09 11:57:45'),
(120,2,21,'Pesan Baru dari User','Demo Account mengirim pesan pada laporan #21',0,'2025-12-09 11:58:25'),
(121,1,21,'Pesan Baru dari User','Demo Account mengirim pesan pada laporan #21',0,'2025-12-09 11:58:25'),
(122,7,21,'Laporan Ditangani','Laporan Anda sedang ditangani oleh Administrator',0,'2025-12-09 11:58:57'),
(123,7,21,'Status Laporan Berubah','Status laporan Anda berubah dari Sedang Diproses menjadi Selesai',0,'2025-12-09 11:59:15'),
(124,7,21,'Laporan Selesai','Laporan Anda telah diselesaikan. Silakan berikan feedback.',0,'2025-12-09 11:59:15'),
(125,7,21,'Pesan Baru','Administrator mengirim pesan baru pada laporan Anda',0,'2025-12-09 12:00:00');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `search_history`
--

DROP TABLE IF EXISTS `search_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `query` varchar(255) NOT NULL,
  `filters` text DEFAULT NULL,
  `results_count` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `search_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_history`
--

LOCK TABLES `search_history` WRITE;
/*!40000 ALTER TABLE `search_history` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `search_history` VALUES
(1,2,'belum','[]',0,'2025-12-08 05:21:25'),
(2,2,'belum','[]',0,'2025-12-08 05:22:19'),
(3,2,'belum','[]',0,'2025-12-08 05:22:22'),
(4,2,'belum','[]',0,'2025-12-08 05:23:00'),
(5,2,'belum','[]',0,'2025-12-08 05:23:14'),
(6,2,'belum','[]',0,'2025-12-08 05:23:33'),
(7,2,'belum','[]',0,'2025-12-08 05:28:06'),
(8,2,'Login','[]',6,'2025-12-08 05:28:15'),
(9,2,'Login','[]',6,'2025-12-08 05:29:10'),
(10,2,'Login','[]',6,'2025-12-08 05:29:16'),
(11,2,'a','[]',24,'2025-12-08 05:38:19'),
(12,2,'a','[]',24,'2025-12-08 05:39:11'),
(13,2,'a','[]',24,'2025-12-08 05:39:15'),
(14,2,'a','[]',24,'2025-12-08 05:41:19'),
(15,2,'a','[]',24,'2025-12-08 05:48:40');
/*!40000 ALTER TABLE `search_history` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('user','admin','superadmin') NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'superadmin','superadmin@example.com','$2y$10$QVmg2FwnI0tbnNRmiTZaeuVq7VOMcCMu1mnX82Y7eiLYlfOixoEX6','Super Administrator','superadmin',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(2,'admin','admin@example.com','$2y$10$DLfQ7/Ef.PCtUMvt8Tl89OtgIDWSVjf8aIHwE2hQJRSrXFBGeiis2','Administrator','admin',1,'2025-12-06 19:05:32','2025-12-06 19:05:32'),
(7,'Demo','demo@example.com','$2y$10$53Rv1ylbN4pz5EkcuU31JOloQ9pRjPTnoj4I1mkaDVftb/mJHxgCS','Demo Account','user',1,'2025-12-09 11:54:40','2025-12-09 11:54:40'),
(8,'Gilang Rizky','gilang@gmail.com','$2y$12$I5xsodnisJU4WuR19yyX.ek8JlDcS1a0xoOnFcMDICSXJxSoXD1S.','Gilang Rizky','superadmin',1,'2026-02-03 16:46:47','2026-02-03 16:46:47'),
(9,'Test','test123@gmail.com','$2y$12$7FnNHTxLV0PKnXb3aqbM7eB.DQXeoJrgYJKEH/HlL47cud6slU9I2','test','user',1,'2026-02-03 16:48:45','2026-02-03 16:48:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-06 18:52:56
